
import Dexie, { Table } from 'dexie';
import { User, Department, Goal, WeeklyReport, AuditLog, Reminder, ReportTemplate, UserRole, Project } from '../types';

class SigaPoaDatabase extends Dexie {
  users!: Table<User>;
  departments!: Table<Department>;
  goals!: Table<Goal>;
  weeklyReports!: Table<WeeklyReport>;
  auditLogs!: Table<AuditLog>;
  reminders!: Table<Reminder>;
  reportTemplates!: Table<ReportTemplate>;
  projects!: Table<Project>;

  constructor() {
    super('SigaPoa_Ent_v18_Final');
    // Version 4: Added projects table and goal order
    (this as any).version(4).stores({
      users: '++id, username',
      departments: '++id, name, order',
      goals: '++id, deptId, order',
      weeklyReports: '++id, deptId',
      auditLogs: '++id, timestamp, action',
      reminders: '++id, deptId',
      reportTemplates: '++id, reportKey',
      projects: '++id, deptId'
    });
  }
}

export const db = new SigaPoaDatabase();

// --- Automatic Log Cleanup (Retention Policy: 30 Days) ---
export const pruneOldLogs = async () => {
    try {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const limitISO = thirtyDaysAgo.toISOString();
        
        // Delete logs older than 30 days
        const deletedCount = await db.auditLogs.where('timestamp').below(limitISO).delete();
        if (deletedCount > 0) {
            console.log(`System Cleanup: Removed ${deletedCount} old audit logs.`);
        }
    } catch (error) {
        console.error("Error pruning logs:", error);
    }
};

// Helper to seed initial data if empty
export const seedDatabase = async () => {
  // Run cleanup on startup
  await pruneOldLogs();

  // Seed Admin User
  const userCount = await db.users.count();
  if (userCount === 0) {
    await db.users.add({
      username: 'admin',
      passwordHash: 'admin123',
      role: UserRole.ADMIN,
      createdAt: new Date().toISOString()
    });
  }
};

export const logAudit = async (username: string, action: string, details: string) => {
  await db.auditLogs.add({
    username,
    action,
    details,
    timestamp: new Date().toISOString()
  });
};

// --- IMPORT / EXPORT SYSTEM ---

export const exportDatabase = async () => {
    const data = {
        users: await db.users.toArray(),
        departments: await db.departments.toArray(),
        goals: await db.goals.toArray(),
        weeklyReports: await db.weeklyReports.toArray(),
        auditLogs: await db.auditLogs.toArray(),
        projects: await db.projects.toArray(),
        reminders: await db.reminders.toArray(),
        reportTemplates: await db.reportTemplates.toArray(),
        timestamp: new Date().toISOString(),
        version: "1.2"
    };
    return JSON.stringify(data, null, 2);
};

export const importDatabase = async (jsonString: string) => {
    try {
        const data = JSON.parse(jsonString);
        
        if (!data.users || !data.departments || !data.goals) {
            throw new Error("Formato de archivo inválido");
        }

        await (db as any).transaction('rw', [
            db.users, db.departments, db.goals, db.weeklyReports, 
            db.auditLogs, db.projects, db.reminders, db.reportTemplates
        ], async () => {
            // Clear existing data
            await db.users.clear();
            await db.departments.clear();
            await db.goals.clear();
            await db.weeklyReports.clear();
            await db.auditLogs.clear();
            await db.projects.clear();
            await db.reminders.clear();
            await db.reportTemplates.clear();

            // Bulk add new data
            // Note: bulkAdd keeps the IDs from the objects if provided, ensuring relationships (parentId, deptId) are preserved.
            await db.users.bulkAdd(data.users);
            await db.departments.bulkAdd(data.departments);
            await db.goals.bulkAdd(data.goals);
            if(data.weeklyReports) await db.weeklyReports.bulkAdd(data.weeklyReports);
            if(data.auditLogs) await db.auditLogs.bulkAdd(data.auditLogs);
            if(data.projects) await db.projects.bulkAdd(data.projects);
            if(data.reminders) await db.reminders.bulkAdd(data.reminders);
            if(data.reportTemplates) await db.reportTemplates.bulkAdd(data.reportTemplates);
        });
        
        return true;
    } catch (error) {
        console.error("Import Error:", error);
        throw error;
    }
};
