import React, { ReactNode } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState;
  public props: ErrorBoundaryProps;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
    this.props = props;
  }

  static getDerivedStateFromError(error: any): ErrorBoundaryState {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
          <div className="bg-white p-8 rounded-xl shadow-2xl max-w-lg w-full border-l-4 border-red-500">
             <h1 className="text-2xl font-black text-slate-800 mb-4">¡Ups! Algo salió mal.</h1>
             <p className="text-slate-600 mb-4">El sistema ha detectado un error crítico y no puede continuar.</p>
             <div className="bg-red-50 p-4 rounded text-xs text-red-800 font-mono overflow-auto mb-6">
                {this.state.error?.message}
             </div>
             <button onClick={() => window.location.reload()} className="bg-slate-800 text-white px-4 py-2 rounded font-bold hover:bg-slate-900 transition-colors">
                Recargar Sistema
             </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);

// AI Studio always uses an `index.tsx` file for all project types.
