
import React, { useEffect, useState, createContext, useContext } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation, Link, useNavigate } from 'react-router-dom';
import { db, seedDatabase, logAudit } from './services/db';
import { User, ALCALDIA_LOGO_URL } from './types';
import LoginView from './views/LoginView';
import HallView from './views/HallView';
import MatrixView from './views/MatrixView';
import ReportsCenter from './views/ReportsCenter';
import UsersControlView from './views/UsersControlView';
import Sidebar from './components/Sidebar';
import { Menu, LogOut, Clock, ChevronRight, Search, Command, ArrowRight } from 'lucide-react';
import { useLiveQuery } from 'dexie-react-hooks';

// --- TOAST SYSTEM (UX #4) ---
interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

export const ToastContext = createContext<{ showToast: (msg: string, type?: 'success' | 'error' | 'info') => void } | null>(null);

const ToastProvider = ({ children }: { children?: React.ReactNode }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2">
        {toasts.map(t => (
          <div key={t.id} className={`px-4 py-3 rounded-lg shadow-lg text-white text-sm font-medium animate-in slide-in-from-right flex items-center gap-2 ${t.type === 'error' ? 'bg-red-500' : t.type === 'info' ? 'bg-blue-500' : 'bg-green-500'}`}>
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

// --- Institutional Clock ---
const InstitutionalClock = () => {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    const dateStr = time.toLocaleDateString('es-VE', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    
    const formattedDate = dateStr.charAt(0).toUpperCase() + dateStr.slice(1);
    const timeStr = time.toLocaleTimeString('es-VE');

    return (
        <div className="flex flex-col items-end text-right">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">El Vigía, {formattedDate}</span>
            <div className="flex items-center gap-1 text-slate-700 font-mono text-sm font-bold">
                <Clock size={12} className="text-blue-600" /> {timeStr}
            </div>
        </div>
    );
};

// --- BREADCRUMBS (UX #2) ---
const Breadcrumbs = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter((x) => x);
  
  // Use DB to resolve department names if in Matrix
  const deptId = pathnames[0] === 'matrix' ? Number(pathnames[1]) : null;
  const dept = useLiveQuery(() => deptId ? db.departments.get(deptId) : null, [deptId]);

  const breadcrumbNameMap: Record<string, string> = {
    hall: 'Dashboard',
    matrix: 'Matriz de Gestión',
    reports: 'Reportes',
    users: 'Seguridad'
  };

  return (
    <div className="flex items-center text-xs text-slate-500 mb-0.5">
       <Link to="/hall" className="hover:text-blue-600 transition-colors">Inicio</Link>
       {pathnames.map((value, index) => {
          if (value === 'matrix' && dept) return null; // Skip "matrix" word if we show dept name next
          if (!isNaN(Number(value))) return null; // Skip IDs, handle via DB fetch

          const to = `/${pathnames.slice(0, index + 1).join('/')}`;
          const isLast = index === pathnames.length - 1;
          const name = breadcrumbNameMap[value] || value;

          return (
             <React.Fragment key={to}>
                <ChevronRight size={10} className="mx-1" />
                {isLast && !dept ? (
                   <span className="font-bold text-slate-700">{name}</span>
                ) : (
                   <Link to={to} className="hover:text-blue-600 transition-colors">{name}</Link>
                )}
             </React.Fragment>
          );
       })}
       {dept && (
          <>
             <ChevronRight size={10} className="mx-1" />
             <span className="font-bold text-slate-700 truncate max-w-[200px]">{dept.name}</span>
          </>
       )}
    </div>
  );
};

// --- COMMAND PALETTE (Search/Nav #1) ---
const CommandPalette = () => {
    const [open, setOpen] = useState(false);
    const [query, setQuery] = useState('');
    const navigate = useNavigate();
    const departments = useLiveQuery(() => db.departments.toArray());
    
    useEffect(() => {
        const down = (e: KeyboardEvent) => {
            if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                setOpen((open) => !open);
            }
        };
        document.addEventListener('keydown', down);
        return () => document.removeEventListener('keydown', down);
    }, []);

    if (!open) return null;

    const filteredDepts = departments?.filter(d => 
        d.name.toLowerCase().includes(query.toLowerCase())
    ).slice(0, 5) || [];

    const handleSelect = (path: string) => {
        setOpen(false);
        setQuery('');
        navigate(path);
        
        // Save to History (Search/Nav #3)
        if(path.includes('matrix')) {
            const history = JSON.parse(localStorage.getItem('siga_search_history') || '[]');
            const dept = departments?.find(d => `/matrix/${d.id}` === path);
            if(dept) {
                const newHistory = [dept, ...history.filter((h: any) => h.id !== dept.id)].slice(0, 5);
                localStorage.setItem('siga_search_history', JSON.stringify(newHistory));
            }
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-start justify-center pt-[20vh]" onClick={() => setOpen(false)}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95" onClick={e => e.stopPropagation()}>
                <div className="flex items-center border-b p-4 gap-3">
                    <Search className="text-slate-400" />
                    <input 
                        className="flex-1 text-lg outline-none placeholder:text-slate-400"
                        placeholder="Comando o Gerencia..."
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        autoFocus
                    />
                    <div className="text-xs text-slate-400 border px-2 py-1 rounded">ESC</div>
                </div>
                <div className="p-2">
                    {query === '' && (
                        <div className="text-xs text-slate-500 p-2 font-bold uppercase tracking-wider">Sugerencias</div>
                    )}
                    {query === '' && (
                        <>
                           <button onClick={() => handleSelect('/hall')} className="w-full text-left p-3 hover:bg-slate-100 rounded flex items-center gap-3">
                               <Command size={16}/> Dashboard Principal
                           </button>
                           <button onClick={() => handleSelect('/reports')} className="w-full text-left p-3 hover:bg-slate-100 rounded flex items-center gap-3">
                               <Command size={16}/> Centro de Reportes
                           </button>
                        </>
                    )}
                    
                    {filteredDepts.length > 0 && (
                        <div className="text-xs text-slate-500 p-2 font-bold uppercase tracking-wider mt-2">Dependencias</div>
                    )}
                    {filteredDepts.map(d => (
                        <button key={d.id} onClick={() => handleSelect(`/matrix/${d.id}`)} className="w-full text-left p-3 hover:bg-slate-100 rounded flex items-center justify-between group">
                            <span className="font-medium text-slate-700">{d.name}</span>
                            <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 text-slate-400"/>
                        </button>
                    ))}
                    {query && filteredDepts.length === 0 && (
                        <div className="p-8 text-center text-slate-400">No se encontraron resultados.</div>
                    )}
                </div>
            </div>
        </div>
    );
};

// --- LAYOUT & AUTO-LOGOUT (Security #1) ---
const Layout = ({ children, user, onLogout }: { children?: React.ReactNode, user: User, onLogout: () => void }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  // Auto Logout Logic
  useEffect(() => {
      let timeoutId: ReturnType<typeof setTimeout>;
      const resetTimer = () => {
          clearTimeout(timeoutId);
          timeoutId = setTimeout(() => {
              alert("Sesión cerrada por inactividad (15 min).");
              onLogout();
          }, 15 * 60 * 1000); // 15 mins
      };
      
      window.addEventListener('mousemove', resetTimer);
      window.addEventListener('keydown', resetTimer);
      resetTimer();

      return () => {
          clearTimeout(timeoutId);
          window.removeEventListener('mousemove', resetTimer);
          window.removeEventListener('keydown', resetTimer);
      };
  }, [onLogout]);

  return (
    <div className="flex h-screen overflow-hidden">
      <div className={`${isSidebarOpen ? 'w-72' : 'w-0'} transition-all duration-300 flex flex-col shadow-2xl overflow-hidden glass-sidebar text-white z-20`}>
        <Sidebar user={user} />
      </div>

      <div className="flex-1 flex flex-col overflow-hidden relative">
        <CommandPalette />
        <header className="glass-panel h-16 flex items-center justify-between px-6 z-10 m-3 rounded-xl sticky top-3">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-white/50 rounded-lg text-slate-600 transition-colors">
              <Menu size={22} />
            </button>
            <div className="flex flex-col border-l border-slate-300 pl-4 justify-center">
                 <Breadcrumbs />
                 <h1 className="font-extrabold text-slate-800 text-sm leading-none tracking-tight">Sistema Integrado de Gestión y Auditoría de Gobierno V1.0</h1>
            </div>
          </div>

          <div className="flex items-center gap-6">
             <div className="hidden lg:block border-r border-slate-300 pr-6">
                 <InstitutionalClock />
             </div>
             
             <div className="flex items-center gap-3">
                 <div className="text-right hidden sm:block">
                    <p className="text-sm font-bold text-slate-800">{user.username}</p>
                    <p className="text-[10px] bg-blue-100 text-blue-700 px-2 rounded-full inline-block font-bold uppercase">{user.role}</p>
                 </div>
                 <button 
                   onClick={onLogout}
                   className="p-2.5 bg-red-50 text-red-600 hover:bg-red-500 hover:text-white rounded-lg transition-all shadow-sm"
                   title="Cerrar Sesión"
                 >
                   <LogOut size={18} />
                 </button>
             </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-3 pt-0 relative">
           {children}
        </main>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        await seedDatabase();
        const storedUser = localStorage.getItem('siga_user');
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } catch (e) {
        console.error("Database init error:", e);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, []);

  const handleLogin = async (u: User) => {
    localStorage.setItem('siga_user', JSON.stringify(u));
    setUser(u);
    await logAudit(u.username, 'LOGIN', 'Ingreso exitoso al sistema');
  };

  const handleLogout = () => {
    localStorage.removeItem('siga_user');
    setUser(null);
  };

  if (loading) return <div className="h-screen w-screen flex items-center justify-center bg-slate-900 text-white font-bold tracking-widest">CARGANDO SISTEMA...</div>;

  return (
    <Router>
      <ToastProvider>
        {!user ? (
          <LoginView onLogin={handleLogin} />
        ) : (
          <Layout user={user} onLogout={handleLogout}>
            <Routes>
              <Route path="/" element={<Navigate to="/hall" replace />} />
              <Route path="/hall" element={<HallView />} />
              <Route path="/matrix/:deptId" element={<MatrixView currentUser={user} />} />
              <Route path="/reports" element={<ReportsCenter currentUser={user} />} />
              <Route path="/users" element={<UsersControlView currentUser={user} />} />
              <Route path="*" element={<Navigate to="/hall" replace />} />
            </Routes>
          </Layout>
        )}
      </ToastProvider>
    </Router>
  );
};

export default App;
