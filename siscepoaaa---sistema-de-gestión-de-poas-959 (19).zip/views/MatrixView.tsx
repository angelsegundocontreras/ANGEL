
import React, { useState, useRef, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, logAudit } from '../services/db';
import { Goal, User, UserRole, WeeklyReport, ActivityDetail, Project } from '../types';
import { 
  Save, Plus, FileText, Calendar, Send, Settings, 
  MessageCircle, CheckCircle2, History, User as UserIcon,
  ChevronDown, ChevronUp, Printer, Target, Shield, MapPin, X, BookOpen, Eye, Edit2, UploadCloud, Download, DownloadCloud, Lock, Unlock, GripVertical, Briefcase, FileType, Check, ArrowLeftRight, Trash2
} from 'lucide-react';
import { ToastContext } from '../App';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ALCALDIA_LOGO_URL } from '../types';
import * as XLSX from 'xlsx';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

interface MatrixViewProps {
  currentUser: User;
}

// Helper interface for the specific form with dynamic keys
interface GoogleFormState {
    reporterName: string;
    email: string;
    observations: string;
    other_poa: string;
    other_no_poa: string;
    [key: string]: string; // Allow dynamic access for metas 1-15
}

const PASTEL_COLORS = [
    'bg-slate-50 border-slate-200',
    'bg-blue-50/50 border-blue-100',
    'bg-green-50/50 border-green-100',
    'bg-orange-50/50 border-orange-100',
    'bg-purple-50/50 border-purple-100',
    'bg-teal-50/50 border-teal-100'
];

// --- FUZZY MATCHING HELPERS ---
const normalizeText = (text: string) => {
    return text ? text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim() : "";
};

const getLevenshteinDistance = (a: string, b: string) => {
    const matrix = [];
    for (let i = 0; i <= b.length; i++) matrix[i] = [i];
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;

    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j] + 1
                );
            }
        }
    }
    return matrix[b.length][a.length];
};

const MatrixView: React.FC<MatrixViewProps> = ({ currentUser }) => {
  const { deptId } = useParams();
  const id = Number(deptId);
  const { showToast } = React.useContext(ToastContext)!;

  const dept = useLiveQuery(() => db.departments.get(id), [id]);
  const goals = useLiveQuery<Goal[]>(() => db.goals.where('deptId').equals(id).sortBy('order'), [id]);
  const reports = useLiveQuery(() => db.weeklyReports.where('deptId').equals(id).reverse().toArray(), [id]);
  const projects = useLiveQuery(() => db.projects.where('deptId').equals(id).toArray(), [id]);

  // States
  const [activeTab, setActiveTab] = useState<'POA' | 'PROJECTS'>('POA');
  const [showReportModal, setShowReportModal] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [isHeaderExpanded, setIsHeaderExpanded] = useState(false);
  
  // Quarter Locking Logic (Matrix #9)
  const currentMonth = new Date().getMonth();
  const [adminUnlock, setAdminUnlock] = useState(false);
  
  const isLocked = (quarter: number) => {
      if(adminUnlock) return false;
      if (quarter === 1 && currentMonth > 2) return true;
      if (quarter === 2 && currentMonth > 5) return true;
      if (quarter === 3 && currentMonth > 8) return true;
      return false; // Q4 closes at year end
  };
  
  // Inline Execution Editing
  const [editingGoalId, setEditingGoalId] = useState<number | null>(null);
  const [editValues, setEditValues] = useState<any>({});
  
  const [expandedReportId, setExpandedReportId] = useState<number | null>(null);

  // States for New/Edit Report
  const [editingReportId, setEditingReportId] = useState<number | null>(null);
  const [newReport, setNewReport] = useState<Partial<WeeklyReport>>({
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      executiveSummary: '',
      activities: []
  });

  // Specific Google Form State
  const [formState, setFormState] = useState<GoogleFormState>({
      reporterName: '',
      email: '',
      observations: '',
      other_poa: '',
      other_no_poa: ''
  });
  
  const [editDeptValues, setEditDeptValues] = useState<any>({});
  
  // State for New/Edit Goal
  const [editingGoalObj, setEditingGoalObj] = useState<Goal | null>(null);
  const [newGoal, setNewGoal] = useState<Partial<Goal>>({
      description: '',
      verificationMeans: '',
      t1_plan: 0, t2_plan: 0, t3_plan: 0, t4_plan: 0,
      t1_exec: 0, t2_exec: 0, t3_exec: 0, t4_exec: 0,
      isExtra: false,
      unit: 'Unidad'
  });

  // State for New/Edit Project (Module #4)
  const [editingProject, setEditingProject] = useState<Partial<Project>>({
      name: '', description: '', status: 'PLANIFICADO', progress: 0, budget: 0, startDate: '', endDate: ''
  });
  const [editingProjectId, setEditingProjectId] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleWhatsAppReminder = async () => {
      if (!dept) return;
      if (!dept.phone) {
          showToast("Esta gerencia no tiene número de teléfono registrado.", "error");
          return;
      }
      const phone = dept.phone.replace(/\D/g, ''); 
      const message = `Estimado(a) ${dept.managerName}, reciba un cordial saludo. Se le recuerda realizar el envió de sus actividades semanales y avances para cargar el sistema SISCEPOAAA para el corte de gestión. Recuerde que la hora estipulada es antes de las 02 de la tarde todos los viernes.\n\nAtentamente, la Gerencia General.`;
      const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
      window.open(url, '_blank');
      await logAudit(currentUser.username, 'WHATSAPP_REMINDER', `Recordatorio enviado a ${dept.managerName} (${dept.phone})`);
  };

  const handleDownloadTemplate = () => {
      if (!dept) return;
      
      // Dynamic Headers for 15 Metas
      const metaHeaders: any = {};
      for(let i=1; i<=15; i++) {
          metaHeaders[`Describa la Meta Producto ${i}:`] = "";
          metaHeaders[`¿Qué logró en relación a la Meta Producto ${i} durante este período?`] = "";
      }

      const headers = [
          {
              "Marca temporal": "",
              "Dirección de correo electrónico": "",
              "Dependencia o Instituto que representa": dept.name, // Fixed column name match
              "Nombre de la persona que carga la informacin": "",
              "Fecha de Inicio del Período de Informe:": new Date().toISOString().split('T')[0],
              "Fecha de Fin del Período de Informe:": new Date().toISOString().split('T')[0],
              ...metaHeaders,
              "Si ha realizado otras actividades, vinculadas al POA, describalas con detalle:": "",
              "Cargue al menos 5 imagenes de las actividades mas resaltantes de esta semana:": "",
              "Si ha realizado otras actividades, no vinculadas al POA pero que considera que son de interes, describalas:": "",
              "Observaciones (alguna información adicional que considere relevante):": ""
          }
      ];
      const ws = XLSX.utils.json_to_sheet(headers);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Respuestas de formulario 1");
      XLSX.writeFile(wb, `Plantilla_GoogleForm_${dept.name.substring(0,10)}.xlsx`);
      showToast("Plantilla descargada con formato Google Forms.", "success");
  };

  // --- EXCEL IMPORT LOGIC ---
  const handleImportExcelClick = () => {
      fileInputRef.current?.click();
  };
  
  // --- WORD EXPORT (Export #1) ---
  const handleExportWord = () => {
      if(!goals || !dept) return;
      
      const tableContent = `
        <h2 style="text-align: center; font-family: Arial;">MATRIZ DE METAS FÍSICAS - POA 2026</h2>
        <h3 style="text-align: center; font-family: Arial;">${dept.name}</h3>
        <table border="1" style="width: 100%; border-collapse: collapse; font-family: Arial; font-size: 10px;">
          <tr style="background-color: #ddd;">
            <th>Meta / Actividad</th>
            <th>Unidad</th>
            <th>Medios Verif.</th>
            <th>T1 Plan</th><th>T1 Ejec</th>
            <th>T2 Plan</th><th>T2 Ejec</th>
            <th>T3 Plan</th><th>T3 Ejec</th>
            <th>T4 Plan</th><th>T4 Ejec</th>
          </tr>
          ${goals.map(g => `
            <tr>
              <td>${g.description}</td>
              <td>${g.unit}</td>
              <td>${g.verificationMeans || ''}</td>
              <td>${g.t1_plan}</td><td>${g.t1_exec}</td>
              <td>${g.t2_plan}</td><td>${g.t2_exec}</td>
              <td>${g.t3_plan}</td><td>${g.t3_exec}</td>
              <td>${g.t4_plan}</td><td>${g.t4_exec}</td>
            </tr>
          `).join('')}
        </table>
      `;
      
      const html = `<html><head><meta charset="utf-8"></head><body>${tableContent}</body></html>`;
      const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `POA_${dept.name}.doc`;
      link.click();
      showToast("Documento Word generado", "success");
  };
  
  // --- DRAG AND DROP (Goals #8) ---
  const handleOnDragEnd = async (result: any) => {
      if(!result.destination || !goals) return;
      const reorderedGoals = Array.from(goals);
      const [reorderedItem] = reorderedGoals.splice(result.source.index, 1);
      reorderedGoals.splice(result.destination.index, 0, reorderedItem);
      
      // Update local state optimistic (Dexie handles it via liveQuery but let's update order)
      await Promise.all(reorderedGoals.map((g: Goal, index) => 
          db.goals.update(g.id!, { order: index })
      ));
  };

  const handleDeleteGoal = async (goalId: number) => {
      // 1. Security Check
      const key = prompt("🔐 SEGURIDAD: Ingrese la CLAVE DE AUTORIZACIÓN (14401308) para eliminar este registro:");
      
      if (key !== "14401308") {
          if (key !== null) showToast("⛔ Clave incorrecta. Acción denegada.", "error");
          return;
      }
      
      // 2. Perform deletion immediately
      await db.goals.delete(goalId);
      await logAudit(currentUser.username, 'DELETE_GOAL', `Eliminada Meta ID ${goalId}`);
      showToast("Meta eliminada correctamente", "success");
  };

  const handleDeleteReport = async (reportId: number) => {
      if (window.confirm("¿Está seguro que desea eliminar este reporte semanal completo? Esta acción es irreversible.")) {
          try {
              await db.weeklyReports.delete(reportId);
              await logAudit(currentUser.username, 'DELETE_REPORT', `Eliminado reporte ID ${reportId}`);
              showToast("Semana eliminada exitosamente", "success");
          } catch (e) {
              showToast("Error al eliminar el reporte", "error");
          }
      }
  };

  const processExcelFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = async (evt) => {
          try {
              const bstr = evt.target?.result;
              const wb = XLSX.read(bstr, { type: 'binary' });
              const wsname = wb.SheetNames[0];
              const ws = wb.Sheets[wsname];
              const rawData = XLSX.utils.sheet_to_json(ws);
              
              if (!rawData || rawData.length === 0) {
                  showToast("El archivo Excel está vacío", "error");
                  return;
              }

              // Load all departments for matching
              const allDepartments = await db.departments.toArray();
              
              // Helper to find value in row fuzzy-matching the header key (ignoring case, accents, etc)
              // We search the row keys for keywords like "Dependencia o Instituto"
              const getVal = (row: any, keywordToMatch: string) => {
                  const normalizedKeyword = normalizeText(keywordToMatch);
                  const foundKey = Object.keys(row).find(k => normalizeText(k).includes(normalizedKeyword));
                  return foundKey ? row[foundKey] : null;
              };

              // --- 1. SORT CHRONOLOGICALLY ---
              // Requirement: The system must read row by row chronologically.
              const data = (rawData as any[]).sort((a, b) => {
                  const dateAStr = getVal(a, "Fecha de Inicio");
                  const dateBStr = getVal(b, "Fecha de Inicio");
                  
                  const dateA = dateAStr ? (typeof dateAStr === 'number' ? dateAStr : new Date(dateAStr).getTime()) : 0;
                  const dateB = dateBStr ? (typeof dateBStr === 'number' ? dateBStr : new Date(dateBStr).getTime()) : 0;
                  
                  return dateA - dateB;
              });

              let importedCount = 0;
              let matchedDeptsCount = 0;

              for (const row of data) {
                  // Requirement: Match by specific column name "Dependencia o Instituto"
                  const deptNameInRow = getVal(row, "Dependencia o Instituto que representa");
                  
                  if (!deptNameInRow) continue;

                  const normalizedRowName = normalizeText(String(deptNameInRow));
                  
                  // --- ADVANCED MATCHING LOGIC (Levenshtein + Normalization) ---
                  // Requirement: Handle "ofcina", "Coordinación" vs "Coordinacion", etc.
                  let bestMatch = null;
                  let lowestDistance = Infinity;

                  for (const dept of allDepartments) {
                      const normalizedDbName = normalizeText(dept.name);
                      
                      // 1. Exact contains match (most accurate for simple transcription diffs)
                      if (normalizedDbName.includes(normalizedRowName) || normalizedRowName.includes(normalizedDbName)) {
                          // Prioritize longest match to avoid matching "Gerencia General" to "Coordinacion de Gerencia General"
                          // We want the most specific one. 
                          // However, usually the DB name is the source of truth.
                          // If we have an 'exact' containment, we consider it a very strong candidate.
                          // But we still check Levenshtein to be sure.
                      }

                      // 2. Levenshtein Distance
                      const dist = getLevenshteinDistance(normalizedRowName, normalizedDbName);
                      
                      // Calculate Threshold: We allow some typos
                      // Threshold is 40% of the longer string length.
                      const maxLength = Math.max(normalizedRowName.length, normalizedDbName.length);
                      const threshold = maxLength * 0.4; 

                      if (dist < lowestDistance && dist < threshold) {
                          lowestDistance = dist;
                          bestMatch = dept;
                      }
                  }

                  const targetDept = bestMatch;

                  if (!targetDept) continue;

                  matchedDeptsCount++;

                  // Extract Dates
                  const startDateRaw = getVal(row, "Fecha de Inicio del Período de Informe");
                  const endDateRaw = getVal(row, "Fecha de Fin del Período de Informe");
                  
                  let startStr = new Date().toISOString();
                  if(startDateRaw) {
                      const d = typeof startDateRaw === 'number' ? new Date(Date.UTC(1899, 11, 30) + startDateRaw * 24 * 60 * 60 * 1000) : new Date(startDateRaw);
                      if(!isNaN(d.getTime())) startStr = d.toISOString();
                  }

                  let endStr = new Date().toISOString();
                  if(endDateRaw) {
                      const d = typeof endDateRaw === 'number' ? new Date(Date.UTC(1899, 11, 30) + endDateRaw * 24 * 60 * 60 * 1000) : new Date(endDateRaw);
                      if(!isNaN(d.getTime())) endStr = d.toISOString();
                  }
                  
                  const email = getVal(row, "Dirección de correo electrónico") || '';
                  const observations = getVal(row, "Observaciones") || '';
                  const reporterName = getVal(row, "Nombre de la persona que carga") || 'Desconocido';

                  // Check for existing report in DB
                  let report = await db.weeklyReports.where({ deptId: targetDept.id!, startDate: startStr.split('T')[0] }).first();
                  let reportId = report?.id;

                  const summary = `Cargado por: ${reporterName}. ${email ? `| Email: ${email}` : ''}`;

                  // Create report if it doesn't exist for this week
                  if (!report) {
                      reportId = await db.weeklyReports.add({
                          deptId: targetDept.id!,
                          startDate: startStr.split('T')[0],
                          endDate: endStr.split('T')[0],
                          executiveSummary: summary,
                          activities: [],
                          classification: 'Operativo',
                          observations: observations,
                          createdAt: new Date().toISOString(),
                          createdBy: currentUser.username
                      });
                  }

                  // Process Activities from Row based on Specific Headers
                  const newActivities: ActivityDetail[] = [];

                  // Loop through 15 Metas
                  for(let i=1; i<=15; i++) {
                      // Header: "Describa la Meta Producto X:"
                      const desc = getVal(row, `Describa la Meta Producto ${i}`);
                      
                      if (desc) {
                          // Header: "¿Qué logró en relación a la Meta Producto X..."
                          const achievement = getVal(row, `Qué logró en relación a la Meta Producto ${i}`) || '';
                          
                          newActivities.push({
                              date: endStr,
                              title: `Meta Producto ${i}`,
                              description: `${desc} | Logro: ${achievement}`,
                              priority: 'Normal'
                          });
                      }
                  }

                  // Header: "Si ha realizado otras actividades, vinculadas al POA..."
                  const extraPOA = getVal(row, "actividades, vinculadas al POA");
                  if(extraPOA) {
                      newActivities.push({
                          date: endStr,
                          title: 'Actividad Vinculada POA',
                          description: extraPOA,
                          priority: 'Normal'
                      });
                  }

                  // Header: "Si ha realizado otras actividades, no vinculadas al POA..."
                  const extraNoPOA = getVal(row, "no vinculadas al POA");
                  if(extraNoPOA) {
                      newActivities.push({
                          date: endStr,
                          title: 'Actividad Extra (No POA)',
                          description: extraNoPOA,
                          priority: 'Normal'
                      });
                  }
                  
                  // Requirement: Overwrite existing activities for this week with the latest data from the row
                  if (reportId && newActivities.length > 0) {
                      await db.weeklyReports.update(reportId, { 
                          activities: newActivities,
                          observations: observations || report?.observations,
                          executiveSummary: summary // Update summary in case reporter changed
                      });
                      importedCount += newActivities.length;
                  }
              }

              if (importedCount > 0) {
                  showToast(`Importación Exitosa: Se procesaron ${importedCount} actividades en ${matchedDeptsCount} gerencias detectadas.`, "success");
                  await logAudit(currentUser.username, 'IMPORT_BULK', `Importación masiva: ${importedCount} actividades`);
                  setTimeout(() => window.location.reload(), 2000);
              } else {
                  showToast("No se encontraron actividades nuevas o válidas en el archivo.", "info");
              }

          } catch (error) {
              console.error(error);
              showToast("Error al procesar el archivo Excel.", "error");
          }
      };
      reader.readAsBinaryString(file);
      e.target.value = '';
  };


  const generatePOAPDF = async () => {
      if (!dept || !goals) return;
      const doc = new jsPDF({ orientation: 'landscape' });

      try {
          const response = await fetch(ALCALDIA_LOGO_URL);
          const blob = await response.blob();
          const reader = new FileReader();
          reader.readAsDataURL(blob);
          await new Promise(resolve => reader.onloadend = resolve);
          const base64data = reader.result as string;
          doc.addImage(base64data, 'PNG', 15, 10, 25, 25);
      } catch (e) { console.log('Logo load failed'); }

      // Get Parent Dept for Offices
      const parentDept = dept.parentId ? await db.departments.get(dept.parentId) : null;

      // Determine Role Title
      let roleTitle = "RESPONSABLE";
      if (dept.type === 'INSTITUTE') {
          roleTitle = "PRESIDENTE";
      } else if (dept.type === 'DEPENDENCY') {
          roleTitle = "GERENTE";
      } else if (dept.type === 'OFFICE') {
          if (dept.name.toLowerCase().includes('coordinaci')) {
              roleTitle = "COORDINADOR";
          } else {
              roleTitle = "JEFE DE OFICINA";
          }
      }

      doc.setFontSize(14); doc.setFont("helvetica", "bold");
      doc.text("ALCALDÍA DEL MUNICIPIO ALBERTO ADRIANI", 148, 15, { align: 'center' });
      doc.setFontSize(10); 
      doc.text("SISTEMA DE PLANIFICACIÓN Y CONTROL DE GESTIÓN", 148, 20, { align: 'center' });
      doc.text("MATRIZ DE METAS FÍSICAS - POA 2026", 148, 25, { align: 'center' });

      doc.setFontSize(10); doc.text(`${dept.type === 'INSTITUTE' ? 'INSTITUTO' : dept.type === 'OFFICE' ? 'OFICINA/COORDINACIÓN' : 'GERENCIA'}: ${dept.name.toUpperCase()}`, 15, 45);
      
      if (parentDept) {
          doc.text(`ADSCRITA A: ${parentDept.name.toUpperCase()}`, 15, 50);
          doc.text(`${roleTitle}: ${dept.managerName.toUpperCase()}`, 15, 55);
      } else {
          doc.text(`${roleTitle}: ${dept.managerName.toUpperCase()}`, 15, 50);
      }

      const tableData = goals.map(g => {
         const plan = Number(g.t1_plan) + Number(g.t2_plan) + Number(g.t3_plan) + Number(g.t4_plan);
         const exec = Number(g.t1_exec) + Number(g.t2_exec) + Number(g.t3_exec) + Number(g.t4_exec);
         const perc = plan > 0 ? Math.round((exec/plan)*100) : 0;
         return [
             g.description,
             g.unit,
             g.t1_plan, g.t1_exec,
             g.t2_plan, g.t2_exec,
             g.t3_plan, g.t3_exec,
             g.t4_plan, g.t4_exec,
             plan, exec, `${perc}%`
         ];
      });

      autoTable(doc, {
          startY: parentDept ? 60 : 55,
          head: [[
              'Descripción de la Meta', 'Unidad', 
              'P. T1', 'E. T1', 'P. T2', 'E. T2', 'P. T3', 'E. T3', 'P. T4', 'E. T4',
              'Total P', 'Total E', '%'
          ]],
          body: tableData,
          theme: 'grid',
          styles: { fontSize: 8 },
          headStyles: { fillColor: [20, 50, 90], textColor: 255, halign: 'center' },
          margin: { left: 15, right: 15 }
      });

      doc.save(`POA_2026_${dept.name.substring(0,10)}.pdf`);
      showToast("Reporte POA generado correctamente", "success");
  };

  const generateWeeklyPDF = async (report: WeeklyReport) => {
      if(!dept) return;
      const doc = new jsPDF();
      
      const finishPdf = () => {
          doc.setFontSize(14); doc.setFont("times", "bold");
          doc.text("REPORTE DE ACTIVIDADES SEMANALES", 105, 20, {align:'center'});
          doc.setFontSize(10); doc.setFont("helvetica", "normal");
          doc.text(`GERENCIA: ${dept.name.toUpperCase()}`, 105, 28, {align:'center'});
          doc.text(`PERIODO: ${new Date(report.startDate).toLocaleDateString()} AL ${new Date(report.endDate).toLocaleDateString()}`, 105, 34, {align:'center'});

          doc.setFontSize(10); doc.setFont("helvetica", "bold"); doc.text("RESUMEN EJECUTIVO:", 14, 45);
          doc.setFont("helvetica", "normal"); doc.text(report.executiveSummary || "Sin resumen", 14, 50, {maxWidth: 180});

          if(report.observations) {
              doc.setFont("helvetica", "bold"); doc.text("OBSERVACIONES:", 14, 60);
              doc.setFont("helvetica", "normal"); doc.text(report.observations, 14, 65, {maxWidth: 180});
          }

          autoTable(doc, {
              startY: report.observations ? 80 : 65,
              head: [['Fecha', 'Actividad', 'Detalle / Descripción']],
              body: report.activities.map(a => [new Date(a.date).toLocaleDateString(), a.title, a.description]),
              headStyles: { fillColor: [20, 50, 90], halign: 'center' }, theme: 'grid'
          });
          doc.save(`Reporte_Semanal_${dept.name.substring(0,10)}_${report.startDate}.pdf`);
      };

      try {
        const response = await fetch(ALCALDIA_LOGO_URL);
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
             const base64data = reader.result as string;
             doc.addImage(base64data, 'PNG', 15, 10, 20, 20);
             finishPdf();
        };
        reader.readAsDataURL(blob);
      } catch (e) { finishPdf(); }
  };

  const handleSaveGoalExecEdit = async (goalId: number) => {
      if (!goals) return;
      const goal = goals.find(g => g.id === goalId);
      if (!goal) return;

      await db.goals.update(goalId, { ...editValues, lastUpdated: new Date().toISOString() });
      setEditingGoalId(null); setEditValues({});
      showToast("Avances de meta actualizados correctamente", "success");
      await logAudit(currentUser.username, 'UPDATE_GOAL_EXEC', `Actualizada ejecución meta ID ${goalId}`);
  };

  const handleOpenGoalModal = (goalToEdit?: Goal) => {
      if (goalToEdit) {
          setEditingGoalObj(goalToEdit);
          setNewGoal({ ...goalToEdit });
      } else {
          setEditingGoalObj(null);
          setNewGoal({ description: '', verificationMeans: '', unit: 'Unidad', t1_plan:0, t2_plan:0, t3_plan:0, t4_plan:0, isExtra: false });
      }
      setShowGoalModal(true);
  };
  
  const handleOpenProjectModal = (project?: Project) => {
      if(project) {
          setEditingProjectId(project.id!);
          setEditingProject({...project});
      } else {
          setEditingProjectId(null);
          setEditingProject({ name: '', description: '', status: 'PLANIFICADO', progress: 0, budget: 0, startDate: '', endDate: '' });
      }
      setShowProjectModal(true);
  };

  const handleSaveGoal = async () => {
      if (!newGoal.description) { showToast("La descripción es obligatoria", "error"); return; }
      
      const nextOrder = goals ? goals.length : 0;
      
      const goalData = {
          deptId: id,
          description: newGoal.description!,
          unit: newGoal.unit || 'Unidad',
          verificationMeans: newGoal.verificationMeans || '',
          isExtra: newGoal.isExtra || false,
          t1_plan: Number(newGoal.t1_plan), 
          t2_plan: Number(newGoal.t2_plan), 
          t3_plan: Number(newGoal.t3_plan), 
          t4_plan: Number(newGoal.t4_plan),
          t1_exec: editingGoalObj ? Number(newGoal.t1_exec!) : 0,
          t2_exec: editingGoalObj ? Number(newGoal.t2_exec!) : 0,
          t3_exec: editingGoalObj ? Number(newGoal.t3_exec!) : 0,
          t4_exec: editingGoalObj ? Number(newGoal.t4_exec!) : 0,
          order: editingGoalObj ? editingGoalObj.order : nextOrder
      };

      if (editingGoalObj && editingGoalObj.id) {
          await db.goals.update(editingGoalObj.id, goalData);
          await logAudit(currentUser.username, 'UPDATE_GOAL_DEF', `Meta ID ${editingGoalObj.id} editada`);
          showToast("Meta actualizada exitosamente", "success");
      } else {
          await db.goals.add({ ...goalData, t1_exec:0, t2_exec:0, t3_exec:0, t4_exec:0 } as Goal);
          await logAudit(currentUser.username, 'CREATE_GOAL', `Nueva meta creada para Dept ${id}`);
          showToast("Meta agregada exitosamente", "success");
      }
      setShowGoalModal(false);
  };
  
  const handleSaveProject = async () => {
      if (!editingProject.name) return;
      const data = {
          ...editingProject,
          deptId: id
      } as Project;
      
      if(editingProjectId) {
          await db.projects.update(editingProjectId, data);
      } else {
          await db.projects.add(data);
      }
      setShowProjectModal(false);
      showToast("Proyecto guardado", "success");
  };

  const handleOpenReportModal = (report?: WeeklyReport) => {
      if (report) {
          setEditingReportId(report.id!);
          setNewReport({ ...report });
          
          // Reconstruct form state from activities
          const newState: GoogleFormState = {
              reporterName: report.executiveSummary.includes('Cargado por:') ? report.executiveSummary.split('Cargado por:')[1].split('|')[0].trim() : '',
              email: report.executiveSummary.includes('Email:') ? report.executiveSummary.split('Email:')[1].trim() : '',
              observations: report.observations || '',
              other_poa: report.activities.filter(a => a.title === 'Actividad Vinculada POA').map(a => a.description).join('\n'),
              other_no_poa: report.activities.filter(a => a.title === 'Actividad Extra (No POA)').map(a => a.description).join('\n'),
          };

          // Fill Metas 1-15
          for(let i=1; i<=15; i++) {
              const act = report.activities.find(a => a.title === `Meta Producto ${i}`);
              newState[`meta${i}_desc`] = act ? act.description.split('|')[0].trim() : '';
              newState[`meta${i}_achieve`] = act && act.description.includes('Logro:') ? act.description.split('Logro:')[1].trim() : '';
          }
          
          setFormState(newState);
      } else {
          setEditingReportId(null);
          setNewReport({ startDate: new Date().toISOString().split('T')[0], endDate: new Date().toISOString().split('T')[0], executiveSummary: '', activities: [] });
          
          const emptyState: GoogleFormState = {
              reporterName: currentUser.username,
              email: '',
              observations: '',
              other_poa: '',
              other_no_poa: ''
          };
          for(let i=1; i<=15; i++) {
              emptyState[`meta${i}_desc`] = '';
              emptyState[`meta${i}_achieve`] = '';
          }
          setFormState(emptyState);
      }
      setShowReportModal(true);
  };

  const handleSaveReport = async () => {
      // Build Activities from Form State
      const activities: ActivityDetail[] = [];
      const endDate = newReport.endDate || new Date().toISOString();

      // Loop Metas 1-15
      for(let i=1; i<=15; i++) {
          const desc = formState[`meta${i}_desc`];
          const achieve = formState[`meta${i}_achieve`];
          if(desc) {
              activities.push({ 
                  date: endDate, 
                  title: `Meta Producto ${i}`, 
                  description: `${desc} | Logro: ${achieve}`, 
                  priority: 'Normal' 
              });
          }
      }
      
      // Linked POA
      if (formState.other_poa) {
          formState.other_poa.split('\n').forEach(line => {
             if(line.trim()) activities.push({ date: endDate, title: 'Actividad Vinculada POA', description: line.trim(), priority: 'Normal' });
          });
      }
      
      // Not Linked POA
      if (formState.other_no_poa) {
          formState.other_no_poa.split('\n').forEach(line => {
             if(line.trim()) activities.push({ date: endDate, title: 'Actividad Extra (No POA)', description: line.trim(), priority: 'Normal' });
          });
      }

      const summary = `Cargado por: ${formState.reporterName}. ${formState.email ? `| Email: ${formState.email}` : ''}`;
      
      const reportData = {
          deptId: id,
          startDate: newReport.startDate!, 
          endDate: newReport.endDate!,
          executiveSummary: summary,
          activities: activities,
          classification: 'Operativo',
          observations: formState.observations,
          createdAt: new Date().toISOString(), 
          createdBy: currentUser.username
      };

      if (editingReportId) {
          await db.weeklyReports.update(editingReportId, reportData);
          await logAudit(currentUser.username, 'UPDATE_REPORT', `Reporte semanal ID ${editingReportId} editado`);
          showToast("Reporte actualizado", "success");
      } else {
          await db.weeklyReports.add(reportData as WeeklyReport);
          await logAudit(currentUser.username, 'CREATE_REPORT', `Reporte semanal cargado Dept ${id}`);
          showToast("Reporte cargado", "success");
      }
      setShowReportModal(false); 
  };

  const handleUpdateDept = async () => {
      await db.departments.update(id, editDeptValues);
      setShowConfigModal(false);
      showToast("Datos actualizados", "success");
  };

  if (!dept) return <div className="p-8 text-center text-slate-500">Cargando...</div>;

  return (
    <div className="space-y-6 pb-20">
      <input type="file" ref={fileInputRef} onChange={processExcelFile} className="hidden" accept=".xlsx,.xls" />
      
      {/* 1. INSTITUTIONAL HEADER (COLLAPSIBLE) */}
      <div className="glass-panel p-6 rounded-xl relative shadow-md bg-white/80">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-2">
              <div>
                  <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">{dept.name}</h2>
                  <div className="flex flex-col sm:flex-row gap-2 sm:gap-6 text-sm text-slate-600 mt-2">
                      <span className="flex items-center gap-1 font-bold"><UserIcon size={16} className="text-blue-600"/> {dept.managerName}</span>
                      <span className="flex items-center gap-1"><Send size={16} className="text-green-600"/> {dept.email}</span>
                      {dept.type === 'OFFICE' && dept.parentId && (
                          <span className="flex items-center gap-1 text-emerald-600 font-bold text-xs bg-emerald-100 px-2 py-0.5 rounded-full">Oficina Adscrita</span>
                      )}
                  </div>
              </div>
              <div className="flex flex-wrap gap-2 items-center">
                  <button onClick={() => setIsHeaderExpanded(!isHeaderExpanded)} className="text-slate-500 hover:text-blue-600 p-2 rounded-full border border-slate-200 hover:bg-slate-50 transition-all" title="Ver Ficha Institucional">
                       {isHeaderExpanded ? <ChevronUp size={20}/> : <ChevronDown size={20}/>}
                  </button>
                  <button onClick={generatePOAPDF} className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 px-3 py-2 rounded-lg font-bold flex items-center gap-2 shadow-sm transition-all active:scale-95 text-xs">
                      <Printer size={16} /> Imprimir POA
                  </button>
                  <button onClick={handleWhatsAppReminder} className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg font-bold flex items-center gap-2 shadow-lg transition-all active:scale-95 text-xs">
                      <MessageCircle size={16} /> Recordatorio
                  </button>
                  <button onClick={() => handleOpenReportModal()} className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg font-bold flex items-center gap-2 shadow-lg transition-all active:scale-95 text-xs">
                      <FileText size={16} /> Reporte
                  </button>
                  
                  <div className="flex bg-slate-100 rounded-lg p-1 gap-1 border border-slate-200">
                    <button onClick={handleDownloadTemplate} className="p-2 text-slate-600 hover:text-blue-600 hover:bg-white rounded transition-colors" title="Descargar Plantilla Excel (Google Forms)">
                        <Download size={16}/>
                    </button>
                    <button onClick={handleImportExcelClick} className="p-2 text-slate-600 hover:text-emerald-600 hover:bg-white rounded transition-colors" title="Importar Actividades (Masivo / Google Forms)">
                        <UploadCloud size={16} />
                    </button>
                  </div>

                  {currentUser.role === 'ADMIN' && (
                       <button onClick={() => { setEditDeptValues(dept); setShowConfigModal(true); }} className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-2 rounded-lg transition-colors border border-slate-300 shadow-sm"><Settings size={16}/></button>
                  )}
              </div>
          </div>

          {isHeaderExpanded && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-sm mt-6 animate-in slide-in-from-top-2">
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                      <h4 className="font-bold text-blue-800 flex items-center gap-2 mb-2 uppercase text-xs"><Target size={14}/> Misión</h4>
                      <p className="text-slate-600 leading-snug text-xs">{dept.mission || "No definida"}</p>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-lg border border-purple-100">
                      <h4 className="font-bold text-purple-800 flex items-center gap-2 mb-2 uppercase text-xs"><BookOpen size={14}/> Visión</h4>
                      <p className="text-slate-600 leading-snug text-xs">{dept.vision || "No definida"}</p>
                  </div>
                  {/* Plan Patria */}
                  <div className="bg-orange-50 p-3 rounded-lg border border-orange-100">
                      <h4 className="font-bold text-orange-800 flex items-center gap-2 mb-2 uppercase text-xs"><Shield size={14}/> Plan Patria</h4>
                      <div className="space-y-2">
                          <div>
                              <span className="text-[10px] font-bold text-orange-700 block">Objetivo:</span>
                              <p className="text-slate-600 leading-snug text-xs">{dept.planPatriaObjective || dept.planPatriaGoal || "Sin vinculación"}</p>
                          </div>
                          <div>
                              <span className="text-[10px] font-bold text-orange-700 block">Lineamiento:</span>
                              <p className="text-slate-600 leading-snug text-xs">{dept.planPatriaLine || "Sin definir"}</p>
                          </div>
                      </div>
                  </div>
                  {/* Municipal */}
                  <div className="bg-teal-50 p-3 rounded-lg border border-teal-100">
                      <h4 className="font-bold text-teal-800 flex items-center gap-2 mb-2 uppercase text-xs"><MapPin size={14}/> P.D.M.</h4>
                      <div className="space-y-2">
                          <div>
                              <span className="text-[10px] font-bold text-teal-700 block">Objetivo:</span>
                              <p className="text-slate-600 leading-snug text-xs">{dept.municipalObjective || dept.municipalStrategy || "Sin definir"}</p>
                          </div>
                          <div>
                              <span className="text-[10px] font-bold text-teal-700 block">Lineamiento:</span>
                              <p className="text-slate-600 leading-snug text-xs">{dept.municipalLine || "Sin definir"}</p>
                          </div>
                      </div>
                  </div>
              </div>
          )}
      </div>

      {/* NEW MODULE (Tabs): POA & Projects */}
      <div className="flex gap-4 border-b border-slate-200 pb-1">
          <button 
             onClick={() => setActiveTab('POA')}
             className={`px-4 py-2 font-bold text-sm border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'POA' ? 'border-blue-600 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
          >
              <Target size={16}/> Metas Físicas (POA)
          </button>
          <button 
             onClick={() => setActiveTab('PROJECTS')}
             className={`px-4 py-2 font-bold text-sm border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'PROJECTS' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
          >
              <Briefcase size={16}/> Proyectos Especiales
          </button>
      </div>

      {/* 2. POA MATRIX (FULL DETAILED VERSION) */}
      {activeTab === 'POA' && (
      <div className="glass-panel rounded-xl overflow-hidden shadow-sm animate-in slide-in-from-bottom-2">
          <div className="p-4 bg-slate-50/80 border-b flex justify-between items-center">
              <h3 className="font-bold text-slate-700 flex items-center gap-2">
                  <Calendar size={18} className="text-blue-600"/> Matriz de Metas Físicas (POA 2026)
              </h3>
              <div className="flex items-center gap-2">
                  <button onClick={handleExportWord} className="text-xs bg-white text-blue-700 border border-blue-200 hover:bg-blue-50 px-3 py-1.5 rounded-lg font-bold shadow-sm flex items-center gap-1" title="Exportar a Word">
                      <FileType size={12}/> Word
                  </button>
                  {currentUser.role === 'ADMIN' && (
                      <>
                      <button onClick={() => setAdminUnlock(!adminUnlock)} className={`text-xs px-3 py-1.5 rounded-lg font-bold shadow-sm flex items-center gap-1 transition-colors ${adminUnlock ? 'bg-orange-100 text-orange-700' : 'bg-slate-100 text-slate-500'}`} title={adminUnlock ? "Bloquear Trimestres Vencidos" : "Desbloquear Edición"}>
                          {adminUnlock ? <Unlock size={12}/> : <Lock size={12}/>}
                      </button>
                      <button onClick={() => handleOpenGoalModal()} className="text-xs bg-blue-600 text-white hover:bg-blue-700 px-3 py-1.5 rounded-lg font-bold shadow-md flex items-center gap-1">
                          <Plus size={12} /> Nueva Meta
                      </button>
                      </>
                  )}
              </div>
          </div>
          <div className="overflow-x-auto">
              <DragDropContext onDragEnd={handleOnDragEnd}>
              <table className="w-full text-sm text-left border-collapse">
                  <thead className="bg-slate-100 text-slate-600 uppercase text-[10px] font-bold border-b border-slate-200">
                      {/* Top Header Grouping */}
                      <tr className="bg-slate-200 text-slate-700">
                          <th className="w-8 px-2"></th>
                          <th className="px-4 py-2 border-r border-slate-300 w-64 min-w-[200px]">Meta / Actividad</th>
                          <th className="px-4 py-2 border-r border-slate-300 w-48 min-w-[150px]">Medios de Verificación</th>
                          <th className="px-2 py-2 text-center border-r border-slate-300 bg-blue-50" colSpan={3}>Trimestre I</th>
                          <th className="px-2 py-2 text-center border-r border-slate-300 bg-purple-50" colSpan={3}>Trimestre II</th>
                          <th className="px-2 py-2 text-center border-r border-slate-300 bg-orange-50" colSpan={3}>Trimestre III</th>
                          <th className="px-2 py-2 text-center border-r border-slate-300 bg-teal-50" colSpan={3}>Trimestre IV</th>
                          <th className="px-2 py-2 text-center border-l-4 border-slate-400 bg-slate-800 text-white" colSpan={3}>Consolidado Anual</th>
                          <th className="px-2 py-2 text-center">Prom</th>
                          <th className="px-1 py-1"></th>
                      </tr>
                      {/* Sub Header */}
                      <tr>
                          <th className="bg-slate-100"></th>
                          <th className="px-2 py-2 border-r border-slate-200">Descripción</th>
                          <th className="px-2 py-2 border-r border-slate-200">Evidencias / Soportes</th>
                          
                          {/* T1 */}
                          <th className="px-1 py-1 text-center bg-blue-50/50 w-14 border-r border-dashed border-slate-200" title="Programado">P</th>
                          <th className="px-1 py-1 text-center bg-blue-50/50 w-14 border-r border-dashed border-slate-200" title="Ejecutado">E</th>
                          <th className="px-1 py-1 text-center bg-blue-50/50 w-14 border-r border-slate-200" title="Evaluación %">%</th>
                          
                          {/* T2 */}
                          <th className="px-1 py-1 text-center bg-purple-50/50 w-14 border-r border-dashed border-slate-200" title="Programado">P</th>
                          <th className="px-1 py-1 text-center bg-purple-50/50 w-14 border-r border-dashed border-slate-200" title="Ejecutado">E</th>
                          <th className="px-1 py-1 text-center bg-purple-50/50 w-14 border-r border-slate-200" title="Evaluación %">%</th>

                          {/* T3 */}
                          <th className="px-1 py-1 text-center bg-orange-50/50 w-14 border-r border-dashed border-slate-200" title="Programado">P</th>
                          <th className="px-1 py-1 text-center bg-orange-50/50 w-14 border-r border-dashed border-slate-200" title="Ejecutado">E</th>
                          <th className="px-1 py-1 text-center bg-orange-50/50 w-14 border-r border-slate-200" title="Evaluación %">%</th>

                          {/* T4 */}
                          <th className="px-1 py-1 text-center bg-teal-50/50 w-14 border-r border-dashed border-slate-200" title="Programado">P</th>
                          <th className="px-1 py-1 text-center bg-teal-50/50 w-14 border-r border-dashed border-slate-200" title="Ejecutado">E</th>
                          <th className="px-1 py-1 text-center bg-teal-50/50 w-14 border-r border-slate-200" title="Evaluación %">%</th>

                          {/* Annual (EMPHASIZED) */}
                          <th className="px-1 py-1 text-center bg-slate-200 w-14 border-l-4 border-slate-400 border-r border-slate-300 font-black text-slate-800" title="Programado Año">P</th>
                          <th className="px-1 py-1 text-center bg-slate-200 w-14 border-r border-slate-300 font-black text-slate-800" title="Ejecutado Año">E</th>
                          <th className="px-1 py-1 text-center bg-slate-200 w-14 border-r border-slate-300 font-black text-slate-800" title="Evaluación %">%</th>

                          <th className="px-2 py-2 text-center w-14" title="Promedio Total">Avg</th>
                          <th className="px-1 py-1 w-12 text-center">Acciones</th>
                      </tr>
                  </thead>
                  <Droppable droppableId="goals-list">
                  {(provided) => (
                  <tbody className="divide-y divide-slate-100" {...provided.droppableProps} ref={provided.innerRef}>
                      {goals?.map((g, index) => {
                          const isEditing = editingGoalId === g.id;
                          
                          // Helper for percentage
                          const calcPerc = (plan: number, exec: number) => plan > 0 ? Math.round((exec / plan) * 100) : 0;
                          
                          const p1 = calcPerc(Number(g.t1_plan), Number(g.t1_exec));
                          const p2 = calcPerc(Number(g.t2_plan), Number(g.t2_exec));
                          const p3 = calcPerc(Number(g.t3_plan), Number(g.t3_exec));
                          const p4 = calcPerc(Number(g.t4_plan), Number(g.t4_exec));
                          
                          const totalPlan = Number(g.t1_plan) + Number(g.t2_plan) + Number(g.t3_plan) + Number(g.t4_plan);
                          const totalExec = Number(g.t1_exec) + Number(g.t2_exec) + Number(g.t3_exec) + Number(g.t4_exec);
                          const totalPerc = calcPerc(totalPlan, totalExec);
                          
                          const averagePerc = Math.round((p1 + p2 + p3 + p4) / 4);

                          return (
                              <Draggable key={g.id} draggableId={String(g.id)} index={index} isDragDisabled={currentUser.role !== 'ADMIN'}>
                              {(provided, snapshot) => (
                              <tr ref={provided.innerRef} {...provided.draggableProps} className={`hover:bg-slate-50 transition-colors text-xs ${snapshot.isDragging ? 'bg-slate-100 shadow-xl' : ''}`}>
                                  <td className="px-2 text-center">
                                      {currentUser.role === 'ADMIN' && (
                                          <div {...provided.dragHandleProps} className="text-slate-400 cursor-grab hover:text-slate-600"><GripVertical size={12}/></div>
                                      )}
                                  </td>
                                  <td className="px-2 py-3 border-r border-slate-100 font-medium text-slate-700 leading-tight">
                                      {g.description}
                                      {g.isExtra && <span className="ml-1 text-[9px] bg-yellow-100 text-yellow-700 px-1 rounded font-bold">EXTRA</span>}
                                  </td>
                                  
                                  <td className="px-2 py-3 border-r border-slate-100 text-xs text-slate-600 leading-tight min-w-[150px]">
                                      {g.verificationMeans || <span className="text-slate-300 italic">No especificado</span>}
                                  </td>

                                  <td className="px-1 py-2 text-center text-slate-500">{g.t1_plan}</td>
                                  <td className="px-1 py-2 text-center">
                                      {isEditing && !isLocked(1) ? <input type="number" className="w-10 text-center border rounded p-0.5 bg-blue-50 font-bold text-blue-700" value={editValues.t1_exec ?? g.t1_exec} onChange={e => setEditValues({...editValues, t1_exec: Number(e.target.value)})} /> : <span className={`font-bold ${isLocked(1) ? 'text-slate-400' : 'text-blue-700'}`}>{g.t1_exec}</span>}
                                  </td>
                                  <td className="px-1 py-2 text-center border-r border-slate-200 text-slate-400">{p1}%</td>

                                  <td className="px-1 py-2 text-center text-slate-500">{g.t2_plan}</td>
                                  <td className="px-1 py-2 text-center">
                                      {isEditing && !isLocked(2) ? <input type="number" className="w-10 text-center border rounded p-0.5 bg-purple-50 font-bold text-purple-700" value={editValues.t2_exec ?? g.t2_exec} onChange={e => setEditValues({...editValues, t2_exec: Number(e.target.value)})} /> : <span className={`font-bold ${isLocked(2) ? 'text-slate-400' : 'text-purple-700'}`}>{g.t2_exec}</span>}
                                  </td>
                                  <td className="px-1 py-2 text-center border-r border-slate-200 text-slate-400">{p2}%</td>

                                  <td className="px-1 py-2 text-center text-slate-500">{g.t3_plan}</td>
                                  <td className="px-1 py-2 text-center">
                                      {isEditing && !isLocked(3) ? <input type="number" className="w-10 text-center border rounded p-0.5 bg-orange-50 font-bold text-orange-700" value={editValues.t3_exec ?? g.t3_exec} onChange={e => setEditValues({...editValues, t3_exec: Number(e.target.value)})} /> : <span className={`font-bold ${isLocked(3) ? 'text-slate-400' : 'text-orange-700'}`}>{g.t3_exec}</span>}
                                  </td>
                                  <td className="px-1 py-2 text-center border-r border-slate-200 text-slate-400">{p3}%</td>

                                  <td className="px-1 py-2 text-center text-slate-500">{g.t4_plan}</td>
                                  <td className="px-1 py-2 text-center">
                                      {isEditing ? <input type="number" className="w-10 text-center border rounded p-0.5 bg-teal-50 font-bold text-teal-700" value={editValues.t4_exec ?? g.t4_exec} onChange={e => setEditValues({...editValues, t4_exec: Number(e.target.value)})} /> : <span className="font-bold text-teal-700">{g.t4_exec}</span>}
                                  </td>
                                  <td className="px-1 py-2 text-center border-r border-slate-200 text-slate-400">{p4}%</td>

                                  <td className="px-1 py-2 text-center font-black text-slate-800 bg-slate-200 border-l-4 border-slate-400">{totalPlan}</td>
                                  <td className="px-1 py-2 text-center font-black text-slate-800 bg-slate-200">{totalExec}</td>
                                  <td className="px-1 py-2 text-center font-black text-slate-800 bg-slate-200 border-r border-slate-300">{totalPerc}%</td>

                                  <td className="px-2 py-2 text-center">
                                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${averagePerc >= 90 ? 'bg-green-100 text-green-700' : averagePerc < 50 ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                          {averagePerc}%
                                      </span>
                                  </td>
                                  <td className="px-1 py-2 text-center flex gap-1 justify-center">
                                      {isEditing ? (
                                          <button onClick={() => handleSaveGoalExecEdit(g.id!)} className="text-green-600 hover:bg-green-50 p-1 rounded" title="Guardar Avances"><Save size={14}/></button>
                                      ) : (
                                          <button onClick={() => setEditingGoalId(g.id!)} className="text-slate-400 hover:text-blue-600 p-1 rounded transition-colors" title="Cargar Avance (Ejecución)">
                                              <Settings size={14} />
                                          </button>
                                      )}
                                      {currentUser.role === 'ADMIN' && (
                                        <>
                                          <button onClick={() => handleOpenGoalModal(g)} className="text-slate-400 hover:text-purple-600 p-1 rounded transition-colors" title="Editar Meta (Definición)">
                                              <Edit2 size={14} />
                                          </button>
                                          <button onClick={() => handleDeleteGoal(g.id!)} className="text-slate-400 hover:text-red-600 p-1 rounded transition-colors" title="Eliminar Meta">
                                              <Trash2 size={14} />
                                          </button>
                                        </>
                                      )}
                                  </td>
                              </tr>
                              )}
                              </Draggable>
                          );
                      })}
                      {provided.placeholder}
                      {(!goals || goals.length === 0) && (
                          <tr><td colSpan={18} className="p-8 text-center text-slate-400 italic">No hay metas cargadas para esta gerencia.</td></tr>
                      )}
                  </tbody>
                  )}
                  </Droppable>
              </table>
              </DragDropContext>
          </div>
      </div>
      )}
      
      {/* 2b. SPECIAL PROJECTS (Module #4) */}
      {activeTab === 'PROJECTS' && (
          <div className="glass-panel rounded-xl overflow-hidden shadow-sm animate-in slide-in-from-bottom-2">
              <div className="p-4 bg-purple-50/80 border-b flex justify-between items-center">
                  <h3 className="font-bold text-purple-900 flex items-center gap-2">
                      <Briefcase size={18}/> Proyectos Especiales y Obras
                  </h3>
                  {currentUser.role === 'ADMIN' && (
                      <button onClick={() => handleOpenProjectModal()} className="text-xs bg-purple-600 text-white hover:bg-purple-700 px-3 py-1.5 rounded-lg font-bold shadow-md flex items-center gap-1">
                          <Plus size={12} /> Nuevo Proyecto
                      </button>
                  )}
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {projects?.map(p => (
                      <div key={p.id} className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                          <div className="flex justify-between items-start mb-2">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  p.status === 'CULMINADO' ? 'bg-green-100 text-green-700' :
                                  p.status === 'EJECUCION' ? 'bg-blue-100 text-blue-700' :
                                  p.status === 'DETENIDO' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'
                              }`}>{p.status}</span>
                              {currentUser.role === 'ADMIN' && (
                                  <button onClick={() => handleOpenProjectModal(p)} className="text-slate-400 hover:text-purple-600"><Edit2 size={14}/></button>
                              )}
                          </div>
                          <h4 className="font-bold text-slate-800 mb-1">{p.name}</h4>
                          <p className="text-xs text-slate-500 mb-4 h-10 line-clamp-2">{p.description}</p>
                          
                          <div className="mb-2">
                              <div className="flex justify-between text-xs mb-1">
                                  <span className="font-bold text-slate-600">Progreso</span>
                                  <span className="font-bold text-blue-600">{p.progress}%</span>
                              </div>
                              <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                                  <div className="h-full bg-blue-500 rounded-full" style={{width: `${p.progress}%`}}></div>
                              </div>
                          </div>
                          <div className="flex justify-between text-[10px] text-slate-400 mt-3 border-t pt-2">
                              <span>Inicio: {p.startDate || 'N/A'}</span>
                              <span>Fin: {p.endDate || 'N/A'}</span>
                          </div>
                      </div>
                  ))}
                  {(!projects || projects.length === 0) && (
                      <div className="col-span-full py-12 text-center text-slate-400 italic">No hay proyectos especiales registrados.</div>
                  )}
              </div>
          </div>
      )}

      {/* 3. WEEKLY REPORTS (ACCORDION & CARDS) */}
      <div className="mt-8">
          <h3 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><History size={20}/> Historial de Actividades Semanales</h3>
          <div className="space-y-4">
              {reports?.map(r => {
                  const isExpanded = expandedReportId === r.id;
                  return (
                      <div key={r.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden transition-all">
                          <div 
                              onClick={() => setExpandedReportId(isExpanded ? null : r.id!)}
                              className="p-4 bg-slate-50 hover:bg-slate-100 cursor-pointer flex justify-between items-center transition-colors"
                          >
                              <div className="flex items-center gap-4">
                                  <div className={`p-2 rounded-lg ${isExpanded ? 'bg-blue-100 text-blue-600' : 'bg-slate-200 text-slate-500'}`}>
                                      {isExpanded ? <ChevronUp size={20}/> : <ChevronDown size={20}/>}
                                  </div>
                                  <div>
                                      <h4 className="font-bold text-slate-800 text-sm">Semana: {new Date(r.startDate).toLocaleDateString()} al {new Date(r.endDate).toLocaleDateString()}</h4>
                                      <p className="text-xs text-slate-500">{r.activities.length} Actividades registradas</p>
                                  </div>
                              </div>
                              <div className="flex gap-2">
                                  <button onClick={(e) => { e.stopPropagation(); handleOpenReportModal(r); }} className="p-2 text-slate-500 hover:text-purple-600 hover:bg-purple-50 rounded-full transition-all" title="Editar Reporte">
                                      <Edit2 size={18}/>
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); generateWeeklyPDF(r); }} className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-all" title="Imprimir Reporte">
                                      <Printer size={18}/>
                                  </button>
                                  {/* DELETE REPORT BUTTON */}
                                  <button onClick={(e) => { e.stopPropagation(); handleDeleteReport(r.id!); }} className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-all" title="Eliminar Semana Completa">
                                      <Trash2 size={18}/>
                                  </button>
                              </div>
                          </div>
                          {isExpanded && (
                              <div className="p-6 bg-slate-50/50 border-t border-slate-200 animate-in slide-in-from-top-2">
                                  <div className="mb-4 p-3 bg-blue-50 border border-blue-100 rounded-lg text-sm text-blue-800 italic">"{r.executiveSummary}"</div>
                                  
                                  {r.observations && (
                                    <div className="mb-4 p-3 bg-yellow-50 border border-yellow-100 rounded-lg text-sm">
                                        <h5 className="font-bold text-yellow-800 text-xs uppercase mb-1">Observaciones:</h5>
                                        <p className="text-slate-700">{r.observations}</p>
                                    </div>
                                  )}

                                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                      {r.activities.map((act, idx) => {
                                          const colorClass = PASTEL_COLORS[idx % PASTEL_COLORS.length];
                                          return (
                                          <div key={idx} className={`${colorClass} p-4 rounded-lg shadow-sm border hover:shadow-md transition-shadow`}>
                                              <div className="flex justify-between items-start mb-2">
                                                  <span className="text-[10px] font-bold uppercase text-slate-500">{new Date(act.date).toLocaleDateString()}</span>
                                              </div>
                                              <h5 className="font-bold text-slate-800 text-sm mb-1">{act.title}</h5>
                                              <p className="text-xs text-slate-600 line-clamp-4 leading-relaxed">{act.description}</p>
                                          </div>
                                      )})}
                                  </div>
                              </div>
                          )}
                      </div>
                  );
              })}
          </div>
      </div>

      {/* MODAL: New/Edit Goal */}
      {showGoalModal && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm overflow-y-auto">
              <div className="bg-white rounded-xl w-full max-w-lg shadow-2xl animate-in zoom-in-95">
                  <div className="bg-slate-900 text-white p-4 flex justify-between items-center rounded-t-xl">
                      <h3 className="font-bold flex items-center gap-2"><Target size={18}/> {editingGoalObj ? 'Editar Meta' : 'Nueva Meta Física'}</h3>
                      <button onClick={() => setShowGoalModal(false)}><X size={18}/></button>
                  </div>
                  <div className="p-6 space-y-4">
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Descripción de la Meta</label>
                          <textarea className="w-full border p-2 rounded text-sm h-20" placeholder="Ej: Realizar mantenimiento preventivo..." value={newGoal.description} onChange={e => setNewGoal({...newGoal, description: e.target.value})} />
                      </div>
                      <div className="flex gap-4">
                          <div className="flex-1">
                               <label className="text-xs font-bold text-slate-500 uppercase">Unidad Medida</label>
                               <input className="w-full border p-2 rounded text-sm" value={newGoal.unit} onChange={e => setNewGoal({...newGoal, unit: e.target.value})} placeholder="Ej: Informe, Obra" />
                          </div>
                          <div className="flex items-end mb-2">
                               <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                                   <input type="checkbox" checked={newGoal.isExtra} onChange={e => setNewGoal({...newGoal, isExtra: e.target.checked})} className="w-4 h-4 text-blue-600 rounded" />
                                   <span className="font-bold">¿Es Meta Extra?</span>
                               </label>
                          </div>
                      </div>
                      
                      {/* Verification Means Input - Updated Location */}
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Medios de Verificación</label>
                          <textarea 
                              className="w-full border p-2 rounded text-sm h-16 mt-1" 
                              placeholder="Ej: Registro fotográfico, actas de entrega, lista de asistencia..."
                              value={newGoal.verificationMeans} 
                              onChange={e => setNewGoal({...newGoal, verificationMeans: e.target.value})} 
                          />
                      </div>

                      <div className="grid grid-cols-4 gap-2 bg-slate-50 p-3 rounded border">
                          <div className="text-center">
                              <label className="text-[10px] font-bold text-slate-500 uppercase">Plan T1</label>
                              <input type="number" className="w-full border p-1 rounded text-center text-sm" value={newGoal.t1_plan} onChange={e => setNewGoal({...newGoal, t1_plan: Number(e.target.value)})} />
                          </div>
                          <div className="text-center">
                              <label className="text-[10px] font-bold text-slate-500 uppercase">Plan T2</label>
                              <input type="number" className="w-full border p-1 rounded text-center text-sm" value={newGoal.t2_plan} onChange={e => setNewGoal({...newGoal, t2_plan: Number(e.target.value)})} />
                          </div>
                          <div className="text-center">
                              <label className="text-[10px] font-bold text-slate-500 uppercase">Plan T3</label>
                              <input type="number" className="w-full border p-1 rounded text-center text-sm" value={newGoal.t3_plan} onChange={e => setNewGoal({...newGoal, t3_plan: Number(e.target.value)})} />
                          </div>
                          <div className="text-center">
                              <label className="text-[10px] font-bold text-slate-500 uppercase">Plan T4</label>
                              <input type="number" className="w-full border p-1 rounded text-center text-sm" value={newGoal.t4_plan} onChange={e => setNewGoal({...newGoal, t4_plan: Number(e.target.value)})} />
                          </div>
                      </div>
                  </div>
                  <div className="p-4 border-t flex justify-end gap-2 bg-slate-50 rounded-b-xl">
                      <button onClick={() => setShowGoalModal(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-200 rounded">Cancelar</button>
                      <button onClick={handleSaveGoal} className="px-4 py-2 bg-blue-600 text-white font-bold rounded hover:bg-blue-700 shadow-lg">Guardar</button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL: New/Edit Project */}
      {showProjectModal && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm overflow-y-auto">
              <div className="bg-white rounded-xl w-full max-w-lg shadow-2xl animate-in zoom-in-95">
                  <div className="bg-slate-900 text-white p-4 flex justify-between items-center rounded-t-xl">
                      <h3 className="font-bold flex items-center gap-2"><Briefcase size={18}/> {editingProjectId ? 'Editar Proyecto' : 'Nuevo Proyecto Especial'}</h3>
                      <button onClick={() => setShowProjectModal(false)}><X size={18}/></button>
                  </div>
                  <div className="p-6 space-y-4">
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Nombre del Proyecto</label>
                          <input className="w-full border p-2 rounded text-sm mb-1" value={editingProject.name} onChange={e => setEditingProject({...editingProject, name: e.target.value})} placeholder="Ej: Rehabilitación de..." />
                      </div>
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Descripción</label>
                          <textarea className="w-full border p-2 rounded text-sm h-16" value={editingProject.description} onChange={e => setEditingProject({...editingProject, description: e.target.value})} />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                           <div>
                               <label className="text-xs font-bold text-slate-500 uppercase">Estatus</label>
                               <select className="w-full border p-2 rounded text-sm" value={editingProject.status} onChange={e => setEditingProject({...editingProject, status: e.target.value as any})}>
                                   <option value="PLANIFICADO">Planificado</option>
                                   <option value="EJECUCION">En Ejecución</option>
                                   <option value="DETENIDO">Detenido</option>
                                   <option value="CULMINADO">Culminado</option>
                               </select>
                           </div>
                           <div>
                               <label className="text-xs font-bold text-slate-500 uppercase">Progreso (%)</label>
                               <input type="number" min="0" max="100" className="w-full border p-2 rounded text-sm" value={editingProject.progress} onChange={e => setEditingProject({...editingProject, progress: Number(e.target.value)})} />
                           </div>
                      </div>
                  </div>
                  <div className="p-4 border-t flex justify-end gap-2 bg-slate-50 rounded-b-xl">
                      <button onClick={() => setShowProjectModal(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-200 rounded">Cancelar</button>
                      <button onClick={handleSaveProject} className="px-4 py-2 bg-purple-600 text-white font-bold rounded hover:bg-purple-700 shadow-lg">Guardar Proyecto</button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL: Reporte Semanal - UPDATED FOR GOOGLE FORM STRUCTURE */}
      {showReportModal && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm overflow-y-auto">
              <div className="bg-white rounded-xl w-full max-w-4xl shadow-2xl animate-in zoom-in-95 my-8">
                  <div className="bg-slate-900 text-white p-4 flex justify-between items-center rounded-t-xl">
                      <h3 className="font-bold flex items-center gap-2"><FileText size={18}/> {editingReportId ? 'Editar Reporte' : 'Nuevo Reporte Semanal'}</h3>
                      <button onClick={() => setShowReportModal(false)}><span className="text-2xl">&times;</span></button>
                  </div>
                  <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
                      
                      {/* Section 1: Basic Info */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-lg border">
                          <div>
                              <label className="text-xs font-bold text-slate-500 uppercase">Dependencia</label>
                              <div className="font-bold text-slate-800">{dept.name}</div>
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-500 uppercase">Persona que carga</label>
                              <input className="w-full border p-2 rounded text-sm mt-1" value={formState.reporterName} onChange={e => setFormState({...formState, reporterName: e.target.value})} placeholder="Nombre Apellido" />
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-500 uppercase">Email (Opcional)</label>
                              <input className="w-full border p-2 rounded text-sm mt-1" value={formState.email} onChange={e => setFormState({...formState, email: e.target.value})} placeholder="correo@ejemplo.com" />
                          </div>
                          <div className="grid grid-cols-2 gap-2 md:col-span-3">
                              <div>
                                  <label className="text-xs font-bold text-slate-500 uppercase">Inicio</label>
                                  <input type="date" className="w-full border p-2 rounded text-sm mt-1" value={newReport.startDate} onChange={e => setNewReport({...newReport, startDate: e.target.value})} />
                              </div>
                              <div>
                                  <label className="text-xs font-bold text-slate-500 uppercase">Fin</label>
                                  <input type="date" className="w-full border p-2 rounded text-sm mt-1" value={newReport.endDate} onChange={e => setNewReport({...newReport, endDate: e.target.value})} />
                              </div>
                          </div>
                      </div>

                      {/* Section 2: Metas Producto */}
                      <div className="space-y-4">
                          <h4 className="font-bold text-slate-700 border-b pb-2">Metas Producto (1-15)</h4>
                          
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map(num => (
                              <div key={num} className="grid grid-cols-1 md:grid-cols-2 gap-4 p-3 border rounded-lg hover:bg-slate-50 transition-colors">
                                  <div>
                                      <label className="text-xs font-bold text-blue-600 uppercase">Meta Producto {num}</label>
                                      <textarea 
                                          className="w-full border p-2 rounded text-sm h-16 mt-1" 
                                          placeholder={`Describa la Meta Producto ${num}...`}
                                          value={formState[`meta${num}_desc`]} 
                                          onChange={e => setFormState({...formState, [`meta${num}_desc`]: e.target.value})} 
                                      />
                                  </div>
                                  <div>
                                      <label className="text-xs font-bold text-green-600 uppercase">Logro Alcanzado</label>
                                      <textarea 
                                          className="w-full border p-2 rounded text-sm h-16 mt-1" 
                                          placeholder={`¿Qué logró en relación a la Meta Producto ${num}?`}
                                          value={formState[`meta${num}_achieve`]} 
                                          onChange={e => setFormState({...formState, [`meta${num}_achieve`]: e.target.value})} 
                                      />
                                  </div>
                              </div>
                          ))}
                      </div>

                      {/* Section 3: Other Activities */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                              <label className="text-xs font-bold text-slate-700 uppercase block mb-2">Otras actividades vinculadas al POA</label>
                              <textarea 
                                  className="w-full border p-2 rounded text-sm h-32" 
                                  placeholder="Descríbalas con detalle (una por línea)..."
                                  value={formState.other_poa} 
                                  onChange={e => setFormState({...formState, other_poa: e.target.value})} 
                              />
                          </div>
                          <div>
                              <label className="text-xs font-bold text-slate-700 uppercase block mb-2">Actividades NO vinculadas al POA (Interés)</label>
                              <textarea 
                                  className="w-full border p-2 rounded text-sm h-32" 
                                  placeholder="Descríbalas con detalle (una por línea)..."
                                  value={formState.other_no_poa} 
                                  onChange={e => setFormState({...formState, other_no_poa: e.target.value})} 
                              />
                          </div>
                      </div>

                      {/* Section 4: Observations */}
                      <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
                           <label className="text-xs font-bold text-yellow-800 uppercase block mb-2">Observaciones Generales</label>
                           <textarea 
                              className="w-full border p-2 rounded text-sm h-24" 
                              placeholder="Información adicional relevante..."
                              value={formState.observations} 
                              onChange={e => setFormState({...formState, observations: e.target.value})} 
                              />
                      </div>
                      
                      <div className="bg-slate-100 p-3 rounded text-xs text-slate-600 border border-slate-200">
                          <b>Nota:</b> Las imágenes de las actividades deben ser archivadas internamente por la gerencia.
                      </div>

                  </div>
                  <div className="p-4 border-t flex justify-end gap-2 bg-slate-50 rounded-b-xl">
                      <button onClick={() => setShowReportModal(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-200 rounded">Cancelar</button>
                      <button onClick={handleSaveReport} className="px-4 py-2 bg-blue-600 text-white font-bold rounded hover:bg-blue-700 shadow-lg">Guardar Reporte</button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL: Configurar Gerencia (Admin) */}
      {showConfigModal && currentUser.role === 'ADMIN' && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
               <div className="bg-white rounded-xl w-full max-w-lg shadow-2xl animate-in zoom-in-95">
                  <div className="bg-slate-900 text-white p-4 flex justify-between items-center rounded-t-xl">
                      <h3 className="font-bold flex items-center gap-2"><Settings size={18}/> Configuración Institucional</h3>
                      <button onClick={() => setShowConfigModal(false)}><X size={18}/></button>
                  </div>
                  <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Nombre</label>
                          <input className="w-full border p-2 rounded text-sm" value={editDeptValues.name || ''} onChange={e => setEditDeptValues({...editDeptValues, name: e.target.value})} />
                      </div>
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Responsable (Gerente)</label>
                          <input className="w-full border p-2 rounded text-sm" value={editDeptValues.managerName || ''} onChange={e => setEditDeptValues({...editDeptValues, managerName: e.target.value})} />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase">Email</label>
                              <input className="w-full border p-2 rounded text-sm" value={editDeptValues.email || ''} onChange={e => setEditDeptValues({...editDeptValues, email: e.target.value})} />
                           </div>
                           <div>
                              <label className="text-xs font-bold text-slate-500 uppercase">Teléfono</label>
                              <input className="w-full border p-2 rounded text-sm" value={editDeptValues.phone || ''} onChange={e => setEditDeptValues({...editDeptValues, phone: e.target.value})} />
                           </div>
                      </div>
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Misión</label>
                          <textarea className="w-full border p-2 rounded text-sm h-16" value={editDeptValues.mission || ''} onChange={e => setEditDeptValues({...editDeptValues, mission: e.target.value})} />
                      </div>
                      <div>
                          <label className="text-xs font-bold text-slate-500 uppercase">Visión</label>
                          <textarea className="w-full border p-2 rounded text-sm h-16" value={editDeptValues.vision || ''} onChange={e => setEditDeptValues({...editDeptValues, vision: e.target.value})} />
                      </div>
                      
                      <div className="bg-orange-50 p-3 rounded border border-orange-100">
                          <label className="text-xs font-bold text-orange-800 uppercase">Plan Patria (Objetivo)</label>
                          <textarea className="w-full border p-2 rounded text-sm h-12" value={editDeptValues.planPatriaObjective || ''} onChange={e => setEditDeptValues({...editDeptValues, planPatriaObjective: e.target.value})} />
                          
                          <label className="text-xs font-bold text-orange-800 uppercase mt-2 block">Plan Patria (Lineamiento)</label>
                          <textarea className="w-full border p-2 rounded text-sm h-12" value={editDeptValues.planPatriaLine || ''} onChange={e => setEditDeptValues({...editDeptValues, planPatriaLine: e.target.value})} />
                      </div>

                      <div className="bg-teal-50 p-3 rounded border border-teal-100">
                          <label className="text-xs font-bold text-teal-800 uppercase">Plan Desarrollo Municipal (Objetivo)</label>
                          <textarea className="w-full border p-2 rounded text-sm h-12" value={editDeptValues.municipalObjective || ''} onChange={e => setEditDeptValues({...editDeptValues, municipalObjective: e.target.value})} />
                          
                          <label className="text-xs font-bold text-teal-800 uppercase mt-2 block">Plan Desarrollo Municipal (Metas / Lineamientos)</label>
                          <textarea className="w-full border p-2 rounded text-sm h-12" value={editDeptValues.municipalLine || ''} onChange={e => setEditDeptValues({...editDeptValues, municipalLine: e.target.value})} />
                      </div>
                  </div>
                  <div className="p-4 border-t flex justify-end gap-2 bg-slate-50 rounded-b-xl">
                      <button onClick={() => setShowConfigModal(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-200 rounded">Cancelar</button>
                      <button onClick={handleUpdateDept} className="px-4 py-2 bg-slate-800 text-white font-bold rounded hover:bg-slate-900 shadow-lg">Guardar Cambios</button>
                  </div>
               </div>
          </div>
      )}

    </div>
  );
};

export default MatrixView;
