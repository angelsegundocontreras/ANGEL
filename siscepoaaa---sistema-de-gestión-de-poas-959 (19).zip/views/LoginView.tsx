import React, { useState } from 'react';
import { db, logAudit } from '../services/db';
import { User, UserRole, MASTER_KEY_HASH, ALCALDIA_LOGO_URL } from '../types';
import { UserPlus, LogIn, Lock, AlertCircle } from 'lucide-react';

interface LoginViewProps {
  onLogin: (user: User) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [masterKey, setMasterKey] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.TRANSCRIBER);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    try {
      const user = await db.users.where('username').equals(username).first();
      if (user && user.passwordHash === password) {
        onLogin(user);
      } else {
        setError('Credenciales inválidas');
      }
    } catch (err) {
      setError('Error al conectar con la base de datos');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validation
    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    if (masterKey !== MASTER_KEY_HASH) {
      setError('Clave Maestra Incorrecta. Acceso Denegado.');
      return;
    }

    const exists = await db.users.where('username').equals(username).count();
    if (exists > 0) {
      setError('El usuario ya existe');
      return;
    }

    try {
      const id = await db.users.add({
        username,
        passwordHash: password,
        role,
        createdAt: new Date().toISOString()
      });
      
      await logAudit(username, 'REGISTER', `Nuevo usuario registrado como ${role}`);
      
      const newUser = await db.users.get(id);
      if (newUser) onLogin(newUser);
      
    } catch (err) {
      setError('Error al crear usuario');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      {/* Background overlay for Login */}
      <div className="fixed inset-0 pointer-events-none z-0" style={{background: 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0) 0%, rgba(15,23,42,0.3) 100%)'}}></div>

      <div className="glass-panel rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col md:flex-row z-10 animate-in zoom-in-95 duration-500">
        
        {/* Left Side: Brand */}
        <div className="hidden md:flex w-1/2 bg-slate-900 text-white flex-col justify-center items-center p-12 relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
             
             {/* Logo Container with White Background - Fixed for visibility */}
             <div className="bg-white p-4 rounded-3xl mb-6 shadow-xl z-10">
                 <img src={ALCALDIA_LOGO_URL} alt="Logo Alcaldía" className="h-28 w-auto object-contain" />
             </div>

             <h1 className="text-3xl font-black text-center mb-2 z-10 tracking-tight">SISCEPOAAA</h1>
             <p className="text-blue-200 text-center font-medium z-10">Sistema Integrado de Gestión y Auditoría de Gobierno</p>
             <div className="mt-8 text-xs text-slate-500 z-10 font-mono">Sistema Integrado de Gestión y Auditoría de Gobierno V1.0</div>
        </div>

        {/* Right Side: Form */}
        <div className="w-full md:w-1/2 p-10 bg-white/60 backdrop-blur-xl flex flex-col justify-center">
          <div className="md:hidden flex flex-col items-center mb-6">
             <div className="bg-white p-2 rounded-xl mb-2 shadow">
                <img src={ALCALDIA_LOGO_URL} alt="Logo Alcaldía" className="h-16 w-auto" />
             </div>
             <h1 className="text-xl font-bold text-slate-800 text-center">Sistema Integrado de Gestión y Auditoría V1.0</h1>
          </div>

          <h2 className="text-2xl font-bold text-slate-800 mb-6 text-center md:text-left">{isRegistering ? 'Registro de Funcionario' : 'Acceso Seguro'}</h2>

          {error && (
            <div className="mb-6 bg-red-50/80 border border-red-200 text-red-600 p-3 rounded-lg text-sm flex items-center gap-2 animate-pulse">
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          <form onSubmit={isRegistering ? handleRegister : handleLogin} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Usuario</label>
              <input 
                type="text" 
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/80"
                placeholder="Nombre de usuario"
                required
              />
            </div>
            
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Contraseña</label>
              <input 
                type="password" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/80"
                placeholder="******"
                required
              />
            </div>

            {isRegistering && (
              <>
                <div className="animate-in slide-in-from-top-2 fade-in">
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Rol de Acceso</label>
                   <select 
                     value={role}
                     onChange={(e) => setRole(e.target.value as UserRole)}
                     className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm bg-white/80"
                   >
                     <option value={UserRole.TRANSCRIBER}>Transcriptor / Analista</option>
                     <option value={UserRole.ADMIN}>Administrador</option>
                   </select>
                </div>
                <div className="animate-in slide-in-from-top-2 fade-in">
                  <label className="block text-xs font-bold text-red-600 uppercase mb-2 ml-1 flex items-center gap-1">
                    <Lock size={12} /> Clave Maestra
                  </label>
                  <input 
                    type="password" 
                    value={masterKey}
                    onChange={e => setMasterKey(e.target.value)}
                    className="w-full border-red-200 bg-red-50/50 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 text-red-800"
                    placeholder="Código de Seguridad"
                    required
                  />
                </div>
              </>
            )}

            <button 
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 rounded-lg transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center justify-center gap-2 mt-4"
            >
              {isRegistering ? <UserPlus size={20} /> : <LogIn size={20} />}
              {isRegistering ? 'Crear Cuenta' : 'Ingresar al Sistema'}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button 
              onClick={() => { setIsRegistering(!isRegistering); setError(''); }}
              className="text-sm text-blue-600 hover:text-blue-800 font-semibold hover:underline transition-colors"
            >
              {isRegistering ? '¿Ya tienes cuenta? Inicia Sesión' : '¿No tienes cuenta? Regístrate'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginView;