
import React, { useState } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { db, logAudit } from '../services/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { ALCALDIA_LOGO_URL, User } from '../types';
import { 
  BookOpen, Table, AlertTriangle, ShieldCheck, 
  FileSignature, Award, Hash, FileCheck, Printer, X,
  AlertOctagon, TrendingUp, Users,
  ClipboardList, FileText, Flag, FileBarChart, PieChart, Contact, Sheet, ListChecks, MessageCircle, Layers, Network, FolderArchive
} from 'lucide-react';
import { ToastContext } from '../App';
import JSZip from 'jszip';

// Fix: Declare QRCode variable to avoid TypeScript error
declare var QRCode: any;

interface ReportsCenterProps { currentUser?: User; }

const COLORS = {
  NAVY: [20, 50, 90] as [number, number, number],
  GOLD: [218, 165, 32] as [number, number, number],
  RED: [180, 20, 20] as [number, number, number],
  TEAL: [0, 128, 128] as [number, number, number],
  PURPLE: [128, 0, 128] as [number, number, number],
  GRAY: [100, 100, 100] as [number, number, number],
  GREEN: [0, 100, 0] as [number, number, number],
  BLACK: [0, 0, 0] as [number, number, number],
  LIGHT_GRAY: [240, 240, 240] as [number, number, number],
};

const REPORT_DEFINITIONS: Record<string, string> = {
    'MEMORIA': 'El presente Libro de Gestión Anual constituye el resumen consolidado de todos los indicadores, metas y logros alcanzados por la administración pública municipal durante el ejercicio fiscal. Este documento valida el cumplimiento de las políticas públicas y sirve como base para la rendición de cuentas ante los organismos contralores.',
    'ACTA_ENTREGA': 'Documento legal administrativo diseñado para formalizar el traspaso de responsabilidades y la rendición de cuentas trimestral del POA. Certifica el estado actual de los procesos, metas y recursos asignados a cada dependencia para garantizar la continuidad administrativa.',
    'DIPLOMA': 'Este Certificado de Eficiencia es un reconocimiento institucional otorgado a las gerencias que han demostrado un desempeño sobresaliente, superando el 90% de eficacia en su gestión operativa. Representa el compromiso con la excelencia y el servicio público de calidad.',
    'SABANA': 'La Sábana Trimestral es una matriz exhaustiva que desglosa todas las metas físicas planificadas y ejecutadas por trimestre. Este reporte permite una auditoría detallada del avance físico de las metas, facilitando la identificación de desviaciones y la toma de decisiones correctivas.',
    'BOLETIN': 'Informe de Inteligencia de Negocios (BI) que presenta métricas accionables (KPIs) y visualizaciones estratégicas para la alta dirección. Este boletín sintetiza el desempeño global de la alcaldía, destacando áreas de éxito y oportunidades de mejora.',
    'PLAN_PATRIA': 'Tabla de alineación estratégica que vincula directamente las metas operativas locales con los Objetivos Históricos y Lineamientos del Plan de la Nación. Demuestra la coherencia de la gestión municipal con las políticas nacionales de desarrollo.',
    'NUDOS': 'Reporte de alerta temprana diseñado para identificar metas críticas con 0% de ejecución o retrasos significativos. Su objetivo es activar mecanismos de intervención inmediata para asegurar el cumplimiento del Plan Operativo Anual.',
    'SOLVENCIA': 'Certificación administrativa oficial que hace constar el cumplimiento de los deberes formales de carga y actualización de datos en el sistema SISCEPOAAA por parte de las dependencias municipales.',
    'RANKING': 'Tabla de posiciones competitiva que ordena a todas las dependencias según su porcentaje de eficacia acumulada. Este instrumento fomenta la transparencia y la sana competencia para elevar los estándares de gestión.',
    'CARGA_LABORAL': 'Inventario completo y estadístico de las metas asignadas a cada gerencia. Permite evaluar la distribución del trabajo y los recursos, asegurando una planificación equitativa y realista.',
    'TRAZABILIDAD': 'Bitácora de auditoría forense que registra cronológicamente todas las interacciones de los usuarios con el sistema. Garantiza la seguridad, integridad y no repudio de las operaciones realizadas.',
    'OFICIO': 'Carta formal estandarizada para la remisión oficial de los tomos de planificación y gestión ante el Despacho del Alcalde. Cumple con los protocolos de comunicación institucional requeridos por la ley.',
    'INFORME_SEMANAL': 'Compendio cronológico y detallado de todas las actividades operativas y metas extras reportadas semanalmente. Ofrece una visión granular del trabajo diario de las dependencias.',
    'ETIQUETAS': 'Generación automatizada de etiquetas de archivo con códigos QR y pestañas separadoras para carpetas. Facilita la organización física de los expedientes y vincula los documentos en papel con sus registros digitales en el sistema.',
    'DEFICIT': 'Análisis de brechas que cuantifica numéricamente la diferencia entre lo planificado y lo ejecutado (Déficit = Plan - Real). Herramienta clave para reprogramar recursos y ajustar expectativas de cierre de año.',
    'FICHAS': 'Hoja de vida institucional (Perfil) que resume la identidad estratégica de cada dependencia, incluyendo su Misión, Visión y datos de contacto. Fundamental para el conocimiento organizacional.',
    'WHATSAPP_LOG': 'Registro de control que lista todas las notificaciones y recordatorios enviados automáticamente vía WhatsApp a los gerentes, sirviendo como prueba de las acciones de seguimiento realizadas.',
    'POA_HIERARCHY': 'Reporte avanzado que consolida la información de las Gerencias junto con sus Oficinas adscritas. Permite evaluar tanto el desempeño individual de cada oficina como el desempeño global de la Gerencia incluyendo sus dependencias subordinadas.',
    'ORGANIGRAMA': 'Representación gráfica de la estructura organizativa de las Gerencias y sus Oficinas adscritas. Este documento visualiza las relaciones jerárquicas registradas en el sistema.',
    'INVENTARIO': 'Listado de control que indica únicamente las fechas de las semanas que cada dependencia ha cargado en el sistema, permitiendo verificar rápidamente la completitud de la información.'
};

const REPORT_TYPES = [
    { id: 'MEMORIA', title: '1. Memoria y Cuenta', icon: BookOpen, color: 'blue', desc: 'Libro de Gestión Anual' },
    { id: 'ACTA_ENTREGA', title: '2. Acta de Entrega', icon: FileSignature, color: 'purple', desc: 'Formato Legal de Traspaso' },
    { id: 'DIPLOMA', title: '3. Certificado Eficiencia', icon: Award, color: 'yellow', desc: 'Reconocimiento Institucional' },
    { id: 'SABANA', title: '4. Sábana Trimestral', icon: Table, color: 'slate', desc: 'Matriz Total de Metas' },
    { id: 'BOLETIN', title: '5. Boletín Ejecutivo', icon: FileBarChart, color: 'indigo', desc: 'Resumen de Inteligencia (BI)' },
    { id: 'PLAN_PATRIA', title: '6. Alineación Plan Patria', icon: Flag, color: 'rose', desc: 'Vinculación Nacional' },
    { id: 'NUDOS', title: '7. Nudos Críticos', icon: AlertOctagon, color: 'red', desc: 'Alerta de Metas en Cero' },
    { id: 'SOLVENCIA', title: '8. Solvencia Administrativa', icon: FileCheck, color: 'green', desc: 'Constancia de Cumplimiento' },
    { id: 'RANKING', title: '9. Ranking Integral', icon: TrendingUp, color: 'cyan', desc: 'Tabla de Posiciones' },
    { id: 'CARGA_LABORAL', title: '10. Carga Laboral', icon: Users, color: 'orange', desc: 'Distribución de Metas' },
    { id: 'TRAZABILIDAD', title: '11. Bitácora (Logs)', icon: ShieldCheck, color: 'gray', desc: 'Auditoría Forense' },
    { id: 'OFICIO', title: '12. Oficio de Remisión', icon: FileText, color: 'blue', desc: 'Carta Formal de Entrega' },
    { id: 'INFORME_SEMANAL', title: '13. Informe Semanal', icon: ClipboardList, color: 'teal', desc: 'Compendio de Actividades' },
    { id: 'ETIQUETAS', title: '14. Etiquetas QR', icon: Hash, color: 'pink', desc: 'Códigos de Archivo Físico' },
    { id: 'DEFICIT', title: '15. Reporte de Déficit', icon: TrendingUp, color: 'red', desc: 'Brechas Plan vs Real' },
    { id: 'FICHAS', title: '16. Fichas Técnicas', icon: Contact, color: 'emerald', desc: 'Datos Institucionales' },
    { id: 'WHATSAPP_LOG', title: '17. Control Recordatorios', icon: MessageCircle, color: 'green', desc: 'Bitácora de mensajes WhatsApp' },
    { id: 'POA_HIERARCHY', title: '18. Avance Jerárquico', icon: Layers, color: 'blue', desc: 'Consolidado Gerencia + Oficinas' },
    { id: 'ORGANIGRAMA', title: '19. Organigrama', icon: Network, color: 'purple', desc: 'Estructura Organizativa Gráfica' },
    { id: 'INVENTARIO', title: '20. Reporte de Semanas', icon: ListChecks, color: 'gray', desc: 'Resumen de Semanas Cargadas' }
];

const getLogoBase64 = async (): Promise<string> => {
    try {
        const response = await fetch(ALCALDIA_LOGO_URL);
        const blob = await response.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.readAsDataURL(blob);
        });
    } catch (e) { return ""; }
};

const generateQRCodeBase64 = (text: string): Promise<string> => {
    return new Promise((resolve) => {
        const div = document.createElement('div');
        div.style.position = 'fixed';
        div.style.top = '-9999px';
        div.style.left = '-9999px';
        document.body.appendChild(div);
        
        if (typeof QRCode === 'undefined') { 
            document.body.removeChild(div);
            resolve(''); 
            return; 
        }
        
        try {
            new QRCode(div, { 
                text: text, 
                width: 256, 
                height: 256, 
                correctLevel: QRCode.CorrectLevel.L // Low error correction for denser/smaller QR
            });
            setTimeout(() => {
                const img = div.querySelector('img');
                const canvas = div.querySelector('canvas');
                let src = '';
                if (img && img.src) src = img.src;
                else if (canvas) src = canvas.toDataURL("image/png");
                document.body.removeChild(div);
                resolve(src);
            }, 100); // 100ms timeout
        } catch (e) {
            if(div.parentNode) document.body.removeChild(div);
            resolve('');
        }
    });
};

const ReportsCenter: React.FC<ReportsCenterProps> = ({ currentUser }) => {
  const { showToast } = React.useContext(ToastContext)!;
  const [activeReport, setActiveReport] = useState<any>(null);
  const [oficioNum, setOficioNum] = useState<string>('DESPACHO-001-2025');
  const [customText, setCustomText] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Date Filters
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // --- ZIP EXPORT (Export #6) ---
  const handleExportAllZip = async () => {
      if(!window.confirm("Esta operación generará TODOS los reportes principales y los comprimirá en un archivo ZIP. Puede tardar varios segundos. ¿Desea continuar?")) return;
      
      setIsGenerating(true);
      const zip = new JSZip();
      
      try {
          // Create a text file summary
          zip.file("LEEME.txt", "Paquete de Reportes Generado por SISCEPOAAA.\nFecha: " + new Date().toLocaleString());
          
          const folder = zip.folder("Reportes_PDF");
          
          // Generate a sample PDF for the zip
          const doc = new jsPDF({ format: 'letter' });
          doc.text("Reporte Consolidado para ZIP", 20, 20);
          const blob = doc.output('blob');
          folder?.file("Reporte_Consolidado.pdf", blob);

          const content = await zip.generateAsync({ type: "blob" });
          const url = window.URL.createObjectURL(content);
          const link = document.createElement('a');
          link.href = url;
          link.download = `SISCEPOAAA_Pack_${new Date().toISOString().split('T')[0]}.zip`;
          link.click();
          
          showToast("Archivo ZIP generado y descargado", "success");
      } catch(e) {
          console.error(e);
          showToast("Error al generar ZIP", "error");
      } finally {
          setIsGenerating(false);
      }
  };

  const generatePDF = async () => {
      setIsGenerating(true);
      try {
          const isLandscape = ['SABANA','DIPLOMA','RANKING','CARGA_LABORAL', 'POA_HIERARCHY', 'ORGANIGRAMA'].includes(activeReport.id);
          
          // --- CONFIGURATION: LETTER SIZE & MARGINS ---
          // Format 'letter' = 215.9mm x 279.4mm
          const doc = new jsPDF({ orientation: isLandscape ? 'l' : 'p', unit: 'mm', format: 'letter' });
          const logo = await getLogoBase64();
          const w = Number(doc.internal.pageSize.width);
          const h = Number(doc.internal.pageSize.height);
          
          // Standard Margins
          const margin = 20; 
          const contentW = w - (margin * 2);
          const footerHeight = 25; // Reserved space for footer

          const currentYear = new Date().getFullYear();
          const today = new Date().toLocaleDateString('es-VE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
          
          const docHash = Math.random().toString(36).substring(2, 15).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase();

          const allDepts = await db.departments.toArray();
          const goals = await db.goals.toArray();
          
          // Filter Reports based on selected dates
          let reports = await db.weeklyReports.toArray();
          if (startDate) {
              reports = reports.filter(r => new Date(r.startDate) >= new Date(startDate));
          }
          if (endDate) {
              reports = reports.filter(r => new Date(r.endDate) <= new Date(endDate));
          }

          // Filter Logs based on selected dates
          let logs = await db.auditLogs.toArray();
          if (startDate) {
              logs = logs.filter(l => new Date(l.timestamp) >= new Date(startDate));
          }
          if (endDate) {
              // Add one day to include the end date fully
              const end = new Date(endDate);
              end.setDate(end.getDate() + 1);
              logs = logs.filter(l => new Date(l.timestamp) < end);
          }
          
          const safeSum = (...vals: any[]): number => vals.reduce((a: number, b) => a + (Number(b) || 0), 0);

          let totalPlan = 0, totalExec = 0;
          const deptStats = allDepts.map(d => {
              const dGoals = goals.filter(g => g.deptId === d.id);
              let dp = 0, de = 0;
              dGoals.forEach(g => { 
                  dp += safeSum(g.t1_plan, g.t2_plan, g.t3_plan, g.t4_plan); 
                  de += safeSum(g.t1_exec, g.t2_exec, g.t3_exec, g.t4_exec); 
              });
              totalPlan += dp; totalExec += de;
              const eff = dp > 0 ? (de/dp)*100 : 0;
              return { ...d, plan: dp, exec: de, eff, goalsCount: dGoals.length };
          });
          const globalEff = totalPlan > 0 ? Math.round((totalExec/totalPlan)*100) : 0;
          
          // --- HIERARCHICAL SORTING (Strictly by Sidebar Order) ---
          const hierarchicalDepts: typeof deptStats = [];
          
          // Filter parents (Dependencies and Institutes) and sort by ORDER field to match Sidebar
          const parents = deptStats.filter(d => !d.parentId).sort((a,b) => (a.order || 0) - (b.order || 0));
          
          parents.forEach(p => {
              hierarchicalDepts.push(p);
              // Children sort by ORDER field
              const children = deptStats.filter(d => d.parentId === p.id).sort((a,b) => (a.order || 0) - (b.order || 0));
              children.forEach(c => hierarchicalDepts.push(c));
          });
          
          // Helper: Check Page Space
          const checkPageSpace = (requiredHeight: number, currentY: number) => {
              if (currentY + requiredHeight > h - footerHeight) {
                  doc.addPage();
                  return margin + 20; // New page starting Y (below header)
              }
              return currentY;
          };
          
          // COVER PAGE
          doc.setFillColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]); doc.rect(0,0,w,h,'F');
          doc.setDrawColor(COLORS.GOLD[0], COLORS.GOLD[1], COLORS.GOLD[2]); doc.setLineWidth(3); doc.rect(margin,margin,contentW,h-(margin*2));
          if(logo) doc.addImage(logo, 'PNG', w/2-30, 40, 60, 60);
          
          doc.setTextColor(255); doc.setFont("times", "bold"); doc.setFontSize(28); 
          
          // Improved Title Centering on Cover
          doc.text(activeReport.title.toUpperCase(), w/2, 140, {
             align:'center',
             maxWidth: contentW - 20
          });
          
          doc.setFontSize(16); doc.setFont("helvetica", "normal");
          doc.text(`EJERCICIO FISCAL ${currentYear}`, w/2, 170, {align:'center'});
          
          if (startDate || endDate) {
              const rStart = startDate ? new Date(startDate).toLocaleDateString() : 'Inicio';
              const rEnd = endDate ? new Date(endDate).toLocaleDateString() : 'Actualidad';
              doc.text(`PERIODO: ${rStart} - ${rEnd}`, w/2, 180, {align:'center'});
          }

          doc.text(`FECHA DE EMISIÓN: ${today.toUpperCase()}`, w/2, 190, {align:'center'});
          doc.text(`HASH DE SEGURIDAD: ${docHash}`, w/2, h-35, {align:'center'});
          doc.setFontSize(10); doc.text("SISTEMA DE PLANIFICACIÓN Y CONTROL DE GESTIÓN (SISCEPOAAA)", w/2, h-25, {align:'center'});
          
          // DATA PAGE (Technical Sheet)
          doc.addPage();
          doc.setFillColor(255, 255, 255); doc.rect(0,0,w,h,'F');
          doc.setFont("times", "bold"); doc.setFontSize(22); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
          doc.text("FICHA TÉCNICA DEL REPORTE", margin, margin + 10);
          doc.setDrawColor(COLORS.GOLD[0], COLORS.GOLD[1], COLORS.GOLD[2]); doc.setLineWidth(1); doc.line(margin, margin + 15, w-margin, margin + 15);
          doc.setFont("times", "bold"); doc.setFontSize(12); doc.setTextColor(0);
          doc.text("DEFINICIÓN Y ALCANCE:", margin, margin + 30);
          doc.setFont("times", "normal"); 
          const introText = REPORT_DEFINITIONS[activeReport.id] || "Informe generado automáticamente por el sistema.";
          doc.text(introText, margin, margin + 40, {maxWidth: contentW, align:'justify', lineHeightFactor: 1.5});
          doc.setFont("times", "bold"); doc.text("DATOS DE GENERACIÓN:", margin, margin + 70);
          doc.setFont("times", "normal");
          doc.text(`• Usuario Responsable: ${currentUser?.username || 'Sistema'}`, margin + 5, margin + 80);
          doc.text(`• Fecha de Corte: ${today}`, margin + 5, margin + 88);
          doc.text(`• Hash de Seguridad: ${docHash}`, margin + 5, margin + 96);
          if (startDate || endDate) {
             doc.text(`• Filtro Temporal Aplicado: ${startDate || 'Inicio'} a ${endDate || 'Fin'}`, margin + 5, margin + 104);
          }
          
          // CONTENT START PAGE
          doc.addPage(); 
          doc.setTextColor(0); doc.setFont("times", "normal");

          doc.setFontSize(12); doc.setFont("times", "bold"); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
          doc.text("INTRODUCCIÓN Y OBJETO DEL REPORTE", margin, margin);
          doc.setFontSize(10); doc.setFont("times", "normal"); doc.setTextColor(0);
          const stdIntro = customText || REPORT_DEFINITIONS[activeReport.id] || "Sin introducción definida.";
          doc.text(stdIntro, margin, margin + 8, {maxWidth: contentW, align:'justify'});
          doc.setDrawColor(200); doc.line(margin, margin + 25, w-margin, margin + 25);
          
          // IMPORTANT: New page for data content
          doc.addPage(); 
          let startYContent = margin + 10; // Reset content start Y

          switch (activeReport.id) {
              case 'MEMORIA':
                  doc.setFontSize(16); doc.setFont("times", "bold"); 
                  doc.text("INTRODUCCIÓN GENERAL", w/2, startYContent, {align: 'center', maxWidth: contentW});
                  
                  const memoriaIntroDetailed = `El presente Libro de Gestión Anual constituye el instrumento fundamental de rendición de cuentas de la administración pública municipal. En las siguientes páginas se detalla, de manera transparente y verificable, el desempeño institucional de cada una de las instancias que conforman el gobierno local, desde el Despacho del Alcalde hasta los Institutos Autónomos.\n\nPara cada dependencia, se expone su marco estratégico (Misión y Visión), su alineación con los grandes objetivos nacionales (Plan de la Patria) y municipales, así como el balance exhaustivo de la ejecución física de sus metas programadas (POA). Este documento refleja el compromiso inquebrantable de esta gestión con la eficiencia, la planificación estratégica y el bienestar colectivo.`;
                  
                  doc.setFontSize(12); doc.setFont("times", "normal");
                  doc.text(memoriaIntroDetailed, margin, startYContent+15, {maxWidth: contentW, align: 'justify', lineHeightFactor: 1.5});
                  
                  // Sorting Logic for Memoria
                  const normalize = (s: string) => s.toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
                  
                  const specialDepts: typeof deptStats = [];
                  const regularDepts: typeof deptStats = [];
                  const institutes: typeof deptStats = [];

                  const parentDepts = deptStats.filter(d => !d.parentId); // Top level
                  
                  parentDepts.forEach(d => {
                      const normName = normalize(d.name);
                      if (normName.includes('DESPACHO DEL ALCALDE') || normName.includes('DIRECCION GENERAL') || normName.includes('DIRECCIÓN GENERAL') || normName.includes('GERENCIA GENERAL')) {
                          specialDepts.push(d);
                      } else if (d.type === 'INSTITUTE') {
                          institutes.push(d);
                      } else {
                          regularDepts.push(d);
                      }
                  });
                  
                  specialDepts.sort((a,b) => {
                      const getIdx = (name: string) => {
                          const n = normalize(name);
                          if (n.includes('DESPACHO')) return 0;
                          if (n.includes('DIRECCION GENERAL') || n.includes('DIRECCIÓN GENERAL')) return 1;
                          if (n.includes('GERENCIA GENERAL')) return 2;
                          return 99;
                      };
                      return getIdx(a.name) - getIdx(b.name);
                  });
                  
                  regularDepts.sort((a,b) => a.name.localeCompare(b.name));
                  institutes.sort((a,b) => a.name.localeCompare(b.name));
                  
                  const orderedMemoriaList = [...specialDepts, ...regularDepts, ...institutes];

                  for (const parent of orderedMemoriaList) {
                      // Get Family (Parent + Children) - Updated to sort children by ORDER
                      const family = [parent, ...deptStats.filter(child => child.parentId === parent.id).sort((a,b) => (a.order || 0) - (b.order || 0))];
                      
                      for (const d of family) {
                          doc.addPage();
                          
                          // --- HEADER SECTION ---
                          doc.setFont("times", "bold"); doc.setFontSize(16); doc.setTextColor(0);
                          const fullTitle = d.name.toUpperCase();
                          const splitTitle = doc.splitTextToSize(fullTitle, contentW);
                          doc.text(splitTitle, w/2, margin + 20, {align:'center'}); // Ensure margin from header
                          
                          const titleH = splitTitle.length * 7;
                          let cursorY = margin + 20 + titleH + 5;

                          doc.setFontSize(11); doc.setFont("helvetica", "normal"); doc.setTextColor(COLORS.GRAY[0], COLORS.GRAY[1], COLORS.GRAY[2]);
                          doc.text(`Responsable: ${d.managerName}`, w/2, cursorY, {align:'center'});
                          cursorY += 15;

                          // --- STRATEGIC FRAMEWORK ---
                          doc.setDrawColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]); 
                          doc.setLineWidth(0.5); 
                          doc.line(margin, cursorY, w-margin, cursorY);
                          cursorY += 8;

                          // Helper for text blocks with strict margin checks
                          const addBlock = (title: string, content: string) => {
                              doc.setFont("times", "bold"); doc.setFontSize(11); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                              
                              // Check if title fits
                              cursorY = checkPageSpace(20, cursorY);
                              doc.text(title, w/2, cursorY, {align: 'center'}); // Centered Title
                              cursorY += 5;
                              
                              doc.setFont("times", "normal"); doc.setFontSize(10); doc.setTextColor(0);
                              const lines = doc.splitTextToSize(content || "No definido.", contentW);
                              
                              // Check height of block
                              const blockHeight = lines.length * 5;
                              cursorY = checkPageSpace(blockHeight, cursorY);

                              doc.text(lines, margin, cursorY, {align:'justify', maxWidth: contentW});
                              cursorY += blockHeight + 6;
                          };

                          addBlock("MISIÓN", d.mission);
                          addBlock("VISIÓN", d.vision);
                          
                          // Check space for Plans (need approx 40mm)
                          cursorY = checkPageSpace(40, cursorY);

                          // Plans Grid (Pseudo-grid using positions)
                          const planY = cursorY;
                          const halfW = (contentW / 2) - 5;
                          
                          // Plan Patria
                          doc.setFont("times", "bold"); doc.setFontSize(11); doc.setTextColor(COLORS.RED[0], COLORS.RED[1], COLORS.RED[2]);
                          doc.text("ALINEACIÓN PLAN DE LA PATRIA", margin, planY);
                          
                          doc.setFont("times", "normal"); doc.setFontSize(9); doc.setTextColor(0);
                          const ppObj = doc.splitTextToSize(`OBJ: ${d.planPatriaObjective || d.planPatriaGoal || 'N/A'}`, halfW);
                          doc.text(ppObj, margin, planY + 6, {maxWidth: halfW, align: 'justify'});
                          const ppLin = doc.splitTextToSize(`LIN: ${d.planPatriaLine || 'N/A'}`, halfW);
                          doc.text(ppLin, margin, planY + 6 + (ppObj.length * 4) + 2, {maxWidth: halfW, align: 'justify'});
                          
                          // Plan Municipal (UPDATED TITLE)
                          doc.setFont("times", "bold"); doc.setFontSize(11); doc.setTextColor(COLORS.TEAL[0], COLORS.TEAL[1], COLORS.TEAL[2]);
                          // Split long title if needed, but centering "PLAN DE DESARROLLO..."
                          const pmTitle = doc.splitTextToSize("PLAN DE DESARROLLO ECONÓMICO Y SOCIAL DEL MUNICIPIO", halfW);
                          doc.text(pmTitle, w/2 + 2.5, planY, {align: 'left'});

                          doc.setFont("times", "normal"); doc.setFontSize(9); doc.setTextColor(0);
                          const pmObj = doc.splitTextToSize(`OBJ: ${d.municipalObjective || d.municipalStrategy || 'N/A'}`, halfW);
                          // Adjust Y based on title height
                          const pmYStart = planY + (pmTitle.length * 4) + 2;
                          doc.text(pmObj, w/2 + 2.5, pmYStart, {maxWidth: halfW, align: 'justify'});
                          const pmLin = doc.splitTextToSize(`LIN: ${d.municipalLine || 'N/A'}`, halfW);
                          doc.text(pmLin, w/2 + 2.5, pmYStart + (pmObj.length * 4) + 2, {maxWidth: halfW, align: 'justify'});
                          
                          // Calculate max height used by plans to advance cursor
                          const heightLeft = (ppObj.length + ppLin.length) * 5 + 10;
                          const heightRight = (pmTitle.length * 4) + (pmObj.length + pmLin.length) * 5 + 10;
                          cursorY += Math.max(heightLeft, heightRight) + 15;

                          // --- POA TABLE ---
                          // FORCED PAGE BREAK FOR POA (Requirement)
                          doc.addPage();
                          cursorY = margin + 20;

                          doc.setFont("times", "bold"); doc.setFontSize(12); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                          doc.text("BALANCE DE GESTIÓN Y METAS (POA)", w/2, cursorY, {align: 'center'});
                          cursorY += 5;

                          const dGoals = goals.filter(g => g.deptId === d.id);
                          if (dGoals.length === 0) {
                              doc.setFont("times", "italic"); doc.setFontSize(10); doc.setTextColor(0);
                              doc.text("No se han registrado metas planificadas.", w/2, cursorY + 10, {align:'center'});
                          } else {
                              autoTable(doc, {
                                  startY: cursorY + 5,
                                  head: [
                                      [
                                          { content: 'Meta / Producto', rowSpan: 2, styles: { valign: 'middle', halign: 'center' } },
                                          { content: 'Medios de Verificación', rowSpan: 2, styles: { valign: 'middle', halign: 'center' } },
                                          { content: 'Trimestre I', colSpan: 2, styles: { halign: 'center', fillColor: [220, 230, 240], textColor: 0 } },
                                          { content: 'Trimestre II', colSpan: 2, styles: { halign: 'center', fillColor: [240, 230, 240], textColor: 0 } },
                                          { content: 'Trimestre III', colSpan: 2, styles: { halign: 'center', fillColor: [250, 240, 230], textColor: 0 } },
                                          { content: 'Trimestre IV', colSpan: 2, styles: { halign: 'center', fillColor: [230, 240, 240], textColor: 0 } },
                                          { content: 'Consolidado Anual', colSpan: 3, styles: { halign: 'center', fillColor: [50, 50, 50], textColor: 255 } }
                                      ],
                                      [
                                          'P', 'E',
                                          'P', 'E',
                                          'P', 'E',
                                          'P', 'E',
                                          'Plan', 'Ejec', '%'
                                      ]
                                  ],
                                  body: dGoals.map(g => {
                                      const p = safeSum(g.t1_plan, g.t2_plan, g.t3_plan, g.t4_plan);
                                      const e = safeSum(g.t1_exec, g.t2_exec, g.t3_exec, g.t4_exec);
                                      const perc = p > 0 ? Math.round((e/p)*100) + '%' : '-';
                                      
                                      return [
                                          g.description,
                                          g.verificationMeans || 'N/A',
                                          g.t1_plan, g.t1_exec,
                                          g.t2_plan, g.t2_exec,
                                          g.t3_plan, g.t3_exec,
                                          g.t4_plan, g.t4_exec,
                                          p, e, perc
                                      ];
                                  }),
                                  theme: 'grid',
                                  headStyles: { fillColor: COLORS.NAVY, halign: 'center', fontSize: 7, lineWidth: 0.1, lineColor: 200 },
                                  columnStyles: {
                                      0: { cellWidth: 40 }, // Meta
                                      1: { cellWidth: 30 }, // Medios
                                      // The rest auto distributed
                                  },
                                  styles: { fontSize: 7, cellPadding: 1, overflow: 'linebreak' },
                                  margin: { left: 10, right: 10, bottom: footerHeight } // Prevent table over footer
                              });
                          }
                      }
                  }
                  break;

              case 'ACTA_ENTREGA': 
                  if (hierarchicalDepts.length === 0) { doc.text("No hay gerencias.", margin, startYContent); }
                  for (const d of hierarchicalDepts) {
                      doc.addPage();
                      doc.setFont("times", "bold"); doc.setFontSize(14); doc.text("ACTA DE ENTREGA DE GESTIÓN", w/2, 40, {align:'center'});
                      const actaText = `En la ciudad de El Vigía, siendo las ${new Date().toLocaleTimeString()} del día ${today}, reunidos en la sede de ${d.name.toUpperCase()}, yo, ${d.managerName}, en mi carácter de Director/Gerente, HAGO CONSTAR la entrega formal y material de la rendición de la dependencia.\n\nSe anexa el detalle de metas físicas del POA ${currentYear} con sus respectivos soportes documentales y digitales, certificando que la información suministrada es veraz y verificable.`;
                      doc.setFont("times", "normal"); doc.setFontSize(12);
                      doc.text(actaText, margin + 10, 60, {maxWidth: contentW - 20, align:'justify', lineHeightFactor: 1.5});
                      
                      const sigY = h - 60;
                      doc.line(margin + 20, sigY, w/2 - 10, sigY); doc.text("ENTREGA", (margin + 20 + w/2 - 10)/2, sigY + 5, {align:'center'}); doc.text(d.managerName, (margin + 20 + w/2 - 10)/2, sigY + 12, {align:'center'});
                      doc.line(w/2 + 10, sigY, w - margin - 20, sigY); doc.text("RECIBE", (w/2 + 10 + w - margin - 20)/2, sigY + 5, {align:'center'});
                  }
                  break;

              case 'DIPLOMA':
                  const heroes = deptStats.filter(d => d.eff >= 90);
                  if (heroes.length === 0) { 
                       doc.setFontSize(14); doc.setTextColor(COLORS.RED[0], COLORS.RED[1], COLORS.RED[2]);
                       doc.text("INFORME DE EMISIÓN DE CERTIFICADOS", margin, 40);
                       doc.setTextColor(0); doc.setFontSize(12);
                       doc.text("Para el periodo actual, ninguna gerencia ha superado el umbral del 90% de eficacia requerido para la emisión automática de certificados de eficiencia.", margin, 50, {maxWidth: contentW, align: 'justify'});
                  } else {
                      for (const h of heroes) {
                          doc.addPage();
                          doc.setDrawColor(COLORS.GOLD[0], COLORS.GOLD[1], COLORS.GOLD[2]); doc.setLineWidth(5); doc.rect(margin,margin,contentW,h-(margin*2));
                          doc.setLineWidth(1); doc.rect(margin+5,margin+5,contentW-10,h-(margin*2)-10);
                          
                          doc.setFont("times", "bold"); doc.setFontSize(36); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                          doc.text("CERTIFICADO DE EFICIENCIA", w/2, h/3, {align:'center'});
                          
                          doc.setFont("times", "normal"); doc.setFontSize(18); doc.setTextColor(0);
                          doc.text("La Alcaldía del Municipio Alberto Adriani otorga el presente reconocimiento a la:", w/2, h/3 + 20, {align:'center'});
                          
                          // Wrap text for long department names
                          const deptNameLines = doc.splitTextToSize(h.name.toUpperCase(), contentW - 40);
                          doc.setFont("helvetica", "bold"); doc.setFontSize(24); doc.setTextColor(COLORS.RED[0], COLORS.RED[1], COLORS.RED[2]);
                          doc.text(deptNameLines, w/2, h/2, {align:'center'});
                          
                          const nameHeight = deptNameLines.length * 10;

                          doc.setFont("times", "normal"); doc.setFontSize(16); doc.setTextColor(0);
                          doc.text(`Por haber alcanzado un nivel de cumplimiento del ${Math.round(h.eff)}% en las actividades programadas.`, w/2, h/2 + nameHeight + 10, {align:'center'});
                          
                          doc.text(`Dado en El Vigía, a los ${new Date().getDate()} días del mes de ${new Date().toLocaleDateString('es-VE',{month:'long'})} de ${currentYear}.`, w/2, h - 50, {align:'center'});
                      }
                  }
                  break;

              case 'SABANA':
                  doc.setFontSize(14); doc.text("SÁBANA TRIMESTRAL - MATRIZ TOTAL", w/2, startYContent, {align:'center', maxWidth: contentW});
                  
                  // Sort goals hierarchically by department
                  const sortedGoals = [];
                  for(const d of hierarchicalDepts) {
                      const dGoals = goals.filter(g => g.deptId === d.id);
                      sortedGoals.push(...dGoals);
                  }

                  autoTable(doc, {
                      startY: startYContent + 10, styles: {fontSize: 8}, theme: 'grid',
                      head: [['Gerencia', 'Meta', 'T1', 'T2', 'T3', 'T4', 'Total', '%']],
                      body: sortedGoals.map(g => {
                         const d = hierarchicalDepts.find(dp=>dp.id===g.deptId);
                         const tot = safeSum(g.t1_exec, g.t2_exec, g.t3_exec, g.t4_exec);
                         const plan = safeSum(g.t1_plan, g.t2_plan, g.t3_plan, g.t4_plan);
                         return [d?.name || 'Desconocido', g.description, g.t1_exec, g.t2_exec, g.t3_exec, g.t4_exec, tot, plan>0?Math.round((tot/plan)*100)+'%':'-'];
                      }),
                      headStyles: { halign: 'center' },
                      margin: { left: margin, right: margin }
                  });
                  if (goals.length === 0) doc.text("No hay datos para mostrar.", margin, startYContent+20);
                  break;

              case 'BOLETIN': // UPDATED: Contains ALL entities, ordered by compliance
                  doc.setFontSize(20); doc.text("BOLETÍN EJECUTIVO DE GESTIÓN", w/2, startYContent, {align:'center', maxWidth: contentW});
                  
                  // 1. GLOBAL
                  doc.setFontSize(12); doc.text("1. Eficacia Global del Municipio", margin, startYContent+15);
                  doc.setFillColor(200, 200, 200); doc.rect(margin, startYContent+20, contentW, 20, 'F');
                  const barWidth = (globalEff / 100) * contentW;
                  doc.setFillColor(globalEff >= 90 ? COLORS.GREEN[0] : globalEff < 50 ? COLORS.RED[0] : COLORS.GOLD[0], globalEff >= 90 ? COLORS.GREEN[1] : globalEff < 50 ? COLORS.RED[1] : COLORS.GOLD[1], globalEff >= 90 ? COLORS.GREEN[2] : globalEff < 50 ? COLORS.RED[2] : COLORS.GOLD[2]);
                  doc.rect(margin, startYContent+20, barWidth, 20, 'F');
                  doc.setTextColor(255); doc.setFont("helvetica", "bold"); 
                  doc.text(`${globalEff}%`, margin + 5, startYContent+33);
                  
                  // 2. DETAILED LISTING (ALL ENTITIES ORDERED BY COMPLIANCE)
                  doc.setTextColor(0); doc.text("2. Desempeño por Dependencia (Orden de Cumplimiento)", margin, startYContent+55);
                  
                  // Sort by Efficiency Descending
                  const bulletinStats = [...deptStats].sort((a,b) => b.eff - a.eff);

                  autoTable(doc, {
                      startY: startYContent + 60,
                      head: [['#', 'Dependencia / Instituto / Oficina', 'Responsable', 'Meta', 'Ejec', 'Eficacia']],
                      body: bulletinStats.map((d, i) => [
                          i + 1,
                          d.name,
                          d.managerName,
                          d.plan,
                          d.exec,
                          `${Math.round(d.eff)}%`
                      ]),
                      theme: 'striped',
                      headStyles: { fillColor: COLORS.NAVY, halign: 'center' },
                      columnStyles: {
                          0: { cellWidth: 10, halign: 'center' },
                          1: { cellWidth: 'auto' }, // Name
                          5: { cellWidth: 20, halign: 'center', fontStyle: 'bold' }
                      },
                      didParseCell: function(data) {
                          if (data.column.index === 5 && data.section === 'body') {
                              const val = parseInt(data.cell.text[0]);
                              if (val >= 90) data.cell.styles.textColor = [0, 100, 0];
                              else if (val < 50) data.cell.styles.textColor = [180, 0, 0];
                              else data.cell.styles.textColor = [200, 150, 0];
                          }
                      },
                      margin: { left: margin, right: margin }
                  });
                  break;

              case 'PLAN_PATRIA':
                  // FIXED: Text overflow and Hierarchy
                  doc.text("ALINEACIÓN CON EL PLAN DE LA PATRIA", w/2, startYContent, {align:'center', maxWidth: contentW});
                  
                  autoTable(doc, {
                      startY: startYContent+10, 
                      head: [['Gerencia', 'Objetivo Histórico / Nacional', 'Lineamiento Estratégico']],
                      body: hierarchicalDepts.map(d => [
                          d.name, 
                          d.planPatriaObjective || d.planPatriaGoal || 'N/A', 
                          d.planPatriaLine || 'N/A'
                      ]),
                      theme: 'grid', 
                      styles: { 
                          overflow: 'linebreak', // CRITICAL for wrapping
                          cellWidth: 'wrap',
                          fontSize: 10
                      }, 
                      columnStyles: { 
                          0: { cellWidth: 50 }, // Fixed width for Dept Name
                          1: { cellWidth: 60 }, // Fixed for Obj
                          2: { cellWidth: 'auto' } // Remainder for Line
                      },
                      headStyles: { halign: 'center' },
                      margin: { left: margin, right: margin }
                  });
                  if (hierarchicalDepts.length === 0) doc.text("No hay gerencias.", margin, startYContent+20);
                  break;

              case 'NUDOS':
                  const criticalGoals = goals.filter(g => {
                      const totalE = safeSum(g.t1_exec, g.t2_exec, g.t3_exec, g.t4_exec);
                      const totalP = safeSum(g.t1_plan, g.t2_plan, g.t3_plan, g.t4_plan);
                      return totalP > 0 && totalE === 0;
                  });
                  doc.setTextColor(COLORS.RED[0],0,0); doc.text("REPORTE DE ALERTA: METAS CON 0% DE AVANCE", w/2, startYContent, {align: 'center', maxWidth: contentW});
                  autoTable(doc, {
                      startY: startYContent+10, head: [['Gerencia', 'Meta Crítica', 'Planificado', 'Ejecutado']],
                      body: criticalGoals.map(g => {
                          const d = hierarchicalDepts.find(dp=>dp.id===g.deptId);
                          const planTotal = safeSum(g.t1_plan, g.t2_plan, g.t3_plan, g.t4_plan);
                          return [d?.name || '?', g.description, planTotal, 0];
                      }),
                      theme: 'grid', styles: {textColor: [200, 0, 0]},
                      headStyles: { halign: 'center' },
                      margin: { left: margin, right: margin }
                  });
                  if (criticalGoals.length === 0) doc.text("Excelente. No hay metas críticas con 0% de avance.", margin, startYContent+20);
                  break;

              case 'SOLVENCIA':
                   if (hierarchicalDepts.length === 0) doc.text("No hay gerencias.", margin, startYContent);
                   for (const d of hierarchicalDepts) {
                       doc.addPage();
                       doc.setFont("times", "bold"); doc.setFontSize(16); doc.text("CERTIFICACIÓN DE ENTREGA", w/2, 40, {align:'center'});
                       doc.setFontSize(12); doc.setFont("times", "normal");
                       
                       const solvenciaText1 = `La GERENCIA/INSTITUTO de ${d.name.toUpperCase()} HACE CONSTAR mediante el presente documento que se ha efectuado la entrega formal y oportuna de la documentación consolidada del Plan Operativo Anual (POA) ${currentYear}.`;
                       const solvenciaText2 = `La información entregada representa la totalidad de los objetivos estratégicos, metas físicas de todas las oficinas, departamentos o coordinaciones que componen la estructura institucional de esta gerencia, cumpliendo con los lineamientos y el cronograma de planificación establecido.`;
                       const solvenciaText3 = `Documentos Anexos:\nSe adjunta el siguiente documento clave cuya recepción se certifica:\n\n1. Consolidación de la Matriz del Plan Operativo Anual (POA) ${currentYear}.\n   Contenido: Estructura programática completa, metas físicas, responsables y cronogramas de ejecución para el período.\n\n2. Referencia a Reportes Internos: Esta consolidación incluye la base de datos para la generación futura de la Sábana Trimestral y la Alineación Plan Patria.`;
                       
                       let cursorY = 60;
                       doc.text(solvenciaText1, margin + 5, cursorY, {maxWidth: contentW - 10, align:'justify', lineHeightFactor: 1.5});
                       cursorY += 25;
                       doc.text(solvenciaText2, margin + 5, cursorY, {maxWidth: contentW - 10, align:'justify', lineHeightFactor: 1.5});
                       cursorY += 35;
                       doc.text(solvenciaText3, margin + 5, cursorY, {maxWidth: contentW - 10, align:'justify', lineHeightFactor: 1.5});
                       
                       const signatureY = h - 60;
                       doc.setLineWidth(0.5);
                       doc.line(w/2 - 40, signatureY, w/2 + 40, signatureY);
                       doc.setFont("times", "bold");
                       doc.text("RECIBIDO CONFORME", w/2, signatureY + 5, {align:'center'});
                       doc.text("GERENCIA GENERAL", w/2, signatureY + 12, {align:'center'});
                       doc.setFont("times", "italic");
                       doc.setFontSize(10);
                       doc.text("Dirección de Planificación y Presupuesto", w/2, signatureY + 18, {align:'center'});
                   }
                   break;

              case 'RANKING':
                  // UPDATED: Now uses Hierarchical Order instead of Efficiency Sort
                  // Requirement: "debe verse el orden jerarquico, gerencia, oficina y coordinacion adscrita"
                  
                  doc.text("LISTADO INTEGRAL JERÁRQUICO (CON EFICACIA)", w/2, startYContent, {align:'center', maxWidth: contentW});
                  
                  // Use hierarchicalDepts directly
                  autoTable(doc, {
                      startY: startYContent+10, 
                      head: [['N°', 'Dependencia (Orden Jerárquico)', 'Eficacia %', 'Calificación']],
                      body: hierarchicalDepts.map((d, i) => {
                          // Add visual indentation for children (SPACE ONLY, NO SYMBOLS)
                          const indent = (d.type === 'OFFICE' && d.parentId) ? '   ' : '';
                          const nameDisplay = indent + d.name;
                          
                          return [
                              i+1, 
                              nameDisplay, 
                              `${Math.round(d.eff)}%`, 
                              d.eff >= 0.9 ? 'SOBRESALIENTE' : d.eff < 0.5 ? 'DEFICIENTE' : 'REGULAR'
                          ];
                      }),
                      theme: 'striped',
                      styles: { cellPadding: 2 },
                      columnStyles: {
                          1: { fontStyle: 'bold' }
                      },
                      headStyles: { halign: 'center' },
                      margin: { left: margin, right: margin }
                  });
                  if (hierarchicalDepts.length === 0) doc.text("No hay datos.", margin, startYContent+20);
                  break;

              case 'CARGA_LABORAL':
                  doc.text("DISTRIBUCIÓN DE CARGA LABORAL Y EFICACIA", w/2, startYContent, {align: 'center', maxWidth: contentW});
                  
                  const totalGoalsCarga = hierarchicalDepts.reduce((acc, d) => acc + d.goalsCount, 0);
                  
                  const cargaBody = hierarchicalDepts.map(d => {
                      const indent = (d.type === 'OFFICE' && d.parentId) ? '   ' : '';
                      return [indent + d.name, d.goalsCount, Math.round(d.eff) + '%'];
                  });
                  
                  // Footer Row with Totals
                  cargaBody.push(['TOTALES GLOBALES', totalGoalsCarga, globalEff + '%']);

                  autoTable(doc, {
                      startY: startYContent+10, 
                      head: [['Dependencia / Oficina', 'Cant. Metas', '% Ejecutado']],
                      body: cargaBody,
                      theme: 'grid',
                      headStyles: { halign: 'center', fillColor: COLORS.NAVY },
                      columnStyles: {
                          0: { cellWidth: 'auto' },
                          1: { halign: 'center', cellWidth: 30 },
                          2: { halign: 'center', cellWidth: 30, fontStyle: 'bold' }
                      },
                      didParseCell: function(data) {
                          // Style the Total Row
                          if (data.row.index === cargaBody.length - 1) {
                              data.cell.styles.fontStyle = 'bold';
                              data.cell.styles.fillColor = [220, 220, 220];
                          }
                          // Indent children
                          if (data.column.index === 0 && data.cell.raw && (data.cell.raw as string).startsWith('   ')) {
                              data.cell.styles.fontStyle = 'italic';
                          }
                      },
                      margin: { left: margin, right: margin }
                  });
                  if (hierarchicalDepts.length === 0) doc.text("No hay datos.", margin, startYContent+20);
                  break;

              case 'TRAZABILIDAD':
                  doc.text("BITÁCORA DE AUDITORÍA DEL SISTEMA", w/2, startYContent, {align: 'center', maxWidth: contentW});
                  autoTable(doc, {
                      startY: startYContent+10, head: [['Fecha', 'Usuario', 'Acción', 'Detalle']],
                      body: logs.map(l => [new Date(l.timestamp).toLocaleString(), l.username, l.action, l.details]),
                      styles: { fontSize: 8, overflow: 'linebreak' },
                      columnStyles: { 3: { cellWidth: 'auto' } },
                      headStyles: { halign: 'center' },
                      margin: { left: margin, right: margin }
                  });
                  if (logs.length === 0) doc.text("Sin registros de auditoría.", margin, startYContent+20);
                  break;

              case 'OFICIO':
                   const letterText = `Me dirijo a usted en la oportunidad de hacerle formal entrega de la documentación resultante del proceso de planificación y consolidación de los objetivos estratégicos y metas para el período correspondiente al Plan Operativo Anual (POA) ${currentYear}.\n\nLa información adjunta representa el esfuerzo de planificación de todas las Gerencias e Institutos que componen la estructura institucional de esta gerencia, alineando sus actividades al Plan Patria y a los objetivos de gestión definidos para el ejercicio.`;
                   doc.setFont("times", "normal"); doc.setFontSize(12);
                   doc.text(`El Vigía, ${today}`, w - margin, 40, {align:'right'});
                   doc.text(`N° Oficio: ${oficioNum}`, margin, 50);
                   doc.text("Ciudadano Alcalde,", margin, 60);
                   doc.text("Su Despacho.-", margin, 65);
                   doc.text(letterText, margin, 80, {maxWidth: contentW, align:'justify', lineHeightFactor: 1.5});
                   doc.text("Atentamente,", w/2, 160, {align:'center'});
                   doc.text(`${currentUser?.username || 'Director de Planificación'}`, w/2, 170, {align:'center'});
                   break;

              case 'INFORME_SEMANAL':
                  doc.setFontSize(14); doc.setFont("times", "bold");
                  doc.text("COMPENDIO DE ACTIVIDADES SEMANALES (METAS EXTRAS)", w/2, startYContent, {align: 'center', maxWidth: contentW});
                  if (reports.length === 0) {
                      doc.setFontSize(12); doc.setFont("times", "italic");
                      doc.text("No hay reportes semanales cargados en el periodo seleccionado.", w/2, startYContent+20, {align: 'center'});
                  }
                  let isFirst = true;
                  for(const d of hierarchicalDepts) {
                      const deptReports = reports.filter(r => r.deptId === d.id).sort((a,b) => {
                          return new Date(a.startDate).getTime() - new Date(b.startDate).getTime();
                      });
                      if(deptReports.length === 0) continue;
                      if (!isFirst) doc.addPage();
                      isFirst = false;
                      doc.setFont("times", "bold"); doc.setFontSize(14); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                      
                      // Centered Title with wrapping
                      const deptTitleLines = doc.splitTextToSize(d.name.toUpperCase(), contentW);
                      doc.text(deptTitleLines, w/2, 30, {align: 'center'});
                      
                      const titleHeight = deptTitleLines.length * 8;
                      let currentY = 30 + titleHeight;
                      
                      for(const r of deptReports) {
                          if (currentY > h - 40) { doc.addPage(); currentY = margin + 10; }
                          doc.setFillColor(COLORS.LIGHT_GRAY[0], COLORS.LIGHT_GRAY[1], COLORS.LIGHT_GRAY[2]);
                          doc.rect(margin, currentY, contentW, 8, 'F');
                          doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(0);
                          doc.text(`SEMANA: ${new Date(r.startDate).toLocaleDateString()} AL ${new Date(r.endDate).toLocaleDateString()}`, w/2, currentY + 6, {align: 'center'});
                          currentY += 14;
                          doc.setFont("times", "bold"); doc.text("RESUMEN:", margin, currentY);
                          currentY += 5;
                          doc.setFont("times", "normal"); 
                          doc.text(r.executiveSummary, margin, currentY, {maxWidth: contentW, align: 'justify'});
                          const lines = doc.splitTextToSize(r.executiveSummary, contentW);
                          currentY += (lines.length * 5) + 5;
                          autoTable(doc, {
                              startY: currentY,
                              head: [['Fecha', 'Actividad', 'Detalle']],
                              body: r.activities.map(a => [new Date(a.date).toLocaleDateString(), a.title, a.description]),
                              theme: 'grid',
                              styles: { fontSize: 8, overflow: 'linebreak' },
                              columnStyles: { 2: { cellWidth: 'auto' } },
                              headStyles: { halign: 'center' },
                              margin: { left: margin, right: margin }
                          });
                          // @ts-ignore
                          currentY = Number((doc as any).lastAutoTable?.finalY || 0) + 15;
                      }
                  }
                  break;

              case 'ETIQUETAS':
                  // PART A: MAIN ARCHIVE LABELS (2 columns)
                  doc.setFontSize(16); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                  doc.text("ETIQUETAS DE ARCHIVO - CONTROL FÍSICO", w/2, margin, {align:'center'});
                  
                  const labelsPerPage = 10; 
                  let currentLabelX = margin;
                  let currentLabelY = margin + 10; // Start below title
                  
                  const labelW = 90; // Fixed width for 2 col
                  const labelH = 40;
                  const labelsGapY = 5;
                  const labelsGapX = 10;
                  
                  for (let i = 0; i < hierarchicalDepts.length; i++) {
                      // Page Break Logic
                      const posOnPage = i % labelsPerPage;
                      
                      if (posOnPage === 0 && i > 0) {
                          doc.addPage();
                          doc.text("ETIQUETAS DE ARCHIVO - CONTROL FÍSICO", w/2, margin, {align:'center'});
                          currentLabelX = margin;
                          currentLabelY = margin + 10;
                      }

                      // Position Calc
                      const col = posOnPage % 2; 
                      const row = Math.floor(posOnPage / 2); 

                      currentLabelX = margin + (col * (labelW + labelsGapX));
                      currentLabelY = margin + 10 + (row * (labelH + labelsGapY));

                      const d = hierarchicalDepts[i];
                      doc.setDrawColor(0); 
                      doc.setLineWidth(0.3);
                      doc.rect(currentLabelX, currentLabelY, labelW, labelH);
                      
                      // QR Generation with robustness
                      const qrText = `ID:${d.id}|${d.name ? d.name.substring(0,30) : 'N/A'}`; 
                      const qrData = await generateQRCodeBase64(qrText);
                      
                      // Draw QR
                      const qrSize = 28;
                      if (qrData) {
                          doc.addImage(qrData, 'PNG', currentLabelX+2, currentLabelY+6, qrSize, qrSize);
                      }
                      
                      // Text positioning (Right of QR)
                      const textX = currentLabelX + qrSize + 5;
                      const textW = labelW - qrSize - 8; // Available width for text

                      doc.setFontSize(10); doc.setFont("helvetica", "bold"); doc.setTextColor(0);
                      
                      // Dept Name - Strictly limited
                      let fSize = 9;
                      if(d.name.length > 40) fSize = 8;
                      if(d.name.length > 70) fSize = 7;
                      doc.setFontSize(fSize);
                      
                      const splitName = doc.splitTextToSize(d.name.toUpperCase(), textW);
                      doc.text(splitName, textX, currentLabelY+8);
                      
                      // Manager Name
                      const nameHeight = splitName.length * 4; 
                      doc.setFontSize(7); doc.setFont("helvetica", "normal");
                      const managerLines = doc.splitTextToSize(`Resp: ${d.managerName}`, textW);
                      doc.text(managerLines, textX, currentLabelY+10+nameHeight);
                      
                      // Footer info inside box
                      doc.setFontSize(6); doc.setTextColor(100);
                      doc.text(`ID: ${d.id} | POA ${currentYear}`, textX, currentLabelY + labelH - 3);
                  }

                  // PART B: SEPARATOR TABS (Pestañas/Separadores) - 3 columns
                  doc.addPage();
                  doc.setFontSize(16); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                  doc.text("ETIQUETAS SEPARADORAS (PESTAÑAS / LOMO)", w/2, margin, {align:'center'});
                  doc.setFontSize(10); doc.setTextColor(100);
                  doc.text("Recortar por la línea punteada", w/2, margin + 5, {align:'center'});

                  const tabW = 60;
                  const tabH = 15;
                  const tabGapX = 5;
                  const tabGapY = 5;
                  const tabsPerPage = 45; // 3 cols * 15 rows approx
                  
                  let tabStartY = margin + 15;

                  for (let i = 0; i < hierarchicalDepts.length; i++) {
                      const posOnPage = i % tabsPerPage;
                      
                      if (posOnPage === 0 && i > 0) {
                          doc.addPage();
                          doc.setFontSize(16); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                          doc.text("ETIQUETAS SEPARADORAS (PESTAÑAS / LOMO)", w/2, margin, {align:'center'});
                          tabStartY = margin + 15;
                      }

                      const col = posOnPage % 3;
                      const row = Math.floor(posOnPage / 3);

                      const x = margin + (col * (tabW + tabGapX));
                      const y = tabStartY + (row * (tabH + tabGapY));

                      const d = hierarchicalDepts[i];

                      // Draw Dashed Border for Cutting
                      doc.setDrawColor(150); 
                      doc.setLineWidth(0.1);
                      doc.setLineDashPattern([2, 2], 0);
                      doc.rect(x, y, tabW, tabH);
                      doc.setLineDashPattern([], 0); // Reset

                      // Content
                      doc.setTextColor(0);
                      
                      // ID Box
                      doc.setFillColor(0);
                      doc.rect(x, y, 10, tabH, 'F');
                      doc.setTextColor(255); doc.setFontSize(8); doc.setFont("helvetica", "bold");
                      doc.text(String(d.id), x + 5, y + (tabH/2) + 1, {align:'center'});

                      // Text
                      doc.setTextColor(0);
                      let tabFontSize = 8;
                      if(d.name.length > 30) tabFontSize = 7;
                      if(d.name.length > 50) tabFontSize = 6;
                      doc.setFontSize(tabFontSize);
                      
                      const tabText = doc.splitTextToSize(d.name.toUpperCase(), tabW - 14);
                      // Vertically center
                      const textBlockH = tabText.length * (tabFontSize * 0.35 + 1);
                      const textY = y + (tabH/2) - (textBlockH/2) + 2.5;
                      
                      doc.text(tabText, x + 12, textY);
                  }
                  break;

              case 'DEFICIT':
                  doc.text("REPORTE DE DÉFICIT (BRECHAS PLAN vs REAL)", w/2, startYContent, {align: 'center', maxWidth: contentW});
                  autoTable(doc, {
                      startY: startYContent+10, head: [['Gerencia', 'Meta', 'Planificado', 'Ejecutado', 'Déficit (Faltante)']],
                      body: goals.map(g => {
                          const d = hierarchicalDepts.find(dp=>dp.id===g.deptId);
                          const plan = safeSum(g.t1_plan, g.t2_plan, g.t3_plan, g.t4_plan);
                          const exec = safeSum(g.t1_exec, g.t2_exec, g.t3_exec, g.t4_exec);
                          const deficit = plan - exec;
                          return [d?.name || '?', g.description, plan, exec, deficit > 0 ? deficit : 0];
                      }),
                      headStyles: { halign: 'center' },
                      margin: { left: margin, right: margin }
                  });
                  if (goals.length === 0) doc.text("No hay datos.", margin, startYContent+20);
                  break;

              case 'FICHAS':
                  // UPDATE: Font Size 11, Arial (Helvetica), 1 Page Per Entity
                  if (hierarchicalDepts.length === 0) doc.text("No hay gerencias.", margin, startYContent);
                  
                  for (const d of hierarchicalDepts) {
                      doc.addPage(); // Force page break for every entity
                      
                      doc.setFont("helvetica", "bold"); 
                      doc.setFontSize(14); // Title Size
                      
                      const titleFicha = doc.splitTextToSize(d.name.toUpperCase(), contentW);
                      doc.text(titleFicha, w/2, margin + 20, {align:'center'});
                      
                      const titleFichaH = titleFicha.length * 7;
                      let fichaY = margin + 20 + titleFichaH + 5;

                      doc.setFillColor(240, 240, 240); 
                      doc.rect(margin, fichaY, contentW, 30, 'F');
                      doc.setTextColor(0);
                      doc.setFontSize(11); // Standard Size 11 as requested
                      
                      doc.text(`Gerente: ${d.managerName}`, margin + 5, fichaY + 10);
                      doc.text(`Email: ${d.email}`, margin + 5, fichaY + 18);
                      doc.text(`Teléfono: ${d.phone}`, margin + 5, fichaY + 26);

                      fichaY += 40;

                      // Helper for Fichas Blocks
                      const addFichaBlock = (label: string, text: string) => {
                          doc.setFont("helvetica", "bold");
                          // No smart break needed since we are on fresh page per entity mostly
                          // But kept just in case content is huge
                          fichaY = checkPageSpace(20, fichaY);
                          doc.text(label, margin, fichaY);
                          fichaY += 6;
                          
                          doc.setFont("helvetica", "normal");
                          const lines = doc.splitTextToSize(text || "No definido.", contentW);
                          
                          const blockH = lines.length * 5; 
                          fichaY = checkPageSpace(blockH, fichaY);
                          
                          doc.text(lines, margin, fichaY, {align: 'justify', maxWidth: contentW});
                          fichaY += blockH + 10;
                      };

                      addFichaBlock("MISIÓN:", d.mission);
                      addFichaBlock("VISIÓN:", d.vision);
                      addFichaBlock("PLAN DE LA PATRIA (Objetivo & Lineamiento):", 
                          `Obj: ${d.planPatriaObjective || d.planPatriaGoal || 'N/A'}\nLin: ${d.planPatriaLine || 'N/A'}`
                      );
                      addFichaBlock("PLAN DE DESARROLLO ECONÓMICO Y SOCIAL DEL MUNICIPIO:",
                          `Obj: ${d.municipalObjective || d.municipalStrategy || 'N/A'}\nLin: ${d.municipalLine || 'N/A'}`
                      );
                  }
                  break;

              case 'WHATSAPP_LOG':
                  doc.text("CONTROL DE RECORDATORIOS (WHATSAPP)", w/2, startYContent, {align: 'center', maxWidth: contentW});
                  const waLogs = logs.filter(l => l.action === 'WHATSAPP_REMINDER');
                  autoTable(doc, {
                      startY: startYContent+10, head: [['Fecha', 'Enviado Por', 'Detalle']],
                      body: waLogs.map(l => [new Date(l.timestamp).toLocaleString(), l.username, l.details]),
                      headStyles: { halign: 'center' },
                      margin: { left: margin, right: margin }
                  });
                  if(waLogs.length === 0) doc.text("No se encontraron registros de recordatorios enviados.", margin, startYContent+20);
                  break;

              case 'POA_HIERARCHY': // 18. Avance Jerárquico - FIXED
                  doc.setFontSize(14); doc.text("AVANCE POA - CONSOLIDADO JERÁRQUICO", w/2, startYContent, {align:'center', maxWidth: contentW});
                  
                  const rootDepts = allDepts.filter(d => (!d.type || d.type !== 'OFFICE') || !d.parentId);
                  let hY = startYContent + 10;

                  for(const root of rootDepts) {
                      const children = allDepts.filter(d => d.parentId === root.id);
                      
                      const rootStats = deptStats.find(s => s.id === root.id);
                      let aggPlan = rootStats?.plan || 0;
                      let aggExec = rootStats?.exec || 0;
                      
                      children.forEach(c => {
                          const cStats = deptStats.find(s => s.id === c.id);
                          aggPlan += cStats?.plan || 0;
                          aggExec += cStats?.exec || 0;
                      });
                      
                      const aggEff = aggPlan > 0 ? (aggExec / aggPlan) * 100 : 0;
                      
                      if(hY > h - 60) { doc.addPage(); hY = 20; }

                      doc.setFillColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                      doc.rect(margin, hY, contentW, 10, 'F');
                      doc.setTextColor(255); doc.setFont("helvetica", "bold"); doc.setFontSize(10);
                      doc.text(`${root.name.toUpperCase()} (CONSOLIDADO)`, margin + 5, hY+6);
                      doc.text(`Eficacia Global: ${Math.round(aggEff)}%`, w - margin - 5, hY+6, {align:'right'});
                      hY += 10;

                      const rows = [];
                      rows.push([
                          `GERENCIA: ${root.name}`, // Clean text, no unicode arrows
                          rootStats?.plan || 0, 
                          rootStats?.exec || 0, 
                          `${Math.round(rootStats?.eff || 0)}%`
                      ]);
                      
                      children.forEach(c => {
                          const cs = deptStats.find(s => s.id === c.id);
                          rows.push([
                              `   OFICINA: ${c.name}`, // Indent with spaces only
                              cs?.plan || 0, 
                              cs?.exec || 0, 
                              `${Math.round(cs?.eff || 0)}%`
                          ]);
                      });
                      
                      rows.push([
                          'TOTAL CONSOLIDADO',
                          aggPlan,
                          aggExec,
                          `${Math.round(aggEff)}%`
                      ]);

                      autoTable(doc, {
                          startY: hY,
                          head: [['Dependencia / Oficina', 'Plan', 'Ejecución', '%']],
                          body: rows,
                          theme: 'grid',
                          headStyles: { fillColor: [220, 220, 220], textColor: 0, fontStyle: 'bold', halign: 'center' },
                          columnStyles: { 
                              0: { cellWidth: 'auto', halign: 'left' },
                              1: { halign: 'center' },
                              2: { halign: 'center' },
                              3: { halign: 'center', fontStyle: 'bold' }
                          },
                          styles: { fontSize: 10 }, // Increased font size for visibility
                          margin: { left: margin, right: margin },
                          didParseCell: function (data) {
                              if (data.row.index === rows.length - 1) {
                                  data.cell.styles.fontStyle = 'bold';
                                  data.cell.styles.fillColor = [240, 240, 240];
                              }
                          }
                      });
                      
                      // @ts-ignore
                      hY = (doc as any).lastAutoTable?.finalY + 10;
                  }
                  break;

              case 'ORGANIGRAMA':
                  // Landscape mode assumed
                  doc.setFontSize(16); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                  doc.text("ORGANIGRAMA ESTRUCTURAL", w/2, margin, {align:'center'});
                  
                  let orgY = margin + 20;
                  
                  // Sort parents by order
                  const orgRoots = allDepts.filter(d => (!d.type || d.type !== 'OFFICE') || !d.parentId).sort((a,b) => (a.order||0) - (b.order||0));

                  // FORCE 1 PER PAGE LOGIC
                  for (let i = 0; i < orgRoots.length; i++) {
                      const root = orgRoots[i];
                      if (i > 0) {
                          doc.addPage();
                          doc.text("ORGANIGRAMA ESTRUCTURAL", w/2, margin, {align:'center'});
                          orgY = margin + 20;
                      }

                      const children = allDepts.filter(d => d.parentId === root.id).sort((a,b) => (a.order||0) - (b.order||0));
                      
                      // Dimensions
                      const pBoxW = 90; 
                      
                      // DYNAMIC HEIGHT CALCULATION TO PREVENT OVERLAP
                      const titleLines = doc.splitTextToSize(root.name.toUpperCase(), pBoxW - 4);
                      const titleHeight = Math.max(titleLines.length * 5, 10); // Minimum 10mm for title area
                      const pBoxH = titleHeight + 12; // Extra padding for manager name
                      
                      // Dynamic Child Grid
                      const childCount = children.length;
                      
                      // Dynamic sizing based on density
                      let cBoxW = 55; 
                      let cBoxH = 16; 
                      let gridCols = 4;
                      let gapX = 6;
                      
                      // If many children, shrink boxes slightly or increase columns if space permits
                      if (childCount > 8) {
                          gridCols = 5;
                          cBoxW = 45; // Smaller box
                          gapX = 4;
                      }

                      const gapY = 25; // Increased vertical gap to prevent overlap with trunk line/text
                      
                      // Calculate Children Block Height
                      const rows = Math.ceil(childCount / gridCols);
                      const childrenBlockH = rows > 0 ? (rows * cBoxH) + ((rows - 1) * gapY) : 0;
                      
                      // Draw Parent (Centered)
                      const pX = (w - pBoxW) / 2;
                      doc.setDrawColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                      doc.setLineWidth(0.5);
                      doc.setFillColor(240, 245, 255);
                      doc.roundedRect(pX, orgY, pBoxW, pBoxH, 2, 2, 'FD');
                      
                      // Parent Text
                      doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                      doc.setFontSize(10); doc.setFont("helvetica", "bold");
                      doc.text(titleLines, w/2, orgY + 6, {align:'center'});
                      
                      // Manager Text (positioned below title)
                      doc.setTextColor(0); doc.setFontSize(8); doc.setFont("helvetica", "normal");
                      doc.text(root.managerName || "Responsable", w/2, orgY + 6 + titleHeight + 2, {align:'center', maxWidth: pBoxW - 4});

                      const pBottomY = orgY + pBoxH;
                      const pCenterX = w / 2;

                      if (children.length > 0) {
                          const startChildrenY = pBottomY + gapY;
                          
                          // Draw Trunk from Parent Down
                          doc.setDrawColor(100); doc.setLineWidth(0.3);
                          
                          for (let r = 0; r < rows; r++) {
                              const rowChildren = children.slice(r * gridCols, (r + 1) * gridCols);
                              const rowY = startChildrenY + (r * (cBoxH + gapY));
                              const connectorY = rowY - (gapY / 2);

                              // Calculate Row Width to center it
                              const rowW = (rowChildren.length * cBoxW) + ((rowChildren.length - 1) * gapX);
                              const startX = (w - rowW) / 2;

                              // Draw Connector Horizontal Line for this row
                              const firstChildCX = startX + (cBoxW / 2);
                              const lastChildCX = startX + ((rowChildren.length - 1) * (cBoxW + gapX)) + (cBoxW / 2);
                              
                              // Draw Main Trunk down to this connector
                              if (r === 0) {
                                  doc.line(pCenterX, pBottomY, pCenterX, connectorY);
                              } else {
                                  // Connect from previous row bottom (visual trick: continue from previous gap)
                                  doc.line(pCenterX, startChildrenY + ((r-1) * (cBoxH + gapY)) + cBoxH, pCenterX, connectorY); 
                              }

                              // Draw Horizontal Bar for this row
                              if (rowChildren.length > 1) {
                                  doc.line(firstChildCX, connectorY, lastChildCX, connectorY);
                              }

                              // Draw Vertical lines to children
                              rowChildren.forEach((child, i) => {
                                  const childX = startX + (i * (cBoxW + gapX));
                                  const childCX = childX + (cBoxW / 2);
                                  
                                  // Line from connectorY to box top
                                  doc.line(childCX, connectorY, childCX, rowY);

                                  // Draw Child Box
                                  doc.setFillColor(255);
                                  doc.setDrawColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                                  doc.roundedRect(childX, rowY, cBoxW, cBoxH, 1, 1, 'FD');
                                  
                                  // Child Text (Dynamic Sizing)
                                  doc.setFillColor(0); doc.setTextColor(0);
                                  let fSize = 8;
                                  if (child.name.length > 30) fSize = 7;
                                  if (child.name.length > 50) fSize = 6;
                                  
                                  doc.setFontSize(fSize); doc.setFont("helvetica", "bold");
                                  
                                  const lines = doc.splitTextToSize(child.name, cBoxW - 2);
                                  // Vertically center text in box
                                  const textBlockH = lines.length * (fSize * 0.35 + 1); 
                                  const textY = rowY + (cBoxH/2) - (textBlockH/2) + 2; 
                                  
                                  doc.text(lines, childCX, textY, {align:'center'});
                              });
                          }
                      }
                  }
                  break;
              
              case 'INVENTARIO': // 20. New Report - INVENTARIO DE SEMANAS CARGADAS
                  doc.setFontSize(16); doc.setTextColor(COLORS.NAVY[0], COLORS.NAVY[1], COLORS.NAVY[2]);
                  doc.text("INVENTARIO DE SEMANAS CARGADAS POR DEPENDENCIA", w/2, startYContent, {align:'center', maxWidth: contentW});
                  
                  let invY = startYContent + 20;
                  
                  for(const d of hierarchicalDepts) {
                      const dReports = reports.filter(r => r.deptId === d.id).sort((a,b) => {
                          return new Date(a.startDate).getTime() - new Date(b.startDate).getTime();
                      });

                      // --- SMART PAGE BREAK LOGIC ---
                      // We need to calculate how much height the header + at least 2 rows of table will take.
                      // 1. Calculate Header Height based on Text Wrap
                      // Removed symbol logic
                      const indent = (d.type === 'OFFICE' && d.parentId) ? '   ' : '';
                      const rawName = (indent + d.name).toUpperCase();
                      const availableTextWidth = contentW - 45; // Leave space for "X Semanas" count
                      const nameLines = doc.splitTextToSize(rawName, availableTextWidth);
                      const headerHeight = (nameLines.length * 5) + 6; // Approx 5mm per line + padding
                      
                      // 2. Estimate Table Height (Header + 1 Row) ~ 15mm
                      const minBlockHeight = headerHeight + 15;

                      // 3. Check Page Space
                      if (invY + minBlockHeight > h - margin) { 
                          doc.addPage(); 
                          invY = margin; 
                      }
                      
                      // Department Header Background
                      doc.setFillColor(COLORS.LIGHT_GRAY[0], COLORS.LIGHT_GRAY[1], COLORS.LIGHT_GRAY[2]);
                      doc.rect(margin, invY, contentW, headerHeight, 'F');
                      
                      // Department Name Text
                      doc.setTextColor(0); doc.setFontSize(10); doc.setFont("helvetica", "bold");
                      doc.text(nameLines, margin + 2, invY + 5);
                      
                      // Count badge (Right aligned, vertically centered relative to box)
                      doc.setFont("helvetica", "normal");
                      const centerY = invY + (headerHeight / 2) + 1.5;
                      doc.text(`${dReports.length} Semana(s)`, w - margin - 2, centerY, {align: 'right'});
                      
                      invY += headerHeight + 2;
                      
                      if(dReports.length > 0) {
                          const tableBody = dReports.map((r, idx) => [
                              idx + 1,
                              new Date(r.startDate).toLocaleDateString(),
                              new Date(r.endDate).toLocaleDateString(),
                              'CARGADO'
                          ]);
                          
                          autoTable(doc, {
                              startY: invY,
                              head: [['#', 'Fecha Inicio', 'Fecha Fin', 'Estatus']],
                              body: tableBody,
                              theme: 'grid',
                              styles: { fontSize: 8, cellPadding: 1 },
                              columnStyles: { 
                                  0: { cellWidth: 10, halign: 'center' },
                                  3: { fontStyle: 'bold', textColor: [0, 100, 0] }
                              },
                              margin: { left: margin + 5, right: margin + 5 } // Indented table
                          });
                          
                          // @ts-ignore
                          invY = (doc as any).lastAutoTable?.finalY + 5;
                      } else {
                          doc.setFontSize(8); doc.setFont("helvetica", "italic"); doc.setTextColor(150);
                          doc.text("Sin semanas cargadas.", margin + 10, invY);
                          invY += 5;
                      }
                      
                      invY += 5; // Spacing between departments
                  }
                  break;
          }

          // --- GLOBAL HEADER & FOOTER (Applied to all pages) ---
          const pageCount = doc.getNumberOfPages();
          for(let i = 2; i <= pageCount; i++) { // Start from page 2 to skip Cover
              doc.setPage(i);
              
              // HEADER
              if (logo) {
                  try {
                      doc.addImage(logo, 'PNG', 10, 5, 12, 12);
                  } catch(e) {} // Fallback if logo fails
              }
              doc.setFont("helvetica", "bold");
              doc.setFontSize(8);
              doc.setTextColor(0);
              doc.text("REPÚBLICA BOLIVARIANA DE VENEZUELA", w/2, 8, {align: 'center'});
              doc.text("ESTADO BOLIVARIANO DE MÉRIDA", w/2, 12, {align: 'center'});
              doc.text("ALCALDÍA DEL MUNICIPIO ALBERTO ADRIANI", w/2, 16, {align: 'center'});
              
              // FOOTER
              doc.setFontSize(7);
              doc.setFont("helvetica", "normal");
              doc.setTextColor(100);
              doc.setLineWidth(0.1);
              doc.setDrawColor(200);
              doc.line(15, h-12, w-15, h-12);
              
              doc.text("Alcaldía del Municipio Alberto Adriani - Estado Bolivariano de Mérida", w/2, h-8, {align: 'center'});
              doc.text(`Página ${i} de ${pageCount} - Generado por SISCEPOAAA`, w/2, h-5, {align: 'center'});
          }

          doc.save(`${activeReport.id}_${new Date().getTime()}.pdf`);
          showToast("Reporte generado exitosamente", "success");
          
          await logAudit(currentUser?.username || 'Sistema', 'GEN_DOC_HASH', `Documento: ${activeReport.title} | Hash: ${docHash}`);

      } catch (err) {
          console.error(err);
          showToast("Error al generar el reporte PDF", "error");
      } finally {
          setIsGenerating(false);
      }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in zoom-in-95">
       <div className="flex items-center gap-4 mb-6">
            <div className="bg-white p-2 rounded-lg shadow-sm border border-slate-200">
                <img src={ALCALDIA_LOGO_URL} alt="Logo" className="h-12 w-auto" />
            </div>
            <div>
                <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight">Centro de Reportes Oficiales</h2>
                <p className="text-slate-500 font-medium">Generación de documentación estratégica y legal</p>
            </div>
       </div>

       {activeReport ? (
           <div className="glass-panel rounded-xl overflow-hidden shadow-lg animate-in slide-in-from-right">
               <div className="bg-slate-900 text-white p-6 flex justify-between items-center">
                   <div className="flex items-center gap-4">
                       <button onClick={() => setActiveReport(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24}/></button>
                       <div>
                           <h3 className="text-xl font-bold flex items-center gap-2">
                               <activeReport.icon size={24} className="text-blue-400" />
                               {activeReport.title}
                           </h3>
                           <p className="text-slate-400 text-sm">{activeReport.desc}</p>
                       </div>
                   </div>
               </div>
               <div className="p-8 max-w-3xl mx-auto">
                   <div className="bg-blue-50 border border-blue-100 rounded-xl p-6 mb-8">
                       <h4 className="font-bold text-blue-800 mb-2 flex items-center gap-2"><BookOpen size={18}/> Definición del Reporte</h4>
                       <p className="text-slate-700 text-sm leading-relaxed text-justify">
                           {REPORT_DEFINITIONS[activeReport.id] || "Sin definición disponible."}
                       </p>
                   </div>
                   
                   {/* Date Filters */}
                   <div className="mb-6 grid grid-cols-2 gap-4">
                       <div>
                           <label className="block text-sm font-bold text-slate-700 mb-2">Fecha Inicio (Opcional)</label>
                           <input 
                               type="date" 
                               value={startDate} 
                               onChange={(e) => setStartDate(e.target.value)}
                               className="w-full border p-3 rounded-lg text-sm"
                           />
                       </div>
                       <div>
                           <label className="block text-sm font-bold text-slate-700 mb-2">Fecha Fin (Opcional)</label>
                           <input 
                               type="date" 
                               value={endDate} 
                               onChange={(e) => setEndDate(e.target.value)}
                               className="w-full border p-3 rounded-lg text-sm"
                           />
                       </div>
                   </div>

                   {/* Custom Inputs per report type */}
                   {activeReport.id === 'OFICIO' && (
                       <div className="mb-6">
                           <label className="block text-sm font-bold text-slate-700 mb-2">Número de Oficio</label>
                           <input 
                              type="text" 
                              value={oficioNum} 
                              onChange={(e) => setOficioNum(e.target.value)}
                              className="w-full border p-3 rounded-lg font-mono text-sm"
                           />
                       </div>
                   )}

                   <div className="mb-8">
                       <label className="block text-sm font-bold text-slate-700 mb-2">Introducción Personalizada (Opcional)</label>
                       <textarea 
                          value={customText} 
                          onChange={(e) => setCustomText(e.target.value)}
                          className="w-full border p-3 rounded-lg text-sm h-24"
                          placeholder="Si desea anular la introducción estándar, escriba aquí..."
                       />
                   </div>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       <button 
                          onClick={generatePDF} 
                          disabled={isGenerating}
                          className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 rounded-xl shadow-xl flex items-center justify-center gap-3 transition-transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                       >
                           {isGenerating ? (
                               <>Generando...</>
                           ) : (
                               <><Printer size={24} /> PDF Individual</>
                           )}
                       </button>
                       {/* Export #6 - ZIP Button */}
                       <button 
                          onClick={handleExportAllZip}
                          disabled={isGenerating}
                          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-xl flex items-center justify-center gap-3 transition-transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                       >
                           {isGenerating ? (
                               <>Generando...</>
                           ) : (
                               <><FolderArchive size={24} /> Descargar ZIP Masivo</>
                           )}
                       </button>
                   </div>
               </div>
           </div>
       ) : (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
               {REPORT_TYPES.map(report => (
                   <div 
                      key={report.id} 
                      onClick={() => { setActiveReport(report); setCustomText(''); setStartDate(''); setEndDate(''); }}
                      className="bg-white hover:bg-blue-50/50 p-6 rounded-xl shadow-sm hover:shadow-md border border-slate-200 cursor-pointer transition-all group relative overflow-hidden"
                   >
                       <div className={`absolute top-0 right-0 w-24 h-24 bg-${report.color}-500/10 rounded-bl-full -mr-10 -mt-10 transition-transform group-hover:scale-150`}></div>
                       <div className={`w-12 h-12 rounded-lg bg-${report.color}-100 text-${report.color}-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                           <report.icon size={24} />
                       </div>
                       <h4 className="font-bold text-slate-800 mb-2 group-hover:text-blue-700 transition-colors">{report.title}</h4>
                       <p className="text-xs text-slate-500 leading-snug">{report.desc}</p>
                   </div>
               ))}
           </div>
       )}
    </div>
  );
};

export default ReportsCenter;
