

import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../services/db';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, AreaChart, Area
} from 'recharts';
import { 
  TrendingUp, AlertTriangle, Users, Target, Activity, Clock, ShieldCheck, 
  BarChart2, Award, Zap, ChevronRight, LayoutList, Monitor, Download, ArrowLeftRight, X
} from 'lucide-react';
import { ToastContext } from '../App';

// --- ENHANCED SKELETON (UX #9) ---
const DashboardSkeleton = () => (
    <div className="space-y-6 animate-pulse p-4">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
            <div className="h-10 w-1/3 bg-slate-200 rounded-lg"></div>
            <div className="flex gap-2">
                <div className="h-10 w-10 bg-slate-200 rounded-lg"></div>
                <div className="h-10 w-10 bg-slate-200 rounded-lg"></div>
            </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
                <div key={i} className="h-36 bg-slate-100 rounded-xl border border-slate-200 p-5 flex flex-col justify-between">
                    <div className="flex justify-between">
                        <div className="h-4 w-20 bg-slate-200 rounded"></div>
                        <div className="h-8 w-8 bg-slate-200 rounded-lg"></div>
                    </div>
                    <div className="h-8 w-32 bg-slate-300 rounded mt-2"></div>
                    <div className="h-4 w-24 bg-slate-200 rounded mt-2"></div>
                </div>
            ))}
        </div>

        {/* Matrix List */}
        <div className="h-96 bg-slate-100 rounded-xl border border-slate-200 p-6">
             <div className="h-6 w-48 bg-slate-200 rounded mb-6"></div>
             <div className="space-y-4">
                 {[1,2,3,4,5].map(i => <div key={i} className="h-12 w-full bg-slate-200 rounded-lg"></div>)}
             </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 h-80 bg-slate-100 rounded-xl border border-slate-200 p-6">
                <div className="h-6 w-40 bg-slate-200 rounded mb-4"></div>
                <div className="h-full w-full bg-slate-200 rounded opacity-50"></div>
            </div>
            <div className="h-80 bg-slate-100 rounded-xl border border-slate-200 flex flex-col gap-4 p-6">
                <div className="h-20 bg-slate-200 rounded-lg"></div>
                <div className="h-20 bg-slate-200 rounded-lg"></div>
                <div className="h-20 bg-slate-200 rounded-lg"></div>
            </div>
        </div>
    </div>
);

const KPICard = ({ title, value, subtitle, icon: Icon, color, isAlert }: any) => (
  <div className={`glass-panel p-5 rounded-xl flex flex-col justify-between hover:shadow-lg hover:-translate-y-1 transition-all duration-300 relative overflow-hidden group border-0 ring-1 ring-white/40 ${isAlert ? 'bg-red-50/80' : 'bg-white/60'}`}>
    <div className="flex justify-between items-start z-10">
      <div>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{title}</p>
        <h3 className={`text-3xl font-black mt-1 tracking-tight ${isAlert ? 'text-red-700' : 'text-slate-800'}`}>{value}</h3>
      </div>
      <div className={`p-3 rounded-xl ${color} text-white shadow-lg shadow-blue-500/20`}>
        <Icon size={20} />
      </div>
    </div>
    <p className="text-xs text-slate-500 mt-4 font-medium z-10 flex items-center gap-1">
        {isAlert && <AlertTriangle size={10} />} {subtitle}
    </p>
    <Icon size={100} className="absolute -bottom-6 -right-6 opacity-[0.05] text-slate-900 rotate-12 group-hover:scale-110 transition-transform duration-500" />
  </div>
);

const HallView: React.FC = () => {
  const navigate = useNavigate();
  const departments = useLiveQuery(() => db.departments.toArray());
  const goals = useLiveQuery(() => db.goals.toArray());
  const { showToast } = React.useContext(ToastContext)!;

  // States for Features
  const [isPresentationMode, setIsPresentationMode] = useState(false);
  const [showCompareModal, setShowCompareModal] = useState(false);
  const [compareDepts, setCompareDepts] = useState<number[]>([0,0]);

  const dashboardRef = useRef<HTMLDivElement>(null);

  if (!departments || !goals) return <DashboardSkeleton />;

  // --- BUSINESS INTELLIGENCE LOGIC ---
  let globalPlan = 0; let globalExec = 0; let totalGoalsCount = 0; let extraCount = 0; let heroesCount = 0; let inactiveCount = 0; let digitizedCount = 0;

  const deptStats = departments.map(d => {
    const deptGoals = goals.filter(g => g.deptId === d.id);
    let dPlan = 0; let dExec = 0; let dExtra = 0; let t1e = 0, t2e = 0, t3e = 0, t4e = 0;
    deptGoals.forEach(g => {
      if (g.isExtra) dExtra++;
      dPlan += (g.t1_plan + g.t2_plan + g.t3_plan + g.t4_plan);
      dExec += (g.t1_exec + g.t2_exec + g.t3_exec + g.t4_exec);
      t1e += g.t1_exec; t2e += g.t2_exec; t3e += g.t3_exec; t4e += g.t4_exec;
      if(g.t1_exec > 0 || g.t2_exec > 0 || g.t3_exec > 0 || g.t4_exec > 0) digitizedCount++;
    });
    globalPlan += dPlan; globalExec += dExec; extraCount += dExtra; totalGoalsCount += deptGoals.length;
    const eff = dPlan > 0 ? (dExec / dPlan) : (dExtra > 0 ? 1 : 0);
    if (eff >= 0.95) heroesCount++;
    if (eff === 0 && dPlan > 0) inactiveCount++;
    const classification = eff >= 0.9 ? "Sobresaliente" : eff < 0.5 ? "Deficiente" : "Regular";
    return { id: d.id, name: d.name, manager: d.managerName, plan: dPlan, exec: dExec, eff, extra: dExtra, classification };
  });

  const globalEfficacy = globalPlan > 0 ? Math.round((globalExec / globalPlan) * 100) : 0;
  const now = new Date();
  const startOfYear = new Date(now.getFullYear(), 0, 1);
  const endOfYear = new Date(now.getFullYear(), 11, 31);
  const totalDays = (endOfYear.getTime() - startOfYear.getTime()) / (1000 * 3600 * 24);
  const daysPassed = (now.getTime() - startOfYear.getTime()) / (1000 * 3600 * 24);
  const fiscalTimePerc = Math.round((daysPassed / totalDays) * 100);
  const isTimeAlert = fiscalTimePerc > globalEfficacy + 10;
  const planningEff = totalGoalsCount > 0 ? Math.round(((totalGoalsCount - extraCount) / totalGoalsCount) * 100) : 0;
  const digiRate = totalGoalsCount > 0 ? Math.round((digitizedCount / totalGoalsCount) * 100) : 0;
  const ranking = [...deptStats].sort((a, b) => b.eff - a.eff);

  const sCurveData = [
      { name: 'T1', plan: 25, real: (globalExec/globalPlan)*25 },
      { name: 'T2', plan: 50, real: (globalExec/globalPlan)*50 },
      { name: 'T3', plan: 75, real: (globalExec/globalPlan)*75 },
      { name: 'T4', plan: 100, real: (globalExec/globalPlan)*100 },
  ];

  // --- FEATURES LOGIC ---
  const handleExportChart = async () => {
    if (!dashboardRef.current) return;
    // @ts-ignore
    const html2canvas = window.html2canvas;
    if (!html2canvas) return alert("Librería de exportación no cargada.");
    try {
        const canvas = await html2canvas(dashboardRef.current, { scale: 2 });
        const link = document.createElement('a');
        link.download = `Dashboard_${new Date().toISOString()}.png`;
        link.href = canvas.toDataURL();
        link.click();
        showToast("Gráficos exportados correctamente", "success");
    } catch(e) {
        showToast("Error al exportar imagen", "error");
    }
  };

  const ComparisonModal = () => {
     if(!showCompareModal) return null;
     const d1 = deptStats.find(d => d.id == compareDepts[0]);
     const d2 = deptStats.find(d => d.id == compareDepts[1]);

     return (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl w-full max-w-4xl p-6 shadow-2xl animate-in zoom-in-95">
                <div className="flex justify-between items-center mb-6">
                   <h3 className="text-xl font-bold flex items-center gap-2"><ArrowLeftRight/> Comparativa Gerencial (Benchmarking)</h3>
                   <button onClick={() => setShowCompareModal(false)}><X/></button>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-6">
                    <select className="border p-2 rounded" onChange={e => setCompareDepts([Number(e.target.value), compareDepts[1]])}>
                        <option value="0">Seleccione Gerencia A...</option>
                        {deptStats.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                    </select>
                    <select className="border p-2 rounded" onChange={e => setCompareDepts([compareDepts[0], Number(e.target.value)])}>
                        <option value="0">Seleccione Gerencia B...</option>
                        {deptStats.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                    </select>
                </div>
                {d1 && d2 ? (
                    <div className="grid grid-cols-2 gap-8 text-center">
                        <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                             <h4 className="font-bold text-lg text-blue-800">{d1.name}</h4>
                             <div className="text-4xl font-black mt-4 text-slate-800">{Math.round(d1.eff*100)}%</div>
                             <p className="text-xs uppercase text-slate-500 font-bold">Eficacia</p>
                             <div className="mt-4 space-y-2 text-sm text-left px-4">
                                <div className="flex justify-between"><span>Metas:</span> <b>{goals.filter(g=>g.deptId==d1.id).length}</b></div>
                                <div className="flex justify-between"><span>Ejecutado:</span> <b>{d1.exec}</b></div>
                                <div className="flex justify-between"><span>Extras:</span> <b>{d1.extra}</b></div>
                             </div>
                        </div>
                        <div className="p-4 bg-purple-50 rounded-xl border border-purple-200">
                             <h4 className="font-bold text-lg text-purple-800">{d2.name}</h4>
                             <div className="text-4xl font-black mt-4 text-slate-800">{Math.round(d2.eff*100)}%</div>
                             <p className="text-xs uppercase text-slate-500 font-bold">Eficacia</p>
                             <div className="mt-4 space-y-2 text-sm text-left px-4">
                                <div className="flex justify-between"><span>Metas:</span> <b>{goals.filter(g=>g.deptId==d2.id).length}</b></div>
                                <div className="flex justify-between"><span>Ejecutado:</span> <b>{d2.exec}</b></div>
                                <div className="flex justify-between"><span>Extras:</span> <b>{d2.extra}</b></div>
                             </div>
                        </div>
                    </div>
                ) : <p className="text-center text-gray-400 py-10">Seleccione dos gerencias para comparar métricas.</p>}
            </div>
        </div>
     );
  };

  return (
    <div ref={dashboardRef} className={`space-y-8 pb-12 animate-in fade-in zoom-in-95 duration-500 ${isPresentationMode ? 'fixed inset-0 bg-white z-[100] p-8 overflow-y-auto' : ''}`}>
      <ComparisonModal />
      
      {/* HEADER & CONTROLS */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight drop-shadow-sm">Tablero de Mando Integral</h2>
           <p className="text-sm text-slate-600 font-medium">Monitoreo Estratégico en Tiempo Real</p>
        </div>
        <div className="flex items-center gap-2">
            {!isPresentationMode && (
                <>
                <button onClick={() => setShowCompareModal(true)} className="p-2 bg-white border border-gray-200 rounded-lg text-slate-600 hover:text-blue-600 shadow-sm" title="Comparar Gerencias (Benchmarking)">
                   <ArrowLeftRight size={18} />
                </button>
                <button onClick={handleExportChart} className="p-2 bg-white border border-gray-200 rounded-lg text-slate-600 hover:text-green-600 shadow-sm" title="Exportar Gráficos">
                   <Download size={18} />
                </button>
                </>
            )}
            <button onClick={() => setIsPresentationMode(!isPresentationMode)} className={`p-2 border rounded-lg shadow-sm ${isPresentationMode ? 'bg-blue-600 text-white border-blue-600' : 'bg-white border-gray-200 text-slate-600 hover:text-purple-600'}`} title="Modo Presentación (TV)">
                <Monitor size={18} />
            </button>
        </div>
      </div>

      {/* MACRO INDICADORES */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard 
          title="1. Eficacia Global" value={`${globalEfficacy}%`} subtitle={globalEfficacy > 90 ? "Excelencia" : "Regular"}
          icon={Activity} color={globalEfficacy >= 90 ? "bg-green-600" : "bg-blue-600"} 
        />
        <KPICard 
          title="2. Volumen Físico" value={globalExec.toLocaleString()} subtitle="Unidades Ejecutadas"
          icon={BarChart2} color="bg-indigo-600" 
        />
        <KPICard 
          title="3. Reloj Fiscal" value={`${fiscalTimePerc}%`} subtitle={isTimeAlert ? "⚠️ RETRASO" : "En Tiempo"}
          icon={Clock} color={isTimeAlert ? "bg-red-600" : "bg-gray-600"} isAlert={isTimeAlert}
        />
        <KPICard 
          title="4. Efectividad Plan." value={`${planningEff}%`} subtitle={`Improvisadas: ${extraCount}`}
          icon={Target} color="bg-teal-600" 
        />
      </div>

      {/* LISTADO INTERACTIVO */}
      <div className="glass-panel rounded-xl overflow-hidden ring-1 ring-slate-900/5 shadow-xl">
         <div className="p-6 border-b border-white/50 bg-white/40 flex justify-between items-center backdrop-blur-sm">
            <h3 className="font-bold text-slate-800 flex items-center gap-2 text-lg"><LayoutList size={22} className="text-blue-600" /> Matriz de Gestión</h3>
         </div>
         <div className="overflow-x-auto">
            <table className="w-full text-sm text-left border-collapse">
               <thead className="bg-slate-50/80 text-slate-500 text-xs uppercase sticky top-0 backdrop-blur-md z-10">
                  <tr>
                     <th className="px-6 py-4">Gerencia</th>
                     <th className="px-6 py-4 hidden sm:table-cell">Responsable</th>
                     <th className="px-6 py-4 text-center">Eficacia</th>
                     <th className="px-6 py-4 hidden md:table-cell">Progreso</th>
                     <th className="px-6 py-4 hidden lg:table-cell">Calificación</th>
                     <th className="px-4 py-4"></th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-gray-100 bg-white/60">
                  {ranking.map((dept, idx) => (
                     <tr key={dept.id} onClick={() => navigate(`/matrix/${dept.id}`)} className="group hover:bg-blue-50/80 cursor-pointer transition-all border-b border-gray-100/50">
                        <td className="px-6 py-4 flex items-center gap-3">
                               <span className="w-6 h-6 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center text-[10px] font-bold">{idx + 1}</span>
                               <span className="font-bold text-slate-700 group-hover:text-blue-700">{dept.name}</span>
                        </td>
                        <td className="px-6 py-4 text-slate-600 hidden sm:table-cell">{dept.manager}</td>
                        <td className="px-6 py-4 text-center"><span className={`px-3 py-1 rounded-full font-bold text-xs ${dept.eff >= 0.9 ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{Math.round(dept.eff * 100)}%</span></td>
                        <td className="px-6 py-4 hidden md:table-cell w-48">
                            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden"><div className={`h-2 rounded-full ${dept.eff >= 0.9 ? 'bg-green-500' : 'bg-yellow-500'}`} style={{ width: `${Math.min(dept.eff * 100, 100)}%` }}></div></div>
                        </td>
                        <td className="px-6 py-4 text-xs font-semibold text-slate-500 hidden lg:table-cell">{dept.classification}</td>
                        <td className="px-4 py-4 text-right text-slate-300 group-hover:text-blue-500"><ChevronRight size={20} /></td>
                     </tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>

      {/* GRÁFICOS INFERIORES */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-4">
          <div className="lg:col-span-2 glass-panel rounded-xl p-6 flex flex-col min-h-[300px]">
              <h3 className="font-bold text-slate-700 mb-6 text-sm uppercase flex items-center gap-2"><TrendingUp size={16} /> Curva "S" de Ejecución</h3>
              <div className="flex-1"><ResponsiveContainer width="100%" height="100%"><AreaChart data={sCurveData}><XAxis dataKey="name"/><YAxis/><Area type="monotone" dataKey="real" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3}/></AreaChart></ResponsiveContainer></div>
          </div>
          <div className="grid grid-cols-1 gap-4">
             <KPICard title="Héroes (100%)" value={heroesCount} subtitle="Alto Nivel" icon={Award} color="bg-yellow-500" />
             <KPICard title="Inactivos (0%)" value={inactiveCount} subtitle="Críticos" icon={AlertTriangle} color="bg-red-500" />
             <KPICard title="Digitalización" value={`${digiRate}%`} subtitle="Evidencias" icon={Zap} color="bg-cyan-500" />
          </div>
      </div>
    </div>
  );
};

export default HallView;
