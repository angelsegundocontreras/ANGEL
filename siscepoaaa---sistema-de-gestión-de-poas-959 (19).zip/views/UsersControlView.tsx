import React, { useState, useRef } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, logAudit, exportDatabase, importDatabase } from '../services/db';
import { User, UserRole, ALCALDIA_LOGO_URL } from '../types';
import { UserCog, Trash2, Shield, Search, History, AlertTriangle, Key, X, Database, Download, Upload, Save, FileCheck } from 'lucide-react';
import { ToastContext } from '../App';

const UsersControlView = ({ currentUser }: { currentUser: User }) => {
  const users = useLiveQuery(() => db.users.toArray());
  const logs = useLiveQuery(() => db.auditLogs.reverse().limit(100).toArray()); // Last 100 logs
  
  // Robust query: If 'action' index exists it uses it, otherwise it falls back to filter to prevent crash
  const docLogs = useLiveQuery(async () => {
      try {
          return await db.auditLogs.where('action').equals('GEN_DOC_HASH').reverse().toArray();
      } catch (e) {
          // Fallback if index missing
          const all = await db.auditLogs.toArray();
          return all.filter(l => l.action === 'GEN_DOC_HASH').reverse();
      }
  });
  
  const [activeTab, setActiveTab] = useState<'users' | 'logs' | 'db' | 'hashes'>('users');
  const { showToast } = React.useContext(ToastContext)!;
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Password Modal State
  const [passwordModal, setPasswordModal] = useState<{show: boolean, userId: number | null, username: string}>({
      show: false, userId: null, username: ''
  });
  const [newPassword, setNewPassword] = useState('');

  const handleDelete = async (id: number) => {
    if (window.confirm('¿Seguro que desea eliminar este usuario?')) {
      await db.users.delete(id);
      await logAudit(currentUser.username, 'DELETE_USER', `Usuario ID ${id} eliminado`);
    }
  };

  const toggleRole = async (u: User) => {
      if(u.id === currentUser.id) return; 
      const newRole = u.role === UserRole.ADMIN ? UserRole.TRANSCRIBER : UserRole.ADMIN;
      await db.users.update(u.id!, { role: newRole });
      await logAudit(currentUser.username, 'CHANGE_ROLE', `Rol de ${u.username} cambiado a ${newRole}`);
      showToast(`Rol de ${u.username} actualizado a ${newRole}`, "success");
  };

  const openPasswordModal = (u: User) => {
      setPasswordModal({ show: true, userId: u.id!, username: u.username });
      setNewPassword('');
  };

  const handlePasswordUpdate = async () => {
      if (!newPassword || newPassword.length < 6) {
          showToast("La contraseña debe tener al menos 6 caracteres.", "error");
          return;
      }
      if (passwordModal.userId) {
          await db.users.update(passwordModal.userId, { passwordHash: newPassword });
          await logAudit(currentUser.username, 'CHANGE_PASSWORD', `Contraseña cambiada para ${passwordModal.username}`);
          showToast(`Contraseña actualizada para ${passwordModal.username}`, "success");
          setPasswordModal({ show: false, userId: null, username: '' });
      }
  };

  const handleExportDB = async () => {
      try {
          const json = await exportDatabase();
          const blob = new Blob([json], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `SISCEPOAAA_BACKUP_${new Date().toISOString().split('T')[0]}.json`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          await logAudit(currentUser.username, 'DB_EXPORT', 'Copia de seguridad generada');
          showToast("Copia de seguridad descargada exitosamente", "success");
      } catch (e) {
          showToast("Error al generar respaldo", "error");
      }
  };

  const handleImportClick = () => {
      if (window.confirm("⚠️ ADVERTENCIA: Al importar una base de datos se BORRARÁN todos los datos actuales y se reemplazarán por los del archivo.\n\n¿Desea continuar?")) {
          fileInputRef.current?.click();
      }
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = async (e) => {
          try {
              const content = e.target?.result as string;
              await importDatabase(content);
              await logAudit(currentUser.username, 'DB_IMPORT', 'Base de datos restaurada desde archivo');
              showToast("Base de datos restaurada. El sistema se recargará...", "success");
              setTimeout(() => window.location.reload(), 2000);
          } catch (err) {
              console.error(err);
              showToast("Error al importar: Archivo inválido o corrupto", "error");
          }
      };
      reader.readAsText(file);
      // Reset input
      event.target.value = '';
  };

  if (currentUser.role !== UserRole.ADMIN) {
      return <div className="p-8 text-red-500 glass-panel rounded-lg m-4">🚫 Acceso Restringido. Requiere privilegios de Administrador.</div>;
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12 animate-in fade-in zoom-in-95">
       <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-6 gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-white p-2 rounded-lg shadow-sm border border-slate-200">
                <img src={ALCALDIA_LOGO_URL} alt="Logo" className="h-12 w-auto" />
            </div>
            <div>
                <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight">Centro de Seguridad</h2>
                <p className="text-slate-500 font-medium">Gestión de identidad y auditoría forense</p>
            </div>
          </div>
          
          <div className="flex bg-white/50 backdrop-blur rounded-lg p-1 border border-white/40 shadow-sm flex-wrap">
              <button 
                onClick={() => setActiveTab('users')}
                className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'users' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                  Usuarios
              </button>
              <button 
                onClick={() => setActiveTab('logs')}
                className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'logs' ? 'bg-white text-purple-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                  <History size={16}/> Bitácora
              </button>
              <button 
                onClick={() => setActiveTab('hashes')}
                className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'hashes' ? 'bg-white text-teal-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                  <FileCheck size={16}/> Hashes
              </button>
              <button 
                onClick={() => setActiveTab('db')}
                className={`px-4 py-2 rounded-md text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'db' ? 'bg-white text-green-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                  <Database size={16}/> Datos
              </button>
          </div>
       </div>

      {activeTab === 'users' && (
          <div className="glass-panel rounded-xl overflow-hidden shadow-sm">
            <div className="p-6 border-b border-white/50 bg-white/40 flex justify-between items-center">
                 <h3 className="font-bold text-slate-700 flex items-center gap-2"><UserCog size={20}/> Usuarios Registrados</h3>
                 <span className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-bold">{users?.length} Activos</span>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                <thead className="bg-slate-50/50 border-b border-gray-200/50 text-xs uppercase text-slate-500 font-bold">
                    <tr>
                    <th className="px-6 py-4">Usuario</th>
                    <th className="px-6 py-4">Rol de Acceso</th>
                    <th className="px-6 py-4">Fecha Registro</th>
                    <th className="px-6 py-4 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100/50">
                    {users?.map(u => (
                    <tr key={u.id} className="hover:bg-white/60 transition-colors">
                        <td className="px-6 py-4 font-bold text-slate-700 flex items-center gap-3">
                             <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold">{u.username.charAt(0).toUpperCase()}</div>
                             {u.username}
                        </td>
                        <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${u.role === UserRole.ADMIN ? 'bg-purple-100 text-purple-700 border-purple-200' : 'bg-blue-100 text-blue-700 border-blue-200'}`}>
                            {u.role}
                        </span>
                        </td>
                        <td className="px-6 py-4 text-gray-500">{new Date(u.createdAt).toLocaleDateString()}</td>
                        <td className="px-6 py-4 text-right flex items-center justify-end gap-2">
                            <button onClick={() => openPasswordModal(u)} className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-transparent hover:border-slate-200" title="Cambiar Contraseña">
                                <Key size={16} />
                            </button>
                            {u.id !== currentUser.id && (
                                <>
                                    <button onClick={() => toggleRole(u)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors border border-transparent hover:border-blue-100" title="Cambiar Rol">
                                        <Shield size={16} />
                                    </button>
                                    <button onClick={() => handleDelete(u.id!)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100" title="Eliminar">
                                        <Trash2 size={16} />
                                    </button>
                                </>
                            )}
                        </td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>
          </div>
      )}

      {activeTab === 'logs' && (
          <div className="glass-panel rounded-xl overflow-hidden shadow-sm">
             <div className="p-6 border-b border-white/50 bg-white/40 flex justify-between items-center">
                 <h3 className="font-bold text-slate-700 flex items-center gap-2"><Shield size={20}/> Auditoría del Sistema</h3>
                 <div className="flex items-center gap-2 text-xs text-orange-600 bg-orange-50 px-3 py-1.5 rounded-lg border border-orange-100">
                     <AlertTriangle size={12} />
                     <span className="font-semibold">Auto-Limpieza: &gt; 30 días</span>
                 </div>
            </div>
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                <table className="w-full text-left text-sm">
                <thead className="bg-slate-50/50 border-b border-gray-200/50 text-xs uppercase text-slate-500 font-bold sticky top-0 bg-white/90 backdrop-blur z-10">
                    <tr>
                    <th className="px-6 py-3">Fecha y Hora</th>
                    <th className="px-6 py-3">Usuario</th>
                    <th className="px-6 py-3">Acción</th>
                    <th className="px-6 py-3">Detalle</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100/50">
                    {logs?.map(l => (
                    <tr key={l.id} className="hover:bg-white/60 transition-colors">
                        <td className="px-6 py-3 text-gray-500 font-mono text-xs whitespace-nowrap">{new Date(l.timestamp).toLocaleString()}</td>
                        <td className="px-6 py-3 font-bold text-slate-700">{l.username}</td>
                        <td className="px-6 py-3">
                            <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded text-[10px] font-bold text-slate-600">{l.action}</span>
                        </td>
                        <td className="px-6 py-3 text-slate-600">{l.details}</td>
                    </tr>
                    ))}
                    {logs?.length === 0 && (
                        <tr><td colSpan={4} className="p-8 text-center text-gray-400 italic">No hay registros de auditoría recientes.</td></tr>
                    )}
                </tbody>
                </table>
            </div>
          </div>
      )}

      {activeTab === 'hashes' && (
          <div className="glass-panel rounded-xl overflow-hidden shadow-sm">
             <div className="p-6 border-b border-white/50 bg-white/40 flex justify-between items-center">
                 <h3 className="font-bold text-slate-700 flex items-center gap-2"><FileCheck size={20}/> Hashes de Seguridad (Documentos Oficiales)</h3>
                 <span className="text-xs bg-teal-100 text-teal-700 px-3 py-1 rounded-full font-bold">{docLogs?.length || 0} Generados</span>
            </div>
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                <table className="w-full text-left text-sm">
                <thead className="bg-slate-50/50 border-b border-gray-200/50 text-xs uppercase text-slate-500 font-bold sticky top-0 bg-white/90 backdrop-blur z-10">
                    <tr>
                    <th className="px-6 py-3">Fecha de Emisión</th>
                    <th className="px-6 py-3">Responsable</th>
                    <th className="px-6 py-3">Documento & Hash</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100/50">
                    {docLogs?.map(l => {
                        const parts = l.details.split('| Hash:');
                        const docName = parts[0]?.replace('Documento: ', '') || 'Documento Desconocido';
                        const hash = parts[1]?.trim() || 'N/A';
                        return (
                            <tr key={l.id} className="hover:bg-white/60 transition-colors">
                                <td className="px-6 py-3 text-gray-500 font-mono text-xs whitespace-nowrap">{new Date(l.timestamp).toLocaleString()}</td>
                                <td className="px-6 py-3 font-bold text-slate-700">{l.username}</td>
                                <td className="px-6 py-3">
                                    <div className="flex flex-col">
                                        <span className="font-bold text-slate-800">{docName}</span>
                                        <span className="font-mono text-[10px] text-teal-600 bg-teal-50 px-2 py-1 rounded border border-teal-100 w-fit mt-1 select-all">{hash}</span>
                                    </div>
                                </td>
                            </tr>
                        );
                    })}
                    {(!docLogs || docLogs.length === 0) && (
                        <tr><td colSpan={3} className="p-8 text-center text-gray-400 italic">No se han generado documentos oficiales aún.</td></tr>
                    )}
                </tbody>
                </table>
            </div>
          </div>
      )}

      {activeTab === 'db' && (
          <div className="glass-panel rounded-xl overflow-hidden shadow-sm">
             <div className="p-6 border-b border-white/50 bg-white/40 flex justify-between items-center">
                 <h3 className="font-bold text-slate-700 flex items-center gap-2"><Database size={20}/> Gestión de Base de Datos</h3>
            </div>
            <div className="p-8 flex flex-col md:flex-row gap-8 justify-center items-center text-center">
                 <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 hover:shadow-lg transition-all max-w-sm w-full">
                     <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600">
                         <Download size={32} />
                     </div>
                     <h4 className="font-bold text-slate-800 text-lg mb-2">Exportar Respaldo</h4>
                     <p className="text-sm text-slate-500 mb-6">Descargar una copia completa de la base de datos (JSON) para guardarla en su equipo.</p>
                     <button onClick={handleExportDB} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-xl w-full flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20">
                         <Save size={18} /> Descargar Backup
                     </button>
                 </div>

                 <div className="bg-purple-50 p-6 rounded-2xl border border-purple-100 hover:shadow-lg transition-all max-w-sm w-full">
                     <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-purple-600">
                         <Upload size={32} />
                     </div>
                     <h4 className="font-bold text-slate-800 text-lg mb-2">Restaurar Datos</h4>
                     <p className="text-sm text-slate-500 mb-6">Cargar un archivo de respaldo previamente exportado. <br/><span className="text-red-500 font-bold text-xs">⚠️ ESTO SOBRESCRIBIRÁ LOS DATOS</span></p>
                     <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept=".json" />
                     <button onClick={handleImportClick} className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-xl w-full flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20">
                         <Upload size={18} /> Importar Archivo
                     </button>
                 </div>
            </div>
          </div>
      )}

      {/* PASSWORD RESET MODAL */}
      {passwordModal.show && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
              <div className="bg-white rounded-xl w-full max-w-sm shadow-2xl animate-in zoom-in-95">
                  <div className="bg-slate-900 text-white p-4 flex justify-between items-center rounded-t-xl">
                      <h3 className="font-bold flex items-center gap-2"><Key size={18}/> Cambiar Contraseña</h3>
                      <button onClick={() => setPasswordModal({show: false, userId: null, username: ''})}><X size={18}/></button>
                  </div>
                  <div className="p-6">
                      <p className="text-sm text-slate-600 mb-4">Ingrese la nueva contraseña para el usuario <b>{passwordModal.username}</b>:</p>
                      <input 
                        type="password" 
                        className="w-full border p-2 rounded mb-4" 
                        placeholder="Nueva contraseña (mínimo 6 caracteres)"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        autoFocus
                      />
                      <button 
                        onClick={handlePasswordUpdate}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded shadow-lg"
                      >
                          Guardar Nueva Contraseña
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default UsersControlView;