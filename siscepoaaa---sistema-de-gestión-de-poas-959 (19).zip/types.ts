

export enum UserRole {
  ADMIN = 'ADMIN',
  TRANSCRIBER = 'TRANSCRIBER'
}

export interface User {
  id?: number;
  username: string;
  passwordHash: string; // Simplified for demo, usually bcrypt
  role: UserRole;
  createdAt: string;
}

export interface Department {
  id?: number;
  name: string;
  managerName: string;
  email: string;
  phone: string;
  mission: string;
  vision: string;
  
  // Updated fields per request
  type?: 'DEPENDENCY' | 'INSTITUTE' | 'OFFICE'; // New field for categorization
  parentId?: number; // Link an Office to a Dependency (Manager)
  
  planPatriaObjective?: string;
  planPatriaLine?: string;
  municipalObjective?: string;
  municipalLine?: string;
  
  // Legacy fields (optional support)
  objectives?: string;
  planPatriaGoal?: string; 
  municipalStrategy?: string;
  
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH';
  order: number; // Added for Drag and Drop
}

export interface Goal {
  id?: number;
  deptId: number;
  description: string;
  verificationMeans?: string; // New Field: Medios de Verificación
  isExtra: boolean;
  unit: string; // e.g., 'Unidad', 'Informe'
  
  t1_plan: number;
  t1_exec: number;
  t2_plan: number;
  t2_exec: number;
  t3_plan: number;
  t3_exec: number;
  t4_plan: number;
  t4_exec: number;
  
  order?: number; // Added for Drag & Drop functionality
  lastUpdated?: string;
}

// New Module: Special Projects
export interface Project {
    id?: number;
    deptId: number;
    name: string;
    description: string;
    status: 'PLANIFICADO' | 'EJECUCION' | 'DETENIDO' | 'CULMINADO';
    progress: number; // 0-100
    budget?: number;
    startDate: string;
    endDate: string;
}

export interface ActivityDetail {
    date: string;
    title: string;
    description: string;
    priority: 'Alta' | 'Media' | 'Baja' | 'Normal' | 'High' | 'Low';
    status?: 'Completada' | 'En Progreso' | 'Bloqueada' | 'Pendiente';
    time?: number; // Hours
    impact_value?: number;
    activity_origin?: string;
}

export interface WeeklyReport {
  id?: number;
  deptId: number;
  startDate: string;
  endDate: string;
  executiveSummary: string;
  generalDetails?: string; // New from CSV
  observations?: string; // New from CSV
  classification?: string; // Estrategico, Operativo
  activities: ActivityDetail[];
  createdAt: string;
  createdBy: string;
}

export interface AuditLog {
  id?: number;
  username: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface Reminder {
  id?: number;
  deptId: number;
  title: string;
  description: string;
  priority: 'ALTA' | 'MEDIA' | 'BAJA';
  createdAt: string;
  createdBy: string;
  isRead: boolean;
}

export interface ReportTemplate {
    id?: number;
    reportKey: string; // 'MEMORIA', 'DIPLOMA', etc.
    name: string; // 'Modelo 2024', 'Edición Especial'
    content: string;
    lastModified: string;
}

export const MASTER_KEY_HASH = "14401308";
export const ALCALDIA_LOGO_URL = "https://alcaldiaalbertoadriani.com/wp-content/uploads/2022/07/Logo-Alcaldia-con-Slogan-1-2.png";