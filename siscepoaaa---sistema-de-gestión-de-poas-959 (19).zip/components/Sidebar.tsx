
import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, logAudit } from '../services/db';
import { User, UserRole, Department } from '../types';
import { LayoutDashboard, FileText, Users, Building2, GripVertical, Plus, X, Trash2, Landmark, ChevronDown, ChevronRight, Search, Briefcase, Edit2, CornerDownRight, Clock } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

interface SidebarProps {
  user: User;
}

// --- FUZZY SEARCH UTILS ---
const levenshteinDistance = (a: string, b: string): number => {
    const matrix = [];
    for (let i = 0; i <= b.length; i++) matrix[i] = [i];
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;

    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j] + 1
                );
            }
        }
    }
    return matrix[b.length][a.length];
};

const fuzzyMatch = (text: string, search: string): boolean => {
    const cleanText = text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const cleanSearch = search.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    
    if (!cleanSearch) return true;
    if (cleanText.includes(cleanSearch)) return true;

    const words = cleanSearch.split(' ');
    const textWords = cleanText.split(' ');
    
    // Check if every search word matches *some* word in the text with tolerance
    return words.every(sw => {
        if (sw.length < 3) return cleanText.includes(sw); // Strict for short words
        return textWords.some(tw => {
            if (tw.includes(sw)) return true;
            return levenshteinDistance(tw, sw) <= 2; // Allow 2 errors max
        });
    });
};

const Sidebar: React.FC<SidebarProps> = ({ user }) => {
  const departments = useLiveQuery(() => db.departments.orderBy('order').toArray());
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptType, setNewDeptType] = useState<'DEPENDENCY' | 'INSTITUTE' | 'OFFICE'>('DEPENDENCY');
  const [selectedParentId, setSelectedParentId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Search History State (Search #3)
  const [searchHistory, setSearchHistory] = useState<any[]>([]);

  // Collapse States
  const [isDepsOpen, setIsDepsOpen] = useState(true);
  const [isOfficesOpen, setIsOfficesOpen] = useState(true);
  const [isInstsOpen, setIsInstsOpen] = useState(true);

  // Load History
  useEffect(() => {
      const history = localStorage.getItem('siga_search_history');
      if (history) setSearchHistory(JSON.parse(history));
  }, []);

  // Filter lists based on Fuzzy Search
  const dependencies = departments?.filter(d => 
      (!d.type || d.type === 'DEPENDENCY') && 
      (fuzzyMatch(d.name, searchTerm) || (
          // Search improvement: Check if any child office matches
          departments.some(c => c.type === 'OFFICE' && c.parentId === d.id && fuzzyMatch(c.name, searchTerm))
      ))
  ) || [];

  // UPDATED: Only show offices that DO NOT have a parent (Orphans) in the top list
  const orphanOffices = departments?.filter(d => 
      d.type === 'OFFICE' && 
      !d.parentId && 
      fuzzyMatch(d.name, searchTerm)
  ) || [];

  // UPDATED: Allow institutes to show if children match search
  const institutes = departments?.filter(d => 
      d.type === 'INSTITUTE' && 
      (fuzzyMatch(d.name, searchTerm) || (
          // Search improvement: Check if any child office matches (same as dependencies)
          departments.some(c => c.type === 'OFFICE' && c.parentId === d.id && fuzzyMatch(c.name, searchTerm))
      ))
  ) || [];

  // Combine for Parent Selection (Managers + Institutes)
  const potentialParents = departments ? departments.filter(d => (!d.type || d.type === 'DEPENDENCY' || d.type === 'INSTITUTE')).sort((a,b) => a.name.localeCompare(b.name)) : [];

  // Auto-expand if searching
  useEffect(() => {
      if (searchTerm) {
          setIsDepsOpen(true);
          setIsOfficesOpen(true);
          setIsInstsOpen(true);
      }
  }, [searchTerm]);

  const navClass = ({ isActive }: { isActive: boolean }) => 
    `flex items-center gap-3 px-4 py-3 text-sm font-medium transition-all duration-200 border-l-4 rounded-r-lg mr-2 ${
      isActive 
        ? 'bg-white/20 text-white border-blue-400 backdrop-blur-sm shadow-lg' 
        : 'text-slate-400 hover:bg-white/10 hover:text-white border-transparent'
    }`;

  const handleOnDragEnd = async (result: any) => {
    if (!result.destination || !departments || searchTerm) return; // Disable drag when searching

    const sourceId = result.source.droppableId;
    
    // Determine which list we are reordering
    let listToReorder: Department[] = [];
    let baseOrder = 0;

    if (sourceId === 'sidebar-institutes') {
        listToReorder = departments.filter(d => d.type === 'INSTITUTE');
        baseOrder = 2000;
    } else if (sourceId === 'sidebar-offices') {
        listToReorder = departments.filter(d => d.type === 'OFFICE' && !d.parentId);
        baseOrder = 1000;
    } else {
        listToReorder = departments.filter(d => !d.type || d.type === 'DEPENDENCY');
        baseOrder = 0;
    }
    
    // Reorder array locally
    const [reorderedItem] = listToReorder.splice(result.source.index, 1);
    listToReorder.splice(result.destination.index, 0, reorderedItem);

    // Update DB
    await Promise.all(listToReorder.map((item, index) => 
        db.departments.update(item.id!, { order: baseOrder + index })
    ));
  };

  const openAddModal = () => {
      setEditingDept(null);
      setNewDeptName('');
      setNewDeptType('DEPENDENCY');
      setSelectedParentId(null);
      setShowAddModal(true);
  };

  const openEditModal = (dept: Department) => {
      setEditingDept(dept);
      setNewDeptName(dept.name);
      setNewDeptType(dept.type || 'DEPENDENCY');
      setSelectedParentId(dept.parentId || null);
      setShowAddModal(true);
  };

  const handleSaveDept = async () => {
      if(!newDeptName.trim()) return;
      
      if (editingDept && editingDept.id) {
          // Update Existing
          await db.departments.update(editingDept.id, {
              name: newDeptName,
              type: newDeptType,
              parentId: (newDeptType === 'OFFICE' && selectedParentId) ? selectedParentId : undefined
          });
          await logAudit(user.username, 'UPDATE_DEPT', `Actualizada: ${newDeptName} (${newDeptType})`);
      } else {
          // Create New
          const nextOrder = departments ? departments.length : 0;
          await db.departments.add({
              name: newDeptName,
              managerName: 'Por Designar',
              email: 'contacto@alcaldia.gob.ve',
              phone: '',
              mission: '',
              vision: '',
              planPatriaObjective: '',
              planPatriaLine: '',
              municipalObjective: '',
              municipalLine: '',
              order: nextOrder,
              type: newDeptType,
              parentId: (newDeptType === 'OFFICE' && selectedParentId) ? selectedParentId : undefined
          });
          await logAudit(user.username, 'CREATE_DEPT', `Creada: ${newDeptName} (${newDeptType})`);
      }
      
      setNewDeptName('');
      setSelectedParentId(null);
      setEditingDept(null);
      setShowAddModal(false);
  };

  const handleDeleteDept = async (id: number, name: string) => {
      if (window.confirm(`⚠️ ADVERTENCIA CRÍTICA ⚠️\n\n¿Está seguro que desea eliminar: "${name}"?\n\nEsta acción podría dejar huérfanas metas y reportes asociados. Solo debe hacerlo si está seguro.`)) {
          await db.departments.delete(id);
          await logAudit(user.username, 'DELETE_DEPT', `Eliminada ID ${id}: ${name}`);
      }
  };

  const renderDraggableList = (items: Department[], droppableId: string, icon: any, showChildren = false) => (
      <Droppable droppableId={droppableId}>
          {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef}>
                  {items.map((dept, index) => {
                    const parentDept = dept.type === 'OFFICE' && dept.parentId && departments ? departments.find(d => d.id === dept.parentId) : null;
                    // Find children if enabled (and filter by search term)
                    const childrenOffices = showChildren && departments 
                        ? departments.filter(d => d.type === 'OFFICE' && d.parentId === dept.id && fuzzyMatch(d.name, searchTerm))
                        : [];

                    return (
                    <Draggable key={dept.id} draggableId={String(dept.id)} index={index} isDragDisabled={user.role !== UserRole.ADMIN || searchTerm !== ''}>
                        {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              className="group relative flex flex-col mb-1 pl-2"
                              style={{ ...provided.draggableProps.style }}
                            >
                                <div className="flex items-center">
                                    {user.role === UserRole.ADMIN && !searchTerm && (
                                        <div {...provided.dragHandleProps} className="p-2 cursor-grab text-slate-600 hover:text-white flex-shrink-0 z-20">
                                            <GripVertical size={14} />
                                        </div>
                                    )}

                                    <NavLink 
                                    to={`/matrix/${dept.id}`} 
                                    className={({ isActive }) => `flex-1 flex flex-col justify-center px-3 py-2.5 text-xs transition-all border-l-2 mr-2 rounded-r group-hover:bg-white/5 cursor-pointer z-10 ${
                                        isActive 
                                        ? 'bg-white/10 text-blue-200 border-blue-400 font-semibold' 
                                        : 'text-slate-400 hover:text-white border-transparent'
                                    } ${snapshot.isDragging ? 'bg-slate-700 shadow-xl opacity-90 rounded' : ''}`}
                                    >
                                    <div className="flex items-center gap-3 w-full">
                                        {icon}
                                        <span className="truncate max-w-[160px]" title={dept.name}>{dept.name}</span>
                                    </div>
                                    {parentDept && (
                                        <div className="text-[9px] text-emerald-500/80 ml-7 mt-0.5 truncate">
                                            Adscrito a: {parentDept.name}
                                        </div>
                                    )}
                                    </NavLink>
                                    
                                    {user.role === UserRole.ADMIN && (
                                        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center opacity-0 group-hover:opacity-100 transition-opacity z-30 bg-slate-900/80 rounded px-1">
                                            <button 
                                            onClick={(e) => { e.preventDefault(); e.stopPropagation(); openEditModal(dept); }}
                                            className="p-1.5 text-slate-400 hover:text-blue-400"
                                            title="Editar Nombre"
                                            >
                                                <Edit2 size={12} />
                                            </button>
                                            <button 
                                            onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleDeleteDept(dept.id!, dept.name); }}
                                            className="p-1.5 text-slate-400 hover:text-red-400"
                                            title="Eliminar"
                                            >
                                                <Trash2 size={12} />
                                            </button>
                                        </div>
                                    )}
                                </div>

                                {/* Render Children Offices */}
                                {childrenOffices.length > 0 && (
                                    <div className="ml-8 pl-2 border-l border-slate-700 mt-1 space-y-1">
                                        {childrenOffices.map(child => (
                                            <div key={child.id} className="relative group/child flex items-center pr-2">
                                                <NavLink 
                                                    to={`/matrix/${child.id}`} 
                                                    className={({ isActive }) => `flex-1 flex items-center gap-2 py-1.5 px-2 rounded text-[11px] transition-colors ${
                                                        isActive 
                                                        ? 'text-emerald-300 bg-emerald-900/20 font-semibold' 
                                                        : 'text-slate-500 hover:text-emerald-400'
                                                    }`}
                                                >
                                                    <CornerDownRight size={10} className="opacity-50" />
                                                    <span className="truncate">{child.name}</span>
                                                </NavLink>
                                                
                                                {user.role === UserRole.ADMIN && (
                                                    <div className="flex items-center gap-1 opacity-0 group-hover/child:opacity-100 transition-opacity absolute right-0 bg-slate-900/80 rounded">
                                                        <button 
                                                            onClick={(e) => { e.preventDefault(); openEditModal(child); }}
                                                            className="p-1 text-slate-400 hover:text-blue-400"
                                                        >
                                                            <Edit2 size={10} />
                                                        </button>
                                                        <button 
                                                            onClick={(e) => { e.preventDefault(); handleDeleteDept(child.id!, child.name); }}
                                                            className="p-1 text-slate-400 hover:text-red-400"
                                                        >
                                                            <Trash2 size={10} />
                                                        </button>
                                                    </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}
                    </Draggable>
                  )})}
                  {provided.placeholder}
              </div>
          )}
      </Droppable>
  );

  return (
    <>
    <nav className="flex-1 py-4 flex flex-col gap-2 overflow-hidden">
      {/* SEARCH BAR */}
      <div className="px-4 mb-2">
          <div className="relative">
              <input 
                  type="text" 
                  placeholder="Buscar (acepta errores)..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-800/50 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
              />
              <Search size={14} className="absolute left-3 top-2.5 text-slate-500" />
              {searchTerm && <button onClick={() => setSearchTerm('')} className="absolute right-3 top-2.5 text-slate-500 hover:text-white"><X size={14}/></button>}
          </div>
          <div className="flex items-center justify-between mt-1 px-1">
             <div className="text-[9px] text-slate-500">Ctrl+K: Comandos</div>
          </div>
      </div>
      
      {/* Search History (Search #3) */}
      {!searchTerm && searchHistory.length > 0 && (
          <div className="px-4 mb-4">
              <div className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1 flex items-center gap-1"><Clock size={9}/> Recientes</div>
              <div className="space-y-1">
                  {searchHistory.map((h: any, i) => (
                      <NavLink key={i} to={`/matrix/${h.id}`} className="block text-[11px] text-slate-400 hover:text-blue-300 truncate px-2 py-0.5 rounded hover:bg-white/5 transition-colors">
                          {h.name}
                      </NavLink>
                  ))}
              </div>
          </div>
      )}

      <div className="flex-1 overflow-y-auto custom-scrollbar px-2">
          <div className="px-4 mb-2 text-[10px] font-bold text-blue-300 uppercase tracking-widest mt-2">Módulos Principales</div>
          
          <NavLink to="/hall" className={navClass}>
            <LayoutDashboard size={18} />
            Dashboard
          </NavLink>
          
          {user.role === UserRole.ADMIN && (
            <>
              <NavLink to="/reports" className={navClass}>
                <FileText size={18} />
                Reportes Oficiales
              </NavLink>
              <NavLink to="/users" className={navClass}>
                <Users size={18} />
                Usuarios & Auditoría
              </NavLink>
            </>
          )}

          {/* HEADER SECTION FOR DEPENDENCIES (GERENCIAS) */}
          <div className="mt-8 px-4 mb-2 flex items-center justify-between group cursor-pointer sticky top-0 bg-[#0f172a] z-30 py-1" onClick={() => setIsDepsOpen(!isDepsOpen)}>
             <div className="flex items-center gap-2">
                 {isDepsOpen ? <ChevronDown size={14} className="text-slate-400"/> : <ChevronRight size={14} className="text-slate-400"/>}
                 <span className="text-[10px] font-bold text-blue-300 uppercase tracking-widest group-hover:text-white transition-colors">Dependencias</span>
             </div>
             <div className="flex gap-2 items-center">
                 <span className="text-[10px] bg-white/20 text-white px-2 py-0.5 rounded-full font-bold">{dependencies.length}</span>
                 {user.role === UserRole.ADMIN && (
                     <button onClick={(e) => { e.stopPropagation(); setNewDeptType('DEPENDENCY'); openAddModal(); }} className="p-1 hover:bg-blue-500 rounded text-slate-300 hover:text-white transition-colors" title="Agregar Gerencia">
                         <Plus size={14} />
                     </button>
                 )}
             </div>
          </div>
          
          <div className={`transition-all duration-300 ${isDepsOpen ? 'opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
              <DragDropContext onDragEnd={handleOnDragEnd}>
                 {renderDraggableList(dependencies, 'sidebar-dependencies', <Building2 size={14} className="opacity-50 flex-shrink-0" />, true)}
              </DragDropContext>
              {dependencies.length === 0 && <p className="px-10 text-[10px] text-slate-600 italic py-2">No se encontraron dependencias.</p>}
          </div>

          {/* HEADER SECTION FOR ORPHAN OFFICES (NEW LOGIC) */}
          {/* Only show this section if there are truly orphan offices */}
          {(orphanOffices.length > 0) && (
              <>
                <div className="mt-6 px-4 mb-2 flex items-center justify-between group cursor-pointer sticky top-0 bg-[#0f172a] z-30 py-1" onClick={() => setIsOfficesOpen(!isOfficesOpen)}>
                    <div className="flex items-center gap-2">
                        {isOfficesOpen ? <ChevronDown size={14} className="text-slate-400"/> : <ChevronRight size={14} className="text-slate-400"/>}
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest group-hover:text-emerald-300 transition-colors">
                            Oficinas Independientes
                        </span>
                    </div>
                    <div className="flex gap-2 items-center">
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-500 px-2 py-0.5 rounded-full font-bold">{orphanOffices.length}</span>
                        {user.role === UserRole.ADMIN && (
                            <button onClick={(e) => { e.stopPropagation(); setNewDeptType('OFFICE'); openAddModal(); }} className="p-1 hover:bg-emerald-600 rounded text-slate-300 hover:text-white transition-colors" title="Agregar Oficina">
                                <Plus size={14} />
                            </button>
                        )}
                    </div>
                </div>

                <div className={`transition-all duration-300 ${isOfficesOpen ? 'opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
                    <DragDropContext onDragEnd={handleOnDragEnd}>
                        {renderDraggableList(orphanOffices, 'sidebar-offices', <Briefcase size={14} className="opacity-50 flex-shrink-0 text-emerald-500" />)}
                    </DragDropContext>
                    {orphanOffices.length === 0 && <p className="px-10 text-[10px] text-slate-600 italic py-2">No hay oficinas sin adscripción.</p>}
                </div>
              </>
          )}
          
          {/* IF NO ORPHANS, STILL SHOW ADD BUTTON FOR OFFICES SOMEWHERE OR RELY ON TYPE SELECTOR */}
          {orphanOffices.length === 0 && user.role === UserRole.ADMIN && !searchTerm && (
              <div className="px-4 mt-2">
                   <button onClick={() => { setNewDeptType('OFFICE'); openAddModal(); }} className="w-full py-1 text-[10px] border border-dashed border-slate-700 text-slate-500 hover:text-emerald-400 hover:border-emerald-500 rounded flex items-center justify-center gap-2 transition-colors">
                       <Plus size={12}/> Agregar Oficina Independiente
                   </button>
              </div>
          )}

          {/* HEADER SECTION FOR INSTITUTES */}
          <div className="mt-6 px-4 mb-2 flex items-center justify-between group cursor-pointer sticky top-0 bg-[#0f172a] z-30 py-1" onClick={() => setIsInstsOpen(!isInstsOpen)}>
             <div className="flex items-center gap-2">
                 {isInstsOpen ? <ChevronDown size={14} className="text-slate-400"/> : <ChevronRight size={14} className="text-slate-400"/>}
                 <span className="text-[10px] font-bold text-yellow-500/80 uppercase tracking-widest group-hover:text-yellow-400 transition-colors">Institutos</span>
             </div>
             <div className="flex gap-2 items-center">
                 <span className="text-[10px] bg-yellow-500/20 text-yellow-500 px-2 py-0.5 rounded-full font-bold">{institutes.length}</span>
                 {user.role === UserRole.ADMIN && (
                     <button onClick={(e) => { e.stopPropagation(); setNewDeptType('INSTITUTE'); openAddModal(); }} className="p-1 hover:bg-yellow-600 rounded text-slate-300 hover:text-white transition-colors" title="Agregar Instituto">
                         <Plus size={14} />
                     </button>
                 )}
             </div>
          </div>

          {/* INSTITUTES LIST */}
          <div className={`transition-all duration-300 ${isInstsOpen ? 'opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
              <DragDropContext onDragEnd={handleOnDragEnd}>
                 {/* FIX: Passed true as last argument to render nested children (offices) for institutes */}
                 {renderDraggableList(institutes, 'sidebar-institutes', <Landmark size={14} className="opacity-50 flex-shrink-0 text-yellow-500" />, true)}
              </DragDropContext>
              {institutes.length === 0 && <p className="px-10 text-[10px] text-slate-600 italic py-2">No se encontraron institutos.</p>}
          </div>
      </div>
      
      <div className="p-4 mt-auto">
         <div className="bg-white/5 backdrop-blur-sm p-3 rounded-lg border border-white/10">
            <p className="text-[10px] text-slate-400 text-center leading-tight">
               <span className="text-blue-300 font-bold">Sistema Integrado de Gestión y Auditoría de Gobierno V1.0</span>
            </p>
         </div>
      </div>
    </nav>

    {/* Add/Edit Dept Modal */}
    {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 border border-white/20">
                <div className="bg-slate-800 text-white p-4 flex justify-between items-center">
                    <h3 className="text-sm font-bold flex items-center gap-2"><Building2 size={16}/> {editingDept ? 'Editar Registro' : 'Nuevo Registro'}</h3>
                    <button onClick={() => setShowAddModal(false)}><X size={16}/></button>
                </div>
                <div className="p-6">
                    <div className="mb-4">
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Tipo de Organización</label>
                        <div className="flex gap-2">
                            <button 
                                onClick={() => setNewDeptType('DEPENDENCY')}
                                className={`flex-1 py-2 text-[10px] font-bold rounded border ${newDeptType === 'DEPENDENCY' ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-50 text-slate-500 border-slate-200'}`}
                            >
                                Gerencia
                            </button>
                            <button 
                                onClick={() => setNewDeptType('OFFICE')}
                                className={`flex-1 py-2 text-[10px] font-bold rounded border ${newDeptType === 'OFFICE' ? 'bg-emerald-500 text-white border-emerald-500' : 'bg-slate-50 text-slate-500 border-slate-200'}`}
                            >
                                Oficina
                            </button>
                            <button 
                                onClick={() => setNewDeptType('INSTITUTE')}
                                className={`flex-1 py-2 text-[10px] font-bold rounded border ${newDeptType === 'INSTITUTE' ? 'bg-yellow-500 text-white border-yellow-500' : 'bg-slate-50 text-slate-500 border-slate-200'}`}
                            >
                                Instituto
                            </button>
                        </div>
                    </div>
                    
                    {newDeptType === 'OFFICE' && (
                        <div className="mb-4">
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Dependencia Adscrita (Jefatura)</label>
                            <select 
                                className="w-full border border-gray-300 p-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 bg-white"
                                value={selectedParentId || ''}
                                onChange={(e) => setSelectedParentId(Number(e.target.value))}
                            >
                                <option value="">Seleccione Gerencia o Instituto...</option>
                                {potentialParents.map(d => (
                                    <option key={d.id} value={d.id}>{d.name}</option>
                                ))}
                            </select>
                        </div>
                    )}

                    <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Nombre Oficial</label>
                    <input 
                        className="w-full border border-gray-300 p-3 rounded-lg text-sm mb-6 focus:ring-2 focus:ring-blue-500 outline-none text-slate-900" 
                        autoFocus
                        placeholder={
                            newDeptType === 'DEPENDENCY' ? "Ej: Gerencia de RRHH" : 
                            newDeptType === 'OFFICE' ? "Ej: Oficina de Prensa" :
                            "Ej: Instituto de Deporte"
                        }
                        value={newDeptName}
                        onChange={e => setNewDeptName(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleSaveDept()}
                    />
                    <button 
                        onClick={handleSaveDept}
                        className="w-full bg-slate-800 hover:bg-slate-900 text-white py-3 rounded-lg text-sm font-bold shadow-lg transition-transform active:scale-95"
                    >
                        {editingDept ? 'Guardar Cambios' : 'Crear Registro'}
                    </button>
                </div>
            </div>
        </div>
    )}
    </>
  );
};

export default Sidebar;
